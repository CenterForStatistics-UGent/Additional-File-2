
dir <- "C:\\Users\\Alemu\\Dropbox\\R Analysis\\DataRCodeFinal\\04-Code - Copy\\New file to store R Data\\"
setwd(dir)

#CRC AZA ---------------------------------------------------------------------------------------------------
read.CRC   <- readRDS("CRC AZA data analysis\\CRC_AZA_data.RData")
counts.CRC <-read.CRC$counts
group.CRC  <- read.CRC$group
counts.CRC <- counts.CRC[which(rowSums(counts.CRC[, group.CRC == levels(group.CRC)[1]]) > 0 &
                         rowSums(counts.CRC[, group.CRC == levels(group.CRC)[2]]) > 0),]
dim(counts.CRC) #14658x6

#NGP Nutlin -----------------------------------------------------------------------------------------------------
read.NGP   <- readRDS("NGP Nutlin\\celine_neuroblastoma_data.RData")
counts.NGP <-read.NGP $counts
counts.NGP <- as.matrix(counts.NGP )
group.NGP  <- as.factor(read.NGP $group)
mRNA.NGP   <- read.NGP$mRNA 
lncRNA.NGP <- read.NGP$lncRNA

colnames(counts.NGP ) <- c(paste0("A", c(1:10)), paste0("B", c(1:10)))
group.NGP  <- as.factor(ifelse(group.NGP ==levels(group.NGP )[1], "condA", "condB"))
counts.NGP  <- counts.NGP [which(rowSums(counts.NGP[, group.NGP  == levels(group.NGP )[1]]) > 0 &
                                   rowSums(counts.NGP [, group.NGP  == levels(group.NGP )[2]]) > 0),]
dim(counts.NGP ) #26418x20

#Hammer -----------------------------------------------------------------------------------------------------
read.Hammer   <- readRDS("Hammer\\Hammer_Data.RData")
counts.Hammer <- read.Hammer$counts
group.Hammer  <- read.Hammer$group
counts.Hammer <- counts.Hammer[which(rowSums(counts.Hammer[, group.Hammer == levels(group.Hammer)[1]]) > 0 &
                         rowSums(counts.Hammer[, group.Hammer == levels(group.Hammer)[2]]) > 0),]
dim(counts.Hammer) #15908 x4

#Bottomly -----------------------------------------------------------------------------------------------------
read.Bottomly   <- readRDS("Bottomly\\Bottomly_Data.RData")
counts.Bottomly <- read.Bottomly$counts
group.Bottomly  <- read.Bottomly$group
counts.Bottomly <- counts.Bottomly[which(rowSums(counts.Bottomly[, group.Bottomly == levels(group.Bottomly)[1]]) > 0 &
                         rowSums(counts.Bottomly[, group.Bottomly == levels(group.Bottomly)[2]]) > 0),]
dim(counts.Bottomly) #12784 x21

#GTEx -----------------------------------------------------------------------------------------------------
read.GTEx   <- readRDS("GTEx\\GTEx_data_full.RData")
counts.GTEx <- read.GTEx$counts
group.GTEx  <- read.GTEx$group
counts.GTEx <- counts.GTEx[which(rowSums(counts.GTEx[, group.GTEx == levels(group.GTEx)[1]]) > 0 &
                         rowSums(counts.GTEx[, group.GTEx == levels(group.GTEx)[2]]) > 0),]
dim(counts.GTEx) #18770 x 58

#Zhang data -----------------------------------------------------------------------------------------------------
read.Zhang   <- readRDS("Zhang\\Kalisto_Zhang_data.RData")
counts.Zhang <- read.Zhang$counts
group.Zhang  <- as.factor(read.Zhang$group)
mRNA.Zhang   <- read.Zhang$mRNA
lncRNA.Zhang <- read.Zhang$lncRNA

counts.Zhang <- counts.Zhang[which(rowSums(counts.Zhang[, group.Zhang == levels(group.Zhang)[1]]) > 0 &
                                     rowSums(counts.Zhang[, group.Zhang == levels(group.Zhang)[2]]) > 0),]

dim(counts.Zhang)# 31890 x175

#####################################################################################################################
#Comparing variability among datasets
calcl.tagwise.disp <- function(counts, group, biotype=list(), nbiotype="mRNA", data.name){
  require(edgeR)
  y <- DGEList(counts=counts, group = group)
  y <- calcNormFactors(y)
  des <- model.matrix(~group)
  y <- estimateDisp(y, design = des, tagwise = TRUE)
  common    <- y$common.dispersion
  gene.wise <- y$tagwise.dispersion
  
  x <- rep(nbiotype, nrow(counts))
  if(!is.null(biotype)){
    x[which(rownames(counts) %in% biotype$mRNA)]   <- "mRNA"
    x[which(rownames(counts) %in% biotype$lncRNA)] <- "lncRNA"
  } 
  return(data.frame(gene.wise.disp=gene.wise, common.disp=common, gbiotype=x, data=data.name))
}


disp.CRC             <- calcl.tagwise.disp(counts.CRC, group.CRC, data.name = "CRC AZA")
disp.Hammer          <- calcl.tagwise.disp(counts.Hammer, group.Hammer, data.name = "Hammer")
disp.Bottomly        <- calcl.tagwise.disp(counts.Bottomly, group.Bottomly, data.name = "Bottomly")
disp.GTEx            <- calcl.tagwise.disp(counts.GTEx, group.GTEx, data.name = "GTEx")
disp.NGP.mRNA        <- calcl.tagwise.disp(counts.NGP[mRNA.NGP, ],    group.NGP, nbiotype="mRNA", data.name = "NGP Nutlin (mRNA)") #, biotype = list(mRNA=mRNA.NGP, lncRNA=lncRNA.NGP))
disp.NGP.lncRNA      <- calcl.tagwise.disp(counts.NGP[lncRNA.NGP, ],  group.NGP, nbiotype = "lncRNA", data.name = "NGP Nutlin (lncRNA)") #, biotype = list(mRNA=mRNA.NGP, lncRNA=lncRNA.NGP))
disp.Zhang.mRNA      <- calcl.tagwise.disp(counts.Zhang[mRNA.Zhang,],  group.Zhang, nbiotype="mRNA", data.name = "Zhang (mRNA)") #, biotype = list(mRNA=mRNA.Zhang, lncRNA=lncRNA.Zhang))
disp.Zhang.lncRNA    <- calcl.tagwise.disp(counts.Zhang[lncRNA.Zhang, ], group.Zhang, nbiotype = "lncRNA", data.name = "Zhang (lncRNA)") #, biotype = list(mRNA=mRNA.Zhang, lncRNA=lncRNA.Zhang))

all.disp      <- rbind(disp.CRC, disp.Hammer, disp.Bottomly,  disp.GTEx, disp.NGP.mRNA, disp.NGP.lncRNA, disp.Zhang.mRNA, disp.Zhang.lncRNA)
head(all.disp)

win.graph()
ggplot(all.disp)+
  geom_boxplot(aes(y=log(sqrt(gene.wise.disp)), x=as.factor(data)))+
  geom_point(aes(y=log(sqrt(common.disp)), x=as.factor(data)), size=4, color="red")+
  coord_flip()+
  labs(y="biological coefficient of variation [log scale]", x=NULL)+
  theme(axis.title.x = element_text(size=15),
        axis.title.y = element_text(size=15),
        axis.text = element_text(size=15),
        panel.background = element_rect(fill = "gray90", colour = "grey90"),
        panel.grid.major.x = element_line(),
        panel.grid.major.y = element_line())
  

all.disp2 <- all.disp
all.disp2$data <- as.character(all.disp2$data)
all.disp2$data <- sapply(1:nrow(all.disp2), function(x) {
  if(substr(all.disp2$data[x], 1, 3)=="NGP") {"NGP Nutlin"}
  else if(substr(all.disp2$data[x], 1, 5)=="Zhang") {"Zhang"}
  else {all.disp2$data[x]}
})

all.disp.sub <- all.disp2[all.disp2$data %in% c("Zhang", "NGP Nutlin"), ]

win.graph()
ggplot(all.disp.sub, aes(x=gbiotype, y=log(sqrt(gene.wise.disp)), fill=gbiotype))+
  geom_boxplot()+
  facet_grid(~data)+
  scale_fill_manual("", values=alpha(c("lightblue", "orange"), 0.6))+
  labs(x="",  y="BCV [log]", title="Estimated biological coefficient of variations")+
  theme(axis.text  = element_text(size=15),
        axis.title = element_text(size=15),
        legend.position = "none")


#Comparing istribution of average expression between mRNA and lncRNA

norm.counts.Zhang <- DESeq::newCountDataSet(counts.Zhang, group.Zhang)
norm.counts.Zhang <- DESeq::estimateSizeFactors(norm.counts.Zhang)
norm.counts.Zhang <- log2(DESeq::counts(norm.counts.Zhang, normalized=TRUE)+1)
mean.norm.counts.Zhang <- data.frame(mean = apply(norm.counts.Zhang, 1, mean))
mean.norm.counts.Zhang$biotype <- NA
mean.norm.counts.Zhang$biotype[rownames(mean.norm.counts.Zhang) %in% mRNA.Zhang] <- "mRNA"
mean.norm.counts.Zhang$biotype[rownames(mean.norm.counts.Zhang) %in% lncRNA.Zhang] <- "lncRNA"

norm.counts.NGP <- DESeq::newCountDataSet(counts.NGP, group.NGP)
norm.counts.NGP <- DESeq::estimateSizeFactors(norm.counts.NGP)
norm.counts.NGP <- log2(DESeq::counts(norm.counts.NGP, normalized=TRUE)+1)
mean.norm.counts.NGP <- data.frame(mean = apply(norm.counts.NGP, 1, mean))
mean.norm.counts.NGP$biotype <- NA
mean.norm.counts.NGP$biotype[rownames(mean.norm.counts.NGP) %in% mRNA.NGP] <- "mRNA"
mean.norm.counts.NGP$biotype[rownames(mean.norm.counts.NGP) %in% lncRNA.NGP] <- "lncRNA"


win.graph() 
pl1 <- ggplot(mean.norm.counts.Zhang, aes(x=mean, y=..density..)) + 
  stat_bin(data=subset(mean.norm.counts.Zhang, biotype == 'mRNA'),   fill = "deepskyblue3", colour="gray90",  alpha = 0.5) +
  stat_bin(data=subset(mean.norm.counts.Zhang, biotype == 'lncRNA'), fill = "orange", colour="gray90", alpha = 0.5)+
  theme(axis.title = element_text(size=15),
        axis.text  = element_text(size=15),
        panel.background = element_rect(fill = "white", colour = "grey90"),
        panel.grid.major.x = element_line(),
        panel.grid.major.y = element_line())+
  labs(x="average log-read-counts", y="density", title="Zhang data")

pl2 <- ggplot(mean.norm.counts.NGP, aes(x=mean, y=..density..)) + 
  geom_histogram(data=subset(mean.norm.counts.NGP, biotype == 'mRNA'),   fill = "deepskyblue3", colour="gray90",  alpha = 0.5) +
  geom_histogram(data=subset(mean.norm.counts.NGP, biotype == 'lncRNA'), fill = "orange", colour="gray90", alpha = 0.5)+
  theme(axis.title = element_text(size=15),
        axis.text  = element_text(size=15),
        panel.background = element_rect(fill = "white", colour = "grey90"),
        panel.grid.major.x = element_line(),
        panel.grid.major.y = element_line())+
  labs(x="average log-read-counts", y="density", title="NGP Nutlin data")

library(gridExtra)
grid.arrange(pl1, pl2, ncol=2)

#----------------------------------------------------------------------------------------
#Full data analysis of Zhang, GTEx, and NGP Nutlin datastes





#--------------------------------------------------------------------------------
cor.Zhang1.mRNA <- cor(counts.Zhang[mRNA.Zhang, group.Zhang == levels(group.Zhang)[1]])
cor.Zhang2.mRNA <- cor(counts.Zhang[mRNA.Zhang, group.Zhang == levels(group.Zhang)[2]])
cor.Zhang.mRNA <- c(as.vector(cor.Zhang1.mRNA[lower.tri(cor.Zhang1.mRNA, diag = F)]), as.vector(cor.Zhang2.mRNA[lower.tri(cor.Zhang2.mRNA, diag = F)]))

cor.Zhang1.lncRNA <- cor(counts.Zhang[lncRNA.Zhang, group.Zhang == levels(group.Zhang)[1]])
cor.Zhang2.lncRNA <- cor(counts.Zhang[lncRNA.Zhang, group.Zhang == levels(group.Zhang)[2]])
cor.Zhang.lncRNA <- c(as.vector(cor.Zhang1.lncRNA[lower.tri(cor.Zhang1.lncRNA, diag = F)]), as.vector(cor.Zhang2.lncRNA[lower.tri(cor.Zhang2.lncRNA, diag = F)]))


cor.Zhang <- data.frame(cor.Zhang.mRNA, cor.Zhang.lncRNA)
colnames(cor.Zhang) <- c("mRNA", "lncRNA")
cor.Zhang$data <- "Zhang"


cor.NGP1.mRNA <- cor(counts.NGP[mRNA.NGP, group.NGP == levels(group.NGP)[1]])
cor.NGP2.mRNA <- cor(counts.NGP[mRNA.NGP, group.NGP == levels(group.NGP)[2]])
cor.NGP.mRNA <- c(as.vector(cor.NGP1.mRNA[lower.tri(cor.NGP1.mRNA, diag = F)]), as.vector(cor.NGP2.mRNA[lower.tri(cor.NGP2.mRNA, diag = F)]))

cor.NGP1.lncRNA <- cor(counts.NGP[lncRNA.NGP, group.NGP == levels(group.NGP)[1]])
cor.NGP2.lncRNA <- cor(counts.NGP[lncRNA.NGP, group.NGP == levels(group.NGP)[2]])
cor.NGP.lncRNA <- c(as.vector(cor.NGP1.lncRNA[lower.tri(cor.NGP1.lncRNA, diag = F)]), as.vector(cor.NGP2.lncRNA[lower.tri(cor.NGP2.lncRNA, diag = F)]))


cor.NGP <- data.frame(cor.NGP.mRNA, cor.NGP.lncRNA)
colnames(cor.NGP) <- c("mRNA", "lncRNA")
cor.NGP$data <- "NGP Nutlin"

cor.Zhang.NGP <- rbind(cor.Zhang, cor.NGP)
library(reshape2)
cor.Zhang.NGP <- melt(cor.Zhang.NGP, id.vars=c("data"))

win.graph()
ggplot(cor.Zhang.NGP, aes(x=variable, y=value, fill=variable))+
  geom_boxplot()+
  facet_grid(~data)+
  scale_fill_manual("", values=alpha(c("lightblue", "orange"), 0.6))+
  labs(x="",  y="correlation", title="Pearson's correlation coefficient among intra-group replicates")+
  theme(axis.text = element_text(size=15),
        axis.title = element_text(size=15),
        legend.position = "none")
  
  
  

