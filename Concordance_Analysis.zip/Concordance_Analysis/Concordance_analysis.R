######  running DE tools
source("ll_DE_tools_for_concordance_analysis.R")




#CRC AZA Data  
  ###### Set working directory
  setwd('CRC AZA data analysis')
  
  
  ##### Loading annotated and processed data
  read <- readRDS("data/CRC_AZA_data.RData")
  counts <-read$counts
  group <- read$group
  counts <- counts[which(rowSums(counts[, group == levels(group)[1]]) > 0 &
                           rowSums(counts[, group == levels(group)[2]]) > 0),]
  dim(counts)
  #14658 mRNA genes

  ####  Exploratory Data Analysis 
  
  #Correlation summary
  cor.summary <- function(counts, group){
    group <- as.factor(group)
    counts <- counts[, c(which(group == levels(group)[1]), 
                         which(group == levels(group)[2]))]
    
    WC1 <- cor(counts[, which(group == levels(group)[1])])
    WC1 <- WC1[lower.tri(WC1, diag = FALSE)]
    WC2 <- cor(counts[, which(group == levels(group)[2])])
    WC2 <- WC2[lower.tri(WC2, diag = FALSE)]
    
    WC.summary <- quantile(c(WC1, WC2), prob=c(0,0.25, 0.5, 0.75, 1))
    
    BC <- cor(counts)[1:length(which(group == levels(group)[1])),
                      (length(which(group == levels(group)[1]))+1):length(group)]
    BC <- BC[lower.tri(BC, diag = FALSE)]
    BC.summary <- quantile(BC, prob=c(0, 0.25, 0.5, 0.75, 1))
    
    return(list(within.cor=WC.summary, between.cor =BC.summary ))
  }
  cor.summary(counts, group)
  
  #Library size
  colSums(counts)

  #Exolring biological coefficient of variability (BCV) using edgeR
  library(edgeR)
  win.graph()
  y <- DGEList(counts=counts, group=group)
  y <- calcNormFactors(y)
  design <- model.matrix(~group)
  y <- estimateCommonDisp(y, design)
  y <- estimateGLMCommonDisp(y, design, verbose=TRUE)
  y <- estimateGLMTrendedDisp(y, design)
  y <- estimateGLMTagwiseDisp(y, design)
  plotBCV(y, ylim=c(0, 6), main="CRC AZA (mRNA)", cex.lab=1.5)
  text(7, 4, "Common Dispersion = 0.010 \n Common BCV = 0.098", cex=1.5, col=2)
  
  
  #PCA plot to setect batch effect
  library("DESeq2")
  dds <- DESeqDataSetFromMatrix(counts, DataFrame(group), ~ group)
  dds <- estimateSizeFactors(dds)
  dds <- dds[ rowSums(counts(dds, normalize=T)) > 1, ]
  nrow(dds)
  rld <- rlog(dds, blind = FALSE)
  DESeq2::plotPCA(rld, intgroup="group", ntop = 1000)
  
  
  #####  Running DGE analysis 
  ###### Set analysis output object
  results.full <- list()
  # edgeR - classic
  results.full["edgeR_classic"] <- list(runedgeR_classic(count.dat=counts, conditions=group,
                                                         colors=colors,path=outputpath))
  # edgeR - glm
  results.full["edgeR_glm"] <- list(runedgeR_glm(count.dat=counts, conditions=group,
                                                 colors=colors,path=outputpath))
  # edgeR - robust 
  results.full["edgeR_rob"] <- list(runedgeR_rob(count.dat=counts, conditions=group,
                                                 colors=colors,path=outputpath))
  # edgeR - quasi-likelihood 
  results.full["edgeR_ql"] <- list(runedgeR_ql(count.dat=counts, conditions=group,
                                               colors=colors,path=outputpath))
  
  # DESeq
  results.full["DESeq"] <- list(runDESeq(count.dat=counts, conditions=group,
                                         colors=colors,path=outputpath))
  # DESeq2
  results.full["DESeq2"] <- list(runDESeq2(count.dat=counts, conditions=group,
                                           colors=colors,path=outputpath))
  # Limma + quantile normalization
  results.full["LimmaQN"] <- list(runLimmaQN(count.dat=counts, conditions=group,
                                             colors=colors,path=outputpath))
  # LimmaVoom (without quality weights)
  results.full["LimmaVoom"] <- list(runLimmaVoom(count.dat=counts, conditions=group,
                                                 colors=colors,path=outputpath))
  # LimmaVoom (with quality weights)
  results.full["LimmaVoom_QW"] <- list(runLimmaVoom_QW(count.dat=counts, conditions=group,
                                                       colors=colors,path=outputpath))
  # LimmaVst 
  results.full["LimmaVst"] <- list(runLimmaVst(count.dat=counts, conditions=group,
                                               colors=colors,path=outputpath))
  # BaySeq
  results.full["BaySeq"] <- list(runBaySeq(count.dat=counts, conditions=group,
                                           colors=colors,path=outputpath))
  
  # PoissonSeq -> Note: pass adapted cut-off to method if required
  results.full["PoissonSeq"] <- list(runPoissonSeq(count.dat=counts, conditions=group,
                                                   colors=colors,path=outputpath))
  # SAMSeq
  results.full["SAMSeq"] <- list(runSAMSeq(count.dat=counts, conditions=group,
                                           colors=colors,path=outputpath))
  
  # QuasiSeq
  results.full["QuasiSeq"] <- list(runQuasiSeq(count.dat=counts, conditions=group,
                                               colors=colors,path=outputpath))
   
  #Saving result
  saveRDS(results.full, file="result_full_CRC_AZA.RData")
  
  
  
  #####  Concordance Analysis between DE tools 
  #Loading saved result of CRC AZA analysis
  results.full <- readRDS("result_full_CRC_AZA.RData")
  methods <- names(results.full)
  
  ## organaizing results
  library(DESeq)
  cds <- DESeq::newCountDataSet(counts, group)
  cds <- DESeq::estimateSizeFactors(cds)
  norm.counts <- counts(cds, normalized=TRUE)
  
  classical.LFC.estimates <- data.frame(classical.LFC = apply(norm.counts, 1, function(x) {
    mu.g1 <- mean(x[group==levels(group)[1]])
    mu.g2 <- mean(x[group==levels(group)[2]])
    if(mu.g1 != 0 & mu.g2 != 0) {lfc <- log2(mu.g2/mu.g1)}
    else if(mu.g1 != 0 & mu.g2 == 0) {lfc <- -log2(mu.g1)}
    else if(mu.g1 == 0 & mu.g2 != 0) {lfc <- log2(mu.g2)}
    return(lfc) }))
  classical.LFC.estimates$ID <- rownames(classical.LFC.estimates)
  
  Merge.DE.results <- function(results.full, na.treat ="keep"){
    #A function that returns the rank of genes for all methods 
    methods <-  names(results.full)
    
    df1 <- results.full[1][[paste(methods[1])]]$summary
    df1 <- merge(df1, classical.LFC.estimates, by="ID", all.x=T, all.y=T)
    df1$pval[is.na(df1$pval)] <- 1
    df1$signed.pval <- sign(df1$classical.LFC)*(df1$pval+1e-5)  #A constant +1e-5 is added to each pvalues to avoid 0 signed p-value when p-value is 0
    df1$pi.score <- abs(df1$classical.LFC)*(-log10(df1$pval+1e-5))
    
    df2 <- results.full[2][[paste(methods[2])]]$summary
    df2 <- merge(df2, classical.LFC.estimates, by="ID", all.x=T, all.y=T)
    df2$pval[is.na(df2$pval)] <- 1
    df2$signed.pval <- sign(df2$classical.LFC)*(df2$pval+1e-5)
    df2$pi.score <- abs(df2$classical.LFC)*(-log10(df2$pval+1e-5))
    
    
    summary.all <- merge(df1, df2, by ="ID", all.x=T, all.y=T)
    colnames(summary.all) <- c("ID", paste(methods[1],".", c(colnames(df1)), sep="")[-1], 
                               paste(methods[2],".", c(colnames(df2)), sep="")[-1])
    
    for(i in 3:length(methods)){
      df.i <- results.full[i][[paste(methods[i])]]$summary
      df.i <- merge(df.i, classical.LFC.estimates, by="ID", all.x=T, all.y=T)
      df.i$pval[is.na(df.i$pval)] <- 1
      
      if(methods[i] != "SAMSeq"){
        df.i$signed.pval <- sign(df.i$classical.LFC)*(df.i$pval+1e-5)
        df.i$pi.score <- abs(df.i$classical.LFC)*(-log10(df.i$pval+1e-5))
      }
      
      if(methods[i] == "SAMSeq"){
        df.i$stat[is.na(df.i$stat)] <- 0
        df.i$signed.pval <- sign(df.i$classical.LFC)*(1/abs(df.i$stat+1e-5))
        df.i$pi.score <- abs(df.i$classical.LFC)*(-log10(1/abs(df.i$stat+1e-5)))
      }
      colnames(df.i) <- c("ID", paste(methods[i], ".", colnames(df.i), sep="")[-1])
      
      summary.all <- merge(summary.all, df.i, by ="ID", all.x=T, all.y=T)
      #colnames(summary.all) <- c("ID", methods[1:i])
    }
    
    rownames(summary.all) <- summary.all$ID
    summary.all <- summary.all[,-1]
    
    return(summary.all)
  }
  
  
  #Merging summary results of all the methods
  summary.all <- Merge.DE.results(results.full)
  dim(summary.all)
  
  methods.name <- c("edgeR exact", "edgeR GLM", "edgeR robust", "edgeR QL", "DESeq", "DESeq2", "limmaQN", "limmaVoom", "limmaVoom + QW", "limmaVst", 
                    "baySeq", "PoissonSeq", "SAMSeq", "QuasiSeq")
  
  
  
  #------------------------------------------------------------------------#
  #GENE RANK ANALYSIS 
  #Spearman's Rank Correlation Matrix
  #columns <- paste(methods,".", "signed.pval", sep="")
  columns <- paste(methods,".", "pi.score", sep="")
  score.matrix <- summary.all[,c(columns)]
  colnames(score.matrix) <- methods.name
  
  #classical LFC estimates
  columns <- paste(methods,".", "classical.LFC", sep="")
  LFC.matrix <- summary.all[,c(columns)]
  colnames(LFC.matrix) <- methods.name
  LFC.matrix <- as.data.frame(lapply(LFC.matrix, function(x) replace(x, is.infinite(x),NA)))
  rownames(LFC.matrix) <- rownames(summary.all)
  
  
  #subsetting the top commonly identifed SDE genes across methods
  columns <- paste(methods,".", "padj", sep="")
  padj.matrix <- summary.all[,c(columns)]
  padj.matrix[is.na(padj.matrix)] = 1   #replacing NA values by 1
  colnames(padj.matrix) <- methods.name
  
  common.SDE.genes <- names(which(apply(padj.matrix, 1, function(x) {
    if(max(x) < 1) {return(1)}
    else {return(0)}}) == 1))
  length(common.SDE.genes)
  
  #Rank correlation, ranks scores and if there are ties, it uses auxillary information to break ties
  rank.cov <- function(y, x=NULL, na.last=TRUE, ties.method="average"){
    r <- y
    if(is.null(x)) {r <- rank(y, na.last=na.last, ties.method=ties.method)}
    else if(!is.null(x)){
      r.temp <- rank(y, na.last=na.last, ties.method="min")
      t.r <- table(r.temp)
      ties <- as.numeric(names(which(t.r>1)))
      if(length(ties)>=1) {
        for(i in 1:length(ties)){
          r.cov <- rank(x[r.temp==ties[i]])-1
          r.temp[r.temp==ties[i]] <- r.temp[r.temp==ties[i]] + r.cov
        }
      }
      else{
        r.temp <- rank(y, na.last=na.last, ties.method=ties.method)
      }
      r <- r.temp 
    }
    return(r)
  }
  
  rank.matrix <- apply(score.matrix, 2, function(v){
    rank.cov(v, x=LFC.matrix[,1])
  })
  
  rank.matrix <- rank.matrix[common.SDE.genes, ]
  
  cor.rank <- round(cor(rank.matrix, use = "pairwise.complete.obs", method ="spearman"), 3)
  cor.rank.2 <- cor.rank
  diag(cor.rank.2) <- NA
  mean.cor <- apply(cor.rank.2, 1, function(x) mean(x, na.rm=T))
  saveRDS(mean.cor, "mean.rank.cor.RData")
  
  cor.rank[lower.tri(cor.rank, diag = T)] <- NA
  cor.rank
  
  
  
  library(reshape2)
  cor.dat <- melt(cor.rank, na.rm = TRUE)
  colnames(cor.dat) <- c("X1", "X2", "value")
  cor.dat$X1<- factor(cor.dat$X1, levels = methods.name)
  cor.dat$X2<- factor(cor.dat$X2, levels = methods.name)
  cor.dat <- cor.dat[!is.na(cor.dat$value),]
  
  library(ggplot2)
  library("scales") 
  
  win.graph()
  ggplot(cor.dat, aes(X2, ordered(X1, levels=methods.name), fill = value))+
    geom_tile(aes(fill = value))+
    scale_fill_gradientn(limit = c(0.80, 1), space = "Lab", colours = c("white", "blue"),
                         name="Spearman rank \n correlation") +
    theme_minimal()+ # minimal theme
    theme(axis.text.x = element_text(angle = 45, vjust = 1, 
                                     size = 12, hjust = 1))+
    scale_x_discrete(breaks=methods.name, labels=methods.name)+
    scale_y_discrete(breaks=methods.name, labels=methods.name)+
    coord_fixed()+
    geom_text(aes(X2, X1, label = value), color = "black", size = 4) +
    theme(
      axis.title.x = element_blank(),
      axis.title.y = element_blank(),
      panel.grid.major = element_blank(),
      panel.border = element_blank(),
      panel.background = element_blank(),
      axis.ticks = element_blank(),
      legend.justification = c(1, 0),
      legend.position = c(0.6, 0.7),
      legend.direction = "horizontal")+
    guides(fill = guide_colorbar(barwidth = 7, barheight = 1,
                                 title.position = "top", title.hjust = 0.5))
  
  
  #------------------------------------------------------------------------#
  #ANALYSIS OF NUMBER OF DE GENES and CLLASSIFICATION OVERLAPPING
  columns <- paste(methods,".", "padj", sep="")
  padj.matrix <- summary.all[,c(columns)]
  colnames(padj.matrix) <- methods
  
  DE.indicator <- padj.matrix
  for(i in 1:nrow(padj.matrix)){
    for(j in 1:ncol(padj.matrix)){
      if(padj.matrix[i,j] < 0.05 & is.na(padj.matrix[i,j]) == F) DE.indicator[i,j] <- 1
      else if(padj.matrix[i,j] >= 0.05 & is.na(padj.matrix[i,j]) == F) DE.indicator[i,j] <- 0
    }
  }
  
  avgExp <- rowMeans(norm.counts)
  q <- quantile(avgExp, prob=c(0.25, 0.5, 0.75))
  q
  #     25%        50%        75% 
  #75.82372  655.18931 2180.98249
  
  avgExp.cat <- NULL
  avgExp.cat[avgExp<=q[1]] <- "Q1"
  avgExp.cat[avgExp>q[1] & avgExp<=q[2]] <- "Q2"
  avgExp.cat[avgExp>q[2] & avgExp<=q[3]] <- "Q3"
  avgExp.cat[avgExp>q[3]] <- "Q4"
  avgExp.cat[is.na(avgExp)] <- NA
  
  library(reshape)
  DE.indicator2 <- melt(DE.indicator)
  DE.indicator2 <- data.frame(DE.indicator2, avgExp.cat =rep(avgExp.cat, times=length(methods)))
  colnames(DE.indicator2) <- c("Methods", "DE", "GE.Category")
  
  
  library(ggplot2)
  library(gridExtra)

  agr <- aggregate(DE~Methods+GE.Category, data=DE.indicator2, FUN=sum)
  agr.all <- aggregate(DE~Methods, data=DE.indicator2, FUN=sum)
  agr.all$Methods <- agr$Methods <- methods.name
  saveRDS(list(agr.all=agr.all, agr=agr), "SDE.summary.RData")
  
  win.graph()

  pl1 <- ggplot(agr[order(agr$GE.Category, decreasing = F),], 
    aes(x=reorder(Methods, DE), y=DE, fill=GE.Category)) + 
    geom_bar(stat="identity", position = "stack")+ 
    theme(axis.text.x = element_text(angle = 45, hjust = 1), 
    legend.position=c(0.1, 0.8)) + 
    scale_x_discrete(breaks=methods.name, labels=methods.name)+
    labs(title="A", x="DE tools", y="mumber of SDE genes (at 5% FDR)",
    fill="Quartiles")
  
  pl2 <- ggplot(agr,  aes(x=Methods, y=DE, fill=GE.Category)) + 
    geom_bar(stat="identity", position = "fill")+
    theme(axis.text.x = element_text(angle = 45, hjust = 1), legend.position='none') + 
    scale_x_discrete(breaks=methods.name, labels=methods.name)+
    labs(title="B", x="DE tools", y="proportion")
  grid.arrange(pl1, pl2, ncol=2)
  
  #Overlapping of DE classification
  overlap <- matrix(NA, ncol=length(methods), nrow=length(methods))
  for(i in 1:nrow(overlap)){
    for(j in 1:ncol(overlap)){
      overlap[i,j] <- length(which(DE.indicator[,i]==1 & DE.indicator[,j]==1))
    }
  }
  colnames(overlap) <- methods
  rownames(overlap) <- methods
  
  non.overlap.A <- matrix(NA, ncol=length(methods), nrow=length(methods))
  for(i in 1:nrow(non.overlap.A)){
    for(j in 1:ncol(non.overlap.A)){
      non.overlap.A[i,j] <- length(which(DE.indicator[,i]==1 & DE.indicator[,j]==0))
    }
  }
  colnames(non.overlap.A) <- methods
  rownames(non.overlap.A) <- methods

  non.overlap.B <- matrix(NA, ncol=length(methods), nrow=length(methods))
  for(i in 1:nrow(non.overlap.B)){
    for(j in 1:ncol(non.overlap.B)){
      non.overlap.B[i,j] <- length(which(DE.indicator[,i]==0 & DE.indicator[,j]==1))
    }
  }
  colnames(non.overlap.B) <- methods
  rownames(non.overlap.B) <- methods

  overlap.prop <-overlap/(non.overlap.A+overlap+non.overlap.B)
  rownames(overlap.prop) <- methods.name
  colnames(overlap.prop) <- methods.name
  
  # number_of.SDE <- diag(overlap)
  # base <- overlap
  # for(i in 1:nrow(base)){
  #   for(j in 1:ncol(base)){
  #     base[i,j] <- min(number_of.SDE[i], number_of.SDE[j])
  #   }
  # }
  # overlap.prop <- overlap/base
  # rownames(overlap.prop) <- methods.name
  # colnames(overlap.prop) <- methods.name
  
  overlap.prop.2 <- overlap.prop
  diag(overlap.prop.2) <- NA
  mean.overlap <- apply(overlap.prop.2, 1, function(x) mean(x, na.rm=T))
  saveRDS(mean.overlap, "mean.overlap.prop.RData")
  
  
  library(reshape2)
  overlap.prop[lower.tri(overlap.prop, diag = T)] <- NA
  overlap.dat <- melt(overlap.prop, na.rm = TRUE)
  colnames(overlap.dat) <- c("X1", "X2", "value")
  overlap.dat$X1<- factor(overlap.dat$X1, levels = methods.name)
  overlap.dat$X2<- factor(overlap.dat$X2, levels = methods.name)
  overlap.dat <- overlap.dat[!is.na(overlap.dat$value),]
  overlap.dat[, "value"] <- round(overlap.dat[, "value"], 3)
  
  library(ggplot2)
  library("scales") 
  
  win.graph()
  ggplot(overlap.dat, aes(X2, ordered(X1, levels=methods.name), fill = value))+
    geom_tile(aes(fill = value))+
    scale_fill_gradientn(limit = c(0.2, 1), space = "Lab", colours = c("white", "blue"),
                         name="overlap proportion") +
    theme_minimal()+ # minimal theme
    theme(axis.text.x = element_text(angle = 45, vjust = 1, 
                                     size = 12, hjust = 1))+
    scale_x_discrete(breaks=methods.name, labels=methods.name)+
    scale_y_discrete(breaks=methods.name, labels=methods.name)+
    coord_fixed()+
    geom_text(aes(X2, X1, label = value), color = "black", size = 4) +
    theme(
      axis.title.x = element_blank(),
      axis.title.y = element_blank(),
      panel.grid.major = element_blank(),
      panel.border = element_blank(),
      panel.background = element_blank(),
      axis.ticks = element_blank(),
      legend.justification = c(1, 0),
      legend.position = c(0.6, 0.7),
      legend.direction = "horizontal")+
    guides(fill = guide_colorbar(barwidth = 7, barheight = 1,
                                 title.position = "top", title.hjust = 0.5))
  
  #------------------------------------------------------------------------#
  #ANALYSIS OF LFC
  columns <- paste(methods,".", "logFC", sep="")
  LFC.matrix <- summary.all[,c(columns)]
  colnames(LFC.matrix) <- methods.name
  LFC.matrix <- as.data.frame(lapply(LFC.matrix, function(x) replace(x, is.infinite(x),NA)))
  rownames(LFC.matrix) <- rownames(summary.all)
  
  ## Correlation b/n LFC estimates from each method
  cor.lfc <- cor(LFC.matrix[-13], method ="pearson", use="pairwise.complete.obs")
  rownames(cor.lfc) <- colnames(cor.lfc) <-methods.name[-13]
  cor.lfc.2 <- cor.lfc
  diag(cor.lfc.2) <- NA
  mean.cor.lfc <- apply(cor.lfc.2, 1, function(x) mean(x, na.rm=T))
  names(mean.cor.lfc) <- methods.name[-13]
  saveRDS(mean.cor.lfc, "mean.lfc.cor.RData")
  
  
  library(reshape2)
  cor.lfc[lower.tri(cor.lfc, diag = T)] <- NA
  cor.lfc.dat <- melt(cor.lfc, na.rm = TRUE)
  colnames(cor.lfc.dat) <- c("X1", "X2", "value")
  cor.lfc.dat$X1<- factor(cor.lfc.dat$X1, levels = methods.name[-13])
  cor.lfc.dat$X2<- factor(cor.lfc.dat$X2, levels = methods.name[-13])
  cor.lfc.dat <- cor.lfc.dat[!is.na(cor.lfc.dat$value),]
  cor.lfc.dat[, "value"] <- round(cor.lfc.dat[, "value"], 3)
  
  
  library(ggplot2)
  library("scales") 
  
  win.graph()
  ggplot(cor.lfc.dat, aes(X2, ordered(X1, levels=methods.name[-13]), fill = value))+
    geom_tile(aes(fill = value))+
    scale_fill_gradientn(limit = c(0.8, 1), space = "Lab", colours = c("white", "blue"),
                         name="Pearson correlation \n between LFC estimates") +
    theme_minimal()+ # minimal theme
    theme(axis.text.x = element_text(angle = 45, vjust = 1, 
                                     size = 12, hjust = 1))+
    scale_x_discrete(breaks=methods.name[-13], labels=methods.name[-13])+
    scale_y_discrete(breaks=methods.name[-13], labels=methods.name[-13])+
    coord_fixed()+
    geom_text(aes(X2, X1, label = value), color = "black", size = 4) +
    theme(
      axis.title.x = element_blank(),
      axis.title.y = element_blank(),
      panel.grid.major = element_blank(),
      panel.border = element_blank(),
      panel.background = element_blank(),
      axis.ticks = element_blank(),
      legend.justification = c(1, 0),
      legend.position = c(0.6, 0.7),
      legend.direction = "horizontal")+
    guides(fill = guide_colorbar(barwidth = 7, barheight = 1,
                                 title.position = "top", title.hjust = 0.5))
  
  #Scatter plots between LFC estimates of selected DE tools, 
  # with partitioning genes into 4 different abundance levels (quartiles)
  methods2 <- methods[c(1,5, 6,8,11, 12)]
  methods.name2 <- methods.name[c(1,5, 6,8,11, 12)]
  LFC.matrix2 <- LFC.matrix[, c(1,5, 6,8,11, 12)]
  LFC.matrix2$avgExp.cat <- avgExp.cat
  pairs <- t(combn(length(methods2), 2))  [c(2,3,6,7,10,11,12,13,14),]
  cols <- c("dodgerblue4", "firebrick4", "goldenrod4", "mediumseagreen")
  win.graph()
  par(mfrow=c(3,3))
  for(i in 1:nrow(pairs)){
    plot(LFC.matrix2[,pairs[i,1]], LFC.matrix2[, pairs[i,2]], type="n", xlab=paste0(methods.name2[pairs[i,1]]), ylab=paste0(methods.name2[pairs[i,2]]),
         xlim=c(-4, 15), ylim=c(-4, 15))
    points(LFC.matrix2[LFC.matrix2$avgExp.cat =="Q1",pairs[i,1]], LFC.matrix2[LFC.matrix2$avgExp.cat =="Q1",pairs[i,2]], pch=6, col=cols[1])
    points(LFC.matrix2[LFC.matrix2$avgExp.cat =="Q2",pairs[i,1]], LFC.matrix2[LFC.matrix2$avgExp.cat =="Q2",pairs[i,2]], pch=1, col=cols[2])
    points(LFC.matrix2[LFC.matrix2$avgExp.cat =="Q3",pairs[i,1]], LFC.matrix2[LFC.matrix2$avgExp.cat =="Q3",pairs[i,2]], pch=0, col=cols[3])
    points(LFC.matrix2[LFC.matrix2$avgExp.cat =="Q4",pairs[i,1]], LFC.matrix2[LFC.matrix2$avgExp.cat =="Q4",pairs[i,2]], pch=17, col=cols[4])
    abline(0,1, lty=2, lwd=2)
    legend("topleft", c(paste0("Q1 ", "(r=", round(cor(LFC.matrix2[LFC.matrix2$avgExp.cat =="Q1",pairs[i,1]], 
                                                       LFC.matrix2[LFC.matrix2$avgExp.cat =="Q1",pairs[i,2]], use = "pairwise.complete.obs"), 3), ")"),
                        paste0("Q2 ", "(r=", round(cor(LFC.matrix2[LFC.matrix2$avgExp.cat =="Q2",pairs[i,1]], 
                                                       LFC.matrix2[LFC.matrix2$avgExp.cat =="Q2",pairs[i,2]], use = "pairwise.complete.obs"), 3), ")"),
                        paste0("Q3 ", "(r=", round(cor(LFC.matrix2[LFC.matrix2$avgExp.cat =="Q3",pairs[i,1]], 
                                                       LFC.matrix2[LFC.matrix2$avgExp.cat =="Q3",pairs[i,2]], use = "pairwise.complete.obs"), 3), ")"),
                        paste0("Q4 ", "(r=", round(cor(LFC.matrix2[LFC.matrix2$avgExp.cat =="Q4",pairs[i,1]], 
                                                       LFC.matrix2[LFC.matrix2$avgExp.cat =="Q4",pairs[i,2]], use = "pairwise.complete.obs"), 3), ")")),
           pch=c(6, 1, 0, 17), col=cols, bty="n", cex=1.5, ncol=2)
  }
  
  
  #-------------------------------------------------------------------#
  #MA plots
  win.graph()
  par(mfrow=c(2,2))
  
  ##edgeR_classic
  x <- summary.all[,c("edgeR_classic.avgExpr", "edgeR_classic.logFC", "edgeR_classic.padj")]
  colnames(x) <- c("baseMean", "log2FoldChange", "padj" )
  x$avgExp.cat <- avgExp.cat
  plot(x$baseMean, x$log2FoldChange, col = ifelse(x$padj>=0.05, "gray32", "red3"), main="edgeR Exact",
       xlab = "mean of normalized counts", ylab = "LFC", log = "x", cex=0.45, ylim=c(-5, 15))
  abline(v=q, lty=2, col="darkcyan")
  abline(h=c(-1, 1), lty=2, col="darkcyan")
  text(c(1E01, 1.5E02, 1E03, 1.5E04), c(13, 13, 13, 13), c("Q1", "Q2", "Q3", "Q4"))
  text(c(2e05, 2e05), c(-1.75, 1.75), c("LFC = -1", "LFC =1"))
  legend("topright", c("Non SDE Genes", "SDE genes"), col=c("gray32", "red3"), pch=20, bty="n")
  ##DESeq2
  x <- summary.all[,c("edgeR_classic.avgExpr", "DESeq2.logFC", "DESeq2.padj")]
  colnames(x) <- c("baseMean", "log2FoldChange", "padj" )
  x$avgExp.cat <- avgExp.cat
  plot(x$baseMean, x$log2FoldChange, col = ifelse(x$padj>=0.05, "gray32", "red3"), main="DESeq2",
       xlab = "mean of normalized counts", ylab = "LFC", log = "x", cex=0.45, ylim=c(-5, 15))
  abline(v=q, lty=2, col="darkcyan")
  abline(h=c(-1, 1), lty=2, col="darkcyan")
  text(c(1E01, 1.5E02, 1E03, 1.5E04), c(13, 13, 13, 13), c("Q1", "Q2", "Q3", "Q4"))
  text(c(2e05, 2e05), c(-1.75, 1.75), c("LFC = -1", "LFC =1"))
  legend("topright", c("Non SDE Genes", "SDE genes"), col=c("gray32", "red3"), pch=20, bty="n")
  
  ##limmaVoom
  x <- summary.all[,c("edgeR_classic.avgExpr", "LimmaVoom.logFC", "LimmaVoom.padj")]
  colnames(x) <- c("baseMean", "log2FoldChange", "padj" )
  x$avgExp.cat <- avgExp.cat
  plot(x$baseMean, x$log2FoldChange, col = ifelse(x$padj>=0.05, "gray32", "red3"), main="limmaVoom",
       xlab = "mean of normalized counts", ylab = "LFC", log = "x", cex=0.45, ylim=c(-5, 15))
  abline(v=q, lty=2, col="darkcyan")
  abline(h=c(-1, 1), lty=2, col="darkcyan")
  text(c(1E01, 1.5E02, 1E03, 1.5E04), c(13, 13, 13, 13), c("Q1", "Q2", "Q3", "Q4"))
  text(c(2e05, 2e05), c(-1.75, 1.75), c("LFC = -1", "LFC =1"))
  legend("topright", c("Non SDE Genes", "SDE genes"), col=c("gray32", "red3"), pch=20, bty="n")
  
  ##PoissonSeq
  x <- summary.all[,c("edgeR_classic.avgExpr", "PoissonSeq.logFC", "PoissonSeq.padj")]
  colnames(x) <- c("baseMean", "log2FoldChange", "padj" )
  x$avgExp.cat <- avgExp.cat
  plot(x$baseMean, x$log2FoldChange, col = ifelse(x$padj>=0.05, "gray32", "red3"), main="PoissonSeq",
       xlab = "mean of normalized counts", ylab = "LFC", log = "x", cex=0.45, ylim=c(-5, 15))
  abline(v=q, lty=2, col="darkcyan")
  abline(h=c(-1, 1), lty=2, col="darkcyan")
  text(c(1E01, 1.5E02, 1E03, 1.5E04), c(13, 13, 13, 13), c("Q1", "Q2", "Q3", "Q4"))
  text(c(2e05, 2e05), c(-1.75, 1.75), c("LFC = -1", "LFC =1"))
  legend("topright", c("Non SDE Genes", "SDE genes"), col=c("gray32", "red3"), pch=20, bty="n")
  
  #-------------------------------------------------------------------------
  #Computational time
  comput.time <- sapply(results.full, function(x) x$time)[3, ]
  names(comput.time) <- methods.name
  saveRDS(comput.time, "comput.time.RData")
  



##############################################################################################################################################################


#Concordance Analysis based on NGP_Nutlin  data

  
  ###### Set working directory
  setwd('NGP Nutlin')
  

  ##### Loading annotated and processed data
  read <- readRDS("data/celine_neuroblastoma_data.RData")
  counts <-read$counts
  counts <- as.matrix(counts)
  group <- as.factor(read$group)
  mRNA <- read$mRNA 
  lncRNA <- read$lncRNA
  
  colnames(counts) <- c(paste0("A", c(1:10)), paste0("B", c(1:10)))
  group <- as.factor(ifelse(group==levels(group)[1], "condA", "condB"))
  counts.mRNA <-counts[mRNA,]
  counts.lncRNA <- counts[lncRNA,]
  
  counts <- counts[which(rowSums(counts[, group == levels(group)[1]]) > 0 &
                         rowSums(counts[, group == levels(group)[2]]) > 0),]
  dim(counts) ; dim(counts.mRNA) ; dim(counts.lncRNA)
  #26418 genes, in which 17489 mRNA genes and 8929 lncRNAs
  
  ### Exploratory Data Analysis 
  
  #Correlation summary
  cor.summary <- function(counts, group){
    group <- as.factor(group)
    counts <- counts[, c(which(group == levels(group)[1]), 
                         which(group == levels(group)[2]))]
    
    WC1 <- cor(counts[, which(group == levels(group)[1])])
    WC1 <- WC1[lower.tri(WC1, diag = FALSE)]
    WC2 <- cor(counts[, which(group == levels(group)[2])])
    WC2 <- WC2[lower.tri(WC2, diag = FALSE)]
    
    WC.summary <- quantile(c(WC1, WC2), prob=c(0, 0.25, 0.5, 0.75, 1))
    
    BC <- cor(counts)[1:length(which(group == levels(group)[1])),
                      (length(which(group == levels(group)[1]))+1):length(group)]
    BC <- BC[lower.tri(BC, diag = FALSE)]
    BC.summary <- quantile(BC, prob=c(0, 0.25, 0.5, 0.75, 1))
    
    return(list(within.cor=WC.summary, between.cor =BC.summary ))
  }
  cor.summary(counts.mRNA, group)
  cor.summary(counts.lncRNA, group)
  
  #Library sizes
  summary(colSums(counts.mRNA)) ; summary(colSums(counts.lncRNA))
  #Exolring biological coefficient of variability (BCV) using edgeR
  
  library(edgeR)
  win.graph()
  par(mfrow=c(1,2))
  #mRNA
  y.mRNA <- DGEList(counts=counts.mRNA, group=group)
  y.mRNA <- calcNormFactors(y.mRNA)
  design <- model.matrix(~group)
  y.mRNA <- estimateCommonDisp(y.mRNA, design)
  y.mRNA <- estimateGLMCommonDisp(y.mRNA, design, verbose=TRUE)
  y.mRNA <- estimateGLMTrendedDisp(y.mRNA, design)
  y.mRNA <- estimateGLMTagwiseDisp(y.mRNA, design)
  plotBCV(y.mRNA, ylim=c(0, 6), main="Cell-line NB (mRNA)", cex.lab=1.5)
  text(7, 4, "Common Dispersion = 0.187 \n Common BCV = 0.432", cex=1.5, col=2)
  
  #lncRNA
  y.lncRNA <- DGEList(counts=counts.lncRNA, group=group)
  y.lncRNA <- calcNormFactors(y.lncRNA)
  design <- model.matrix(~group)
  y.lncRNA <- estimateCommonDisp(y.lncRNA, design)
  y.lncRNA <- estimateGLMCommonDisp(y.lncRNA, design, verbose=TRUE)
  y.lncRNA <- estimateGLMTrendedDisp(y.lncRNA, design)
  y.lncRNA <- estimateGLMTagwiseDisp(y.lncRNA, design)
  plotBCV(y.lncRNA, ylim=c(0, 6), main="Cell-line NB (lncRNA)", cex.lab=1.5)
  text(9, 4, "Common Dispersion = 0.034 \n Common BCV = 0.183", cex=1.5, col=2)
  
  
  #PCA plot to setect batch effect
  library("DESeq2")
  dds <- DESeqDataSetFromMatrix(counts, DataFrame(group), ~ group)
  dds <- estimateSizeFactors(dds)
  dds <- dds[ rowSums(counts(dds, normalize=T)) > 1, ]
  nrow(dds)
  rld <- rlog(dds, blind = FALSE)
  DESeq2::plotPCA(rld, intgroup="group", ntop = 1000)
  
  ### Running DGE analysis
  ###### Set analysis output object
  results.full <- list()
  
  # edgeR - classic
  results.full["edgeR_classic"] <- list(runedgeR_classic(count.dat=counts, conditions=group,
                                                         colors=colors,path=outputpath))
  # edgeR - glm
  results.full["edgeR_glm"] <- list(runedgeR_glm(count.dat=counts, conditions=group,
                                                 colors=colors,path=outputpath))
  # edgeR - robust 
  results.full["edgeR_rob"] <- list(runedgeR_rob(count.dat=counts, conditions=group,
                                                 colors=colors,path=outputpath))
  # edgeR - quasi-likelihood 
  results.full["edgeR_ql"] <- list(runedgeR_ql(count.dat=counts, conditions=group,
                                               colors=colors,path=outputpath))
  
  # DESeq
  results.full["DESeq"] <- list(runDESeq(count.dat=counts, conditions=group,
                                         colors=colors,path=outputpath))
  # DESeq2
  results.full["DESeq2"] <- list(runDESeq2(count.dat=counts, conditions=group,
                                           colors=colors,path=outputpath))
  # Limma + quantile normalization
  results.full["LimmaQN"] <- list(runLimmaQN(count.dat=counts, conditions=group,
                                             colors=colors,path=outputpath))
  # LimmaVoom (without quality weights)
  results.full["LimmaVoom"] <- list(runLimmaVoom(count.dat=counts, conditions=group,
                                                 colors=colors,path=outputpath))
  # LimmaVoom (with quality weights)
  results.full["LimmaVoom_QW"] <- list(runLimmaVoom_QW(count.dat=counts, conditions=group,
                                                       colors=colors,path=outputpath))
  # LimmaVst 
  results.full["LimmaVst"] <- list(runLimmaVst(count.dat=counts, conditions=group,
                                               colors=colors,path=outputpath))
  # BaySeq
  results.full["BaySeq"] <- list(runBaySeq(count.dat=counts, conditions=group,
                                           colors=colors,path=outputpath))
  
  # PoissonSeq 
  results.full["PoissonSeq"] <- list(runPoissonSeq(count.dat=counts, conditions=group,
                                                   colors=colors,path=outputpath))
  # SAMSeq
  results.full["SAMSeq"] <- list(runSAMSeq(count.dat=counts, conditions=group,
                                           colors=colors,path=outputpath))
  
  # QuasiSeq
  results.full["QuasiSeq"] <- list(runQuasiSeq(count.dat=counts, conditions=group,
                                               colors=colors,path=outputpath))
  
  #Saving result
  saveRDS(results.full, file="result_full_NGP.RData")
  
  
  
  ### Concordance Analysis between DE tools 
  #Loading saved result of CRC AZA analysis
  results.full <- readRDS("result_full_NGP.RData")
  methods <- names(results.full)
  
  ## organaizing results
  library(DESeq)
  cds <- DESeq::newCountDataSet(counts, group)
  cds <- DESeq::estimateSizeFactors(cds)
  norm.counts <- counts(cds, normalized=TRUE)
  
  classical.LFC.estimates <- data.frame(classical.LFC = apply(norm.counts, 1, function(x) {
    mu.g1 <- mean(x[group==levels(group)[1]])
    mu.g2 <- mean(x[group==levels(group)[2]])
    if(mu.g1 != 0 & mu.g2 != 0) {lfc <- log2(mu.g2/mu.g1)}
    else if(mu.g1 != 0 & mu.g2 == 0) {lfc <- -log2(mu.g1)}
    else if(mu.g1 == 0 & mu.g2 != 0) {lfc <- log2(mu.g2)}
    return(lfc) }))
  classical.LFC.estimates$ID <- rownames(classical.LFC.estimates)
  
  Merge.DE.results <- function(results.full, na.treat ="keep"){
    #A function that returns the rank of genes for all methods 
    methods <-  names(results.full)
    
    df1 <- results.full[1][[paste(methods[1])]]$summary
    df1 <- merge(df1, classical.LFC.estimates, by="ID", all.x=T, all.y=T)
    df1$pval[is.na(df1$pval)] <- 1
    df1$signed.pval <- sign(df1$classical.LFC)*(df1$pval+1e-5)  #A constant +1e-5 is added to each pvalues to avoid 0 signed p-value when p-value is 0
    df1$pi.score <- abs(df1$classical.LFC)*(-log10(df1$pval+1e-5))
    
    df2 <- results.full[2][[paste(methods[2])]]$summary
    df2 <- merge(df2, classical.LFC.estimates, by="ID", all.x=T, all.y=T)
    df2$pval[is.na(df2$pval)] <- 1
    df2$signed.pval <- sign(df2$classical.LFC)*(df2$pval+1e-5)
    df2$pi.score <- abs(df2$classical.LFC)*(-log10(df2$pval+1e-5))
    
    
    summary.all <- merge(df1, df2, by ="ID", all.x=T, all.y=T)
    colnames(summary.all) <- c("ID", paste(methods[1],".", c(colnames(df1)), sep="")[-1], 
                               paste(methods[2],".", c(colnames(df2)), sep="")[-1])
    
    for(i in 3:length(methods)){
      df.i <- results.full[i][[paste(methods[i])]]$summary
      df.i <- merge(df.i, classical.LFC.estimates, by="ID", all.x=T, all.y=T)
      df.i$pval[is.na(df.i$pval)] <- 1
      
      if(methods[i] != "SAMSeq"){
        df.i$signed.pval <- sign(df.i$classical.LFC)*(df.i$pval+1e-5)
        df.i$pi.score <- abs(df.i$classical.LFC)*(-log10(df.i$pval+1e-5))
      }
      
      if(methods[i] == "SAMSeq"){
        df.i$stat[is.na(df.i$stat)] <- 0
        df.i$signed.pval <- sign(df.i$classical.LFC)*(1/abs(df.i$stat+1e-5))
        df.i$pi.score <- abs(df.i$classical.LFC)*(-log10(1/abs(df.i$stat+1e-5)))
      }
      colnames(df.i) <- c("ID", paste(methods[i], ".", colnames(df.i), sep="")[-1])
      
      summary.all <- merge(summary.all, df.i, by ="ID", all.x=T, all.y=T)
      #colnames(summary.all) <- c("ID", methods[1:i])
    }
    
    rownames(summary.all) <- summary.all$ID
    summary.all <- summary.all[,-1]
    
    return(summary.all)
  }
  
  
  #Merging summary results of all the methods
  summary.all <- Merge.DE.results(results.full)
  dim(summary.all)
  
  methods.name <- c("edgeR exact", "edgeR GLM", "edgeR robust", "edgeR QL", "DESeq", "DESeq2", "limmaQN", "limmaVoom", "limmaVoom + QW", "limmaVst", 
                    "baySeq", "PoissonSeq", "SAMSeq", "QuasiSeq")
  
  
  
  #------------------------------------------------------------------------#
  #GENE RANK ANALYSIS 
  #Spearman's Rank Correlation Matrix
  #columns <- paste(methods,".", "signed.pval", sep="")
  columns <- paste(methods,".", "pi.score", sep="")
  score.matrix <- summary.all[,c(columns)]
  colnames(score.matrix) <- methods.name
  
  #classical LFC estimates
  columns <- paste(methods,".", "classical.LFC", sep="")
  LFC.matrix <- summary.all[,c(columns)]
  colnames(LFC.matrix) <- methods.name
  LFC.matrix <- as.data.frame(lapply(LFC.matrix, function(x) replace(x, is.infinite(x),NA)))
  rownames(LFC.matrix) <- rownames(summary.all)
  
  
  #subsetting the top commonly identifed SDE genes across methods
  columns <- paste(methods,".", "padj", sep="")
  padj.matrix <- summary.all[,c(columns)]
  padj.matrix[is.na(padj.matrix)] = 1   #replacing NA values by 1
  colnames(padj.matrix) <- methods.name
  
  common.SDE.genes <- names(which(apply(padj.matrix, 1, function(x) {
    if(max(x) < 1) {return(1)}
    else {return(0)}}) == 1))
  length(common.SDE.genes)
  common.SDE.genes.mRNA <- common.SDE.genes[which(common.SDE.genes %in% mRNA)]
  common.SDE.genes.lncRNA <- common.SDE.genes[which(common.SDE.genes %in% lncRNA)]
  length(common.SDE.genes.mRNA) ; length(common.SDE.genes.lncRNA)
  
  #Rank correlation, ranks scores and if there are ties, it uses auxillary information to break ties
  rank.cov <- function(y, x=NULL, na.last=TRUE, ties.method="average"){
    r <- y
    if(is.null(x)) {r <- rank(y, na.last=na.last, ties.method=ties.method)}
    else if(!is.null(x)){
      r.temp <- rank(y, na.last=na.last, ties.method="min")
      t.r <- table(r.temp)
      ties <- as.numeric(names(which(t.r>1)))
      if(length(ties)>=1) {
        for(i in 1:length(ties)){
          r.cov <- rank(x[r.temp==ties[i]])-1
          r.temp[r.temp==ties[i]] <- r.temp[r.temp==ties[i]] + r.cov
        }
      }
      else{
        r.temp <- rank(y, na.last=na.last, ties.method=ties.method)
      }
      r <- r.temp 
    }
    return(r)
  }
  
  #mRNA
  rank.matrix.mRNA <- apply(score.matrix[which(rownames(score.matrix) %in% mRNA), ], 2, function(v){
    rank.cov(v, x=LFC.matrix[which(rownames(LFC.matrix) %in% mRNA), 1])
  })
  rank.matrix.mRNA <- rank.matrix.mRNA[common.SDE.genes.mRNA, ]
  
  #lncRNA
  rank.matrix.lncRNA <- apply(score.matrix[which(rownames(score.matrix) %in% lncRNA), ], 2, function(v){
    rank.cov(v, x=LFC.matrix[which(rownames(LFC.matrix) %in% lncRNA), 1])
  })
  rank.matrix.lncRNA <- rank.matrix.lncRNA[common.SDE.genes.lncRNA, ]
  
  
  #mRNA
  cor.rank.mRNA <- round(cor(rank.matrix.mRNA, use = "pairwise.complete.obs", method ="spearman"), 3)
  cor.rank.mRNA.2 <- cor.rank.mRNA
  diag(cor.rank.mRNA.2) <- NA
  mean.cor.mRNA <- apply(cor.rank.mRNA.2, 1, function(x) mean(x, na.rm=T))
  saveRDS(mean.cor.mRNA, "mean.rank.cor.mRNA.RData")
  
  cor.rank.mRNA[lower.tri(cor.rank.mRNA, diag = T)] <- NA
  cor.rank.mRNA
  
  library(reshape2)
  cor.dat.mRNA <- melt(cor.rank.mRNA, na.rm = TRUE)
  colnames(cor.dat.mRNA) <- c("X1", "X2", "value")
  cor.dat.mRNA$X1<- factor(cor.dat.mRNA$X1, levels = methods.name)
  cor.dat.mRNA$X2<- factor(cor.dat.mRNA$X2, levels = methods.name)
  cor.dat.mRNA <- cor.dat.mRNA[!is.na(cor.dat.mRNA$value),]
  
  
  #lncRNA
  cor.rank.lncRNA <- round(cor(rank.matrix.lncRNA, use = "pairwise.complete.obs", method ="spearman"), 3)
  cor.rank.lncRNA.2 <- cor.rank.lncRNA
  diag(cor.rank.lncRNA.2) <- NA
  mean.cor.lncRNA <- apply(cor.rank.lncRNA.2, 1, function(x) mean(x, na.rm=T))
  saveRDS(mean.cor.lncRNA, "mean.rank.cor.lncRNA.RData")
  
  cor.rank.lncRNA[lower.tri(cor.rank.lncRNA, diag = T)] <- NA
  cor.rank.lncRNA
  
  library(reshape2)
  cor.dat.lncRNA <- melt(cor.rank.lncRNA, na.rm = TRUE)
  colnames(cor.dat.lncRNA) <- c("X1", "X2", "value")
  cor.dat.lncRNA$X1<- factor(cor.dat.lncRNA$X1, levels = methods.name)
  cor.dat.lncRNA$X2<- factor(cor.dat.lncRNA$X2, levels = methods.name)
  cor.dat.lncRNA <- cor.dat.lncRNA[!is.na(cor.dat.lncRNA$value),]
  
  
  
  library(ggplot2)
  library("scales") 
  library(gridExtra)
  
  win.graph()
  pl1 <- ggplot(cor.dat.mRNA, aes(X2, ordered(X1, levels=methods.name), fill = value))+
    geom_tile(aes(fill = value))+labs(title="mRNA")+
    scale_fill_gradientn(limit = c(0.7, 1), space = "Lab", colours = c("white", "blue"),
                         name="Spearman\n rank correlation") +
    theme_minimal()+ # minimal theme
    theme(axis.text.x = element_text(angle = 45, vjust = 1, 
                                     size = 12, hjust = 1))+
    scale_x_discrete(breaks=methods.name, labels=methods.name)+
    scale_y_discrete(breaks=methods.name, labels=methods.name)+
    coord_fixed()+
    geom_text(aes(X2, X1, label = value), color = "black", size = 4) +
    theme(
      axis.title.x = element_blank(),
      axis.title.y = element_blank(),
      panel.grid.major = element_blank(),
      panel.border = element_blank(),
      panel.background = element_blank(),
      axis.ticks = element_blank(),
      legend.justification = c(1, 0),
      legend.position = c(0.6, 0.7),
      legend.direction = "horizontal")+
    guides(fill = guide_colorbar(barwidth = 7, barheight = 1,
                                 title.position = "top", title.hjust = 0.5))
  
  pl2 <- ggplot(cor.dat.lncRNA, aes(X2, ordered(X1, levels=methods.name), fill = value))+
    geom_tile(aes(fill = value))+labs(title="lncRNA")+
    scale_fill_gradientn(limit = c(0.7, 1), space = "Lab", colours = c("white", "blue"),
                         name="Spearman\n rank correlation") +
    theme_minimal()+ # minimal theme
    theme(axis.text.x = element_text(angle = 45, vjust = 1, 
                                     size = 12, hjust = 1))+
    scale_x_discrete(breaks=methods.name, labels=methods.name)+
    scale_y_discrete(breaks=methods.name, labels=methods.name)+
    coord_fixed()+
    geom_text(aes(X2, X1, label = value), color = "black", size = 4) +
    theme(
      axis.title.x = element_blank(),
      axis.title.y = element_blank(),
      panel.grid.major = element_blank(),
      panel.border = element_blank(),
      panel.background = element_blank(),
      axis.ticks = element_blank(),
      legend.justification = c(1, 0),
      legend.position = c(0.6, 0.7),
      legend.direction = "horizontal")+
    guides(fill = guide_colorbar(barwidth = 7, barheight = 1,
                                 title.position = "top", title.hjust = 0.5))
  
  grid.arrange(pl1, pl2, ncol=2)
  
  #------------------------------------------------------------------------#
  #ANALYSIS OF NUMBER OF DE GENES and CLLASSIFICATION OVERLAPPING
  columns <- paste(methods,".", "padj", sep="")
  padj.matrix <- summary.all[,c(columns)]
  colnames(padj.matrix) <- methods
  
  DE.indicator <- padj.matrix
  for(i in 1:nrow(padj.matrix)){
    for(j in 1:ncol(padj.matrix)){
      if(padj.matrix[i,j] < 0.05 & is.na(padj.matrix[i,j]) == F) DE.indicator[i,j] <- 1
      else if(padj.matrix[i,j] >= 0.05 & is.na(padj.matrix[i,j]) == F) DE.indicator[i,j] <- 0
    }
  }
  
  
  biotype <- ifelse(rownames(DE.indicator) %in% mRNA, "mRNA", "lncRNA")
  library(reshape2)
  DE.indicator2 <- melt(DE.indicator)
  DE.indicator2 <- data.frame(DE.indicator2, biotype =rep(biotype, times=length(methods)))
  colnames(DE.indicator2) <- c("Methods", "DE", "biotype")
  
  agr <- aggregate(DE~Methods+biotype, data=DE.indicator2, FUN=sum)
  agr.all <- aggregate(DE~Methods, data=DE.indicator2, FUN=sum)
  agr.all$Methods <- agr$Methods <- methods.name
  saveRDS(list(agr.all=agr.all, agr=agr), "SDE.summary.RData")
  
  library(ggplot2)
  library(gridExtra)
  
  win.graph()
  pl1 <- ggplot(agr, aes(x=reorder(Methods, DE), y=DE, fill=biotype)) + 
    geom_bar(stat="identity", position = "stack")+ 
    theme(axis.text.x = element_text(angle = 45, hjust = 1), 
          legend.position=c(0.2, 0.9)) + 
    scale_x_discrete(breaks=methods.name, labels=methods.name)+
    labs(title="A", x="DE tools", y="mumber of SDE genes (at 5% FDR)",
         fill="genes biotypes")
  
  pl2 <- ggplot(agr,  aes(x=Methods, y=DE, fill=biotype)) + 
    geom_bar(stat="identity", position = "fill")+
    theme(axis.text.x = element_text(angle = 45, hjust = 1), legend.position='none') + 
    scale_x_discrete(breaks=methods.name, labels=methods.name)+
    labs(title="B", x="DE tools", y="proportion")
  grid.arrange(pl1, pl2, ncol=2)
  
  
  #Overlapping of DE classification
  #mRNA
  DE.indicator.mRNA <- DE.indicator[which(rownames(DE.indicator) %in% mRNA), ]
  overlap.mRNA <- matrix(NA, ncol=length(methods), nrow=length(methods))
  for(i in 1:nrow(overlap.mRNA)){
    for(j in 1:ncol(overlap.mRNA)){
      overlap.mRNA[i,j] <- length(which(DE.indicator.mRNA[,i]==1 & DE.indicator.mRNA[,j]==1))
    }
  }
  colnames(overlap.mRNA) <- methods.name
  rownames(overlap.mRNA) <- methods.name
  
  non.overlap.mRNA.A <- matrix(NA, ncol=length(methods), nrow=length(methods))
  for(i in 1:nrow(non.overlap.mRNA.A)){
    for(j in 1:ncol(non.overlap.mRNA.A)){
      non.overlap.mRNA.A[i,j] <- length(which(DE.indicator.mRNA[,i]==1 & DE.indicator.mRNA[,j]==0))
    }
  }
  colnames(non.overlap.mRNA.A) <- methods.name
  rownames(non.overlap.mRNA.A) <- methods.name

  non.overlap.mRNA.B <- t(non.overlap.mRNA.A)

  overlap.mRNA.prop <-overlap.mRNA/(non.overlap.mRNA.A+overlap.mRNA+non.overlap.mRNA.B)
  rownames(overlap.mRNA.prop) <- methods.name
  colnames(overlap.mRNA.prop) <- methods.name
  
  # number_of.SDE.mRNA <- diag(overlap.mRNA)
  # base.mRNA <- overlap.mRNA
  # for(i in 1:nrow(base.mRNA)){
  #   for(j in 1:ncol(base.mRNA)){
  #     base.mRNA[i,j] <- min(number_of.SDE.mRNA[i], number_of.SDE.mRNA[j])
  #   }
  # }
  # overlap.prop.mRNA <- overlap.mRNA/base.mRNA
  # rownames(overlap.prop.mRNA) <- methods.name
  # colnames(overlap.prop.mRNA) <- methods.name
  
  overlap.prop.mRNA.2 <- overlap.mRNA.prop
  diag(overlap.prop.mRNA.2) <- NA
  mean.overlap.mRNA <- apply( overlap.prop.mRNA.2, 1, function(x) mean(x, na.rm=T))
  saveRDS(mean.overlap.mRNA, "mean.overlap.prop.mRNA.RData")
  
  
  library(reshape2)
  overlap.prop.mRNA <- overlap.mRNA.prop
  overlap.prop.mRNA[lower.tri(overlap.prop.mRNA, diag = T)] <- NA
  overlap.mRNA.dat <- melt(overlap.prop.mRNA, na.rm = TRUE)
  colnames(overlap.mRNA.dat) <- c("X1", "X2", "value")
  overlap.mRNA.dat$X1<- factor(overlap.mRNA.dat$X1, levels = methods.name)
  overlap.mRNA.dat$X2<- factor(overlap.mRNA.dat$X2, levels = methods.name)
  overlap.mRNA.dat <- overlap.mRNA.dat[!is.na(overlap.mRNA.dat$value),]
  overlap.mRNA.dat[, "value"] <- round(overlap.mRNA.dat[, "value"], 3)
  
  #lncRNA
  DE.indicator.lncRNA <- DE.indicator[which(rownames(DE.indicator) %in% lncRNA), ]
  overlap.lncRNA <- matrix(NA, ncol=length(methods), nrow=length(methods))
  for(i in 1:nrow(overlap.lncRNA)){
    for(j in 1:ncol(overlap.lncRNA)){
      overlap.lncRNA[i,j] <- length(which(DE.indicator.lncRNA[,i]==1 & DE.indicator.lncRNA[,j]==1))
    }
  }
  colnames(overlap.lncRNA) <- methods.name
  rownames(overlap.lncRNA) <- methods.name
  
  non.overlap.lncRNA.A <- matrix(NA, ncol=length(methods), nrow=length(methods))
  for(i in 1:nrow(non.overlap.lncRNA.A)){
    for(j in 1:ncol(non.overlap.lncRNA.A)){
      non.overlap.lncRNA.A[i,j] <- length(which(DE.indicator.lncRNA[,i]==1 & DE.indicator.lncRNA[,j]==0))
    }
  }
  colnames(non.overlap.lncRNA.A) <- methods.name
  rownames(non.overlap.lncRNA.A) <- methods.name

  non.overlap.lncRNA.B <- t(non.overlap.lncRNA.A)

  overlap.lncRNA.prop <-overlap.lncRNA/(non.overlap.lncRNA.A+overlap.lncRNA+non.overlap.lncRNA.B)
  rownames(overlap.lncRNA.prop) <- methods.name
  colnames(overlap.lncRNA.prop) <- methods.name
  
  # number_of.SDE.lncRNA <- diag(overlap.lncRNA)
  # base.lncRNA <- overlap.lncRNA
  # for(i in 1:nrow(base.lncRNA)){
  #   for(j in 1:ncol(base.lncRNA)){
  #     base.lncRNA[i,j] <- min(number_of.SDE.lncRNA[i], number_of.SDE.lncRNA[j])
  #   }
  # }
  # overlap.prop.lncRNA <- overlap.lncRNA/base.lncRNA
  # rownames(overlap.prop.lncRNA) <- methods.name
  # colnames(overlap.prop.lncRNA) <- methods.name
  
  overlap.prop.lncRNA.2 <- overlap.lncRNA.prop
  diag(overlap.prop.lncRNA.2) <- NA
  mean.overlap.lncRNA <- apply( overlap.prop.lncRNA.2, 1, function(x) mean(x, na.rm=T))
  saveRDS(mean.overlap.lncRNA, "mean.overlap.prop.lncRNA.RData")
  
  
  library(reshape2)
  overlap.prop.lncRNA <- overlap.lncRNA.prop
  overlap.prop.lncRNA[lower.tri(overlap.prop.lncRNA, diag = T)] <- NA
  overlap.lncRNA.dat <- melt(overlap.prop.lncRNA, na.rm = TRUE)
  colnames(overlap.lncRNA.dat) <- c("X1", "X2", "value")
  overlap.lncRNA.dat$X1<- factor(overlap.lncRNA.dat$X1, levels = methods.name)
  overlap.lncRNA.dat$X2<- factor(overlap.lncRNA.dat$X2, levels = methods.name)
  overlap.lncRNA.dat <- overlap.lncRNA.dat[!is.na(overlap.lncRNA.dat$value),]
  overlap.lncRNA.dat[, "value"] <- round(overlap.lncRNA.dat[, "value"], 3)
  
  
  library(ggplot2)
  library("scales") 
  library(gridExtra)
  
  win.graph()
  pl1 <- ggplot(overlap.mRNA.dat, aes(X2, ordered(X1, levels=methods.name), fill = value))+
    geom_tile(aes(fill = value))+labs(title="mRNA")+
    scale_fill_gradientn(limit = c(0.3, 1), space = "Lab", colours = c("white", "blue"),
                         name="overlap proportion") +
    theme_minimal()+ # minimal theme
    theme(axis.text.x = element_text(angle = 45, vjust = 1, 
                                     size = 12, hjust = 1))+
    scale_x_discrete(breaks=methods.name, labels=methods.name)+
    scale_y_discrete(breaks=methods.name, labels=methods.name)+
    coord_fixed()+
    geom_text(aes(X2, X1, label = value), color = "black", size = 4) +
    theme(
      axis.title.x = element_blank(),
      axis.title.y = element_blank(),
      panel.grid.major = element_blank(),
      panel.border = element_blank(),
      panel.background = element_blank(),
      axis.ticks = element_blank(),
      legend.justification = c(1, 0),
      legend.position = c(0.6, 0.7),
      legend.direction = "horizontal")+
    guides(fill = guide_colorbar(barwidth = 7, barheight = 1,
                                 title.position = "top", title.hjust = 0.5))
  pl2 <- ggplot(overlap.lncRNA.dat, aes(X2, ordered(X1, levels=methods.name), fill = value))+
    geom_tile(aes(fill = value))+labs(title="lncRNA")+
    scale_fill_gradientn(limit = c(0.3, 1), space = "Lab", colours = c("white", "blue"),
                         name="overlap proportion") +
    theme_minimal()+ # minimal theme
    theme(axis.text.x = element_text(angle = 45, vjust = 1, 
                                     size = 12, hjust = 1))+
    scale_x_discrete(breaks=methods.name, labels=methods.name)+
    scale_y_discrete(breaks=methods.name, labels=methods.name)+
    coord_fixed()+
    geom_text(aes(X2, X1, label = value), color = "black", size = 4) +
    theme(
      axis.title.x = element_blank(),
      axis.title.y = element_blank(),
      panel.grid.major = element_blank(),
      panel.border = element_blank(),
      panel.background = element_blank(),
      axis.ticks = element_blank(),
      legend.justification = c(1, 0),
      legend.position = c(0.6, 0.7),
      legend.direction = "horizontal")+
    guides(fill = guide_colorbar(barwidth = 7, barheight = 1,
                                 title.position = "top", title.hjust = 0.5))
  grid.arrange(pl1, pl2, ncol=2)
  
  #------------------------------------------------------------------------#
  #ANALYSIS OF LFC
  columns <- paste(methods,".", "logFC", sep="")
  LFC.matrix <- summary.all[,c(columns)]
  colnames(LFC.matrix) <- methods.name
  LFC.matrix <- as.data.frame(lapply(LFC.matrix, function(x) replace(x, is.infinite(x),NA)))
  rownames(LFC.matrix) <- rownames(summary.all)
  
  #Correlation b/n LFC estimates from each method
  ## mRNA
  cor.lfc.mRNA <- cor(LFC.matrix[which(rownames(LFC.matrix) %in% mRNA),-13], 
                      method ="pearson", use="pairwise.complete.obs")
  rownames(cor.lfc.mRNA) <- colnames(cor.lfc.mRNA) <- methods.name[-13]
  cor.lfc.mRNA.2 <- cor.lfc.mRNA
  diag(cor.lfc.mRNA.2) <- NA
  mean.cor.lfc.mRNA <- apply(cor.lfc.mRNA.2, 1, function(x) mean(x, na.rm=T))
  names(mean.cor.lfc.mRNA) <- methods.name[-13]
  saveRDS(mean.cor.lfc.mRNA, "mean.lfc.cor.mRNA.RData")
  
  
  library(reshape2)
  cor.lfc.mRNA[lower.tri(cor.lfc.mRNA, diag = T)] <- NA
  cor.lfc.dat.mRNA <- melt(cor.lfc.mRNA, na.rm = TRUE)
  colnames(cor.lfc.dat.mRNA) <- c("X1", "X2", "value")
  cor.lfc.dat.mRNA$X1<- factor(cor.lfc.dat.mRNA$X1, levels = methods.name[-13])
  cor.lfc.dat.mRNA$X2<- factor(cor.lfc.dat.mRNA$X2, levels = methods.name[-13])
  cor.lfc.dat.mRNA <- cor.lfc.dat.mRNA[!is.na(cor.lfc.dat.mRNA$value),]
  cor.lfc.dat.mRNA[, "value"] <- round(cor.lfc.dat.mRNA[, "value"], 3)
  
  ## lncRNA
  cor.lfc.lncRNA <- cor(LFC.matrix[which(rownames(LFC.matrix) %in% lncRNA),-13], 
                        method ="pearson", use="pairwise.complete.obs")
  rownames(cor.lfc.lncRNA) <- colnames(cor.lfc.lncRNA) <- methods.name[-13]
  cor.lfc.lncRNA.2 <- cor.lfc.lncRNA
  diag(cor.lfc.lncRNA.2) <- NA
  mean.cor.lfc.lncRNA <- apply(cor.lfc.lncRNA.2, 1, function(x) mean(x, na.rm=T))
  names(mean.cor.lfc.lncRNA) <- methods.name[-13]
  saveRDS(mean.cor.lfc.lncRNA, "mean.lfc.cor.lncRNA.RData")
  
  
  library(reshape2)
  cor.lfc.lncRNA[lower.tri(cor.lfc.lncRNA, diag = T)] <- NA
  cor.lfc.dat.lncRNA <- melt(cor.lfc.lncRNA, na.rm = TRUE)
  colnames(cor.lfc.dat.lncRNA) <- c("X1", "X2", "value")
  cor.lfc.dat.lncRNA$X1<- factor(cor.lfc.dat.lncRNA$X1, levels = methods.name[-13])
  cor.lfc.dat.lncRNA$X2<- factor(cor.lfc.dat.lncRNA$X2, levels = methods.name[-13])
  cor.lfc.dat.lncRNA <- cor.lfc.dat.lncRNA[!is.na(cor.lfc.dat.lncRNA$value),]
  cor.lfc.dat.lncRNA[, "value"] <- round(cor.lfc.dat.lncRNA[, "value"], 3)
  
  
  
  library(ggplot2)
  library("scales") 
  library(gridExtra)
  
  win.graph()
  pl1 <- ggplot(cor.lfc.dat.mRNA, aes(X2, ordered(X1, levels=methods.name[-13]), fill = value))+
    geom_tile(aes(fill = value))+labs(title="mRNA")+
    scale_fill_gradientn(limit = c(0.8, 1), space = "Lab", colours = c("white", "blue"),
                         name="Pearson correlation \n between LFC estimates") +
    theme_minimal()+ # minimal theme
    theme(axis.text.x = element_text(angle = 45, vjust = 1, 
                                     size = 12, hjust = 1))+
    scale_x_discrete(breaks=methods.name[-13], labels=methods.name[-13])+
    scale_y_discrete(breaks=methods.name[-13], labels=methods.name[-13])+
    coord_fixed()+
    geom_text(aes(X2, X1, label = value), color = "black", size = 4) +
    theme(
      axis.title.x = element_blank(),
      axis.title.y = element_blank(),
      panel.grid.major = element_blank(),
      panel.border = element_blank(),
      panel.background = element_blank(),
      axis.ticks = element_blank(),
      legend.justification = c(1, 0),
      legend.position = c(0.6, 0.7),
      legend.direction = "horizontal")+
    guides(fill = guide_colorbar(barwidth = 7, barheight = 1,
                                 title.position = "top", title.hjust = 0.5))
  pl2 <- ggplot(cor.lfc.dat.lncRNA, aes(X2, ordered(X1, levels=methods.name[-13]), fill = value))+
    geom_tile(aes(fill = value))+labs(title="lncRNA")+
    scale_fill_gradientn(limit = c(0.8, 1), space = "Lab", colours = c("white", "blue"),
                         name="Pearson correlation \n between LFC estimates") +
    theme_minimal()+ # minimal theme
    theme(axis.text.x = element_text(angle = 45, vjust = 1, 
                                     size = 12, hjust = 1))+
    scale_x_discrete(breaks=methods.name[-13], labels=methods.name[-13])+
    scale_y_discrete(breaks=methods.name[-13], labels=methods.name[-13])+
    coord_fixed()+
    geom_text(aes(X2, X1, label = value), color = "black", size = 4) +
    theme(
      axis.title.x = element_blank(),
      axis.title.y = element_blank(),
      panel.grid.major = element_blank(),
      panel.border = element_blank(),
      panel.background = element_blank(),
      axis.ticks = element_blank(),
      legend.justification = c(1, 0),
      legend.position = c(0.6, 0.7),
      legend.direction = "horizontal")+
    guides(fill = guide_colorbar(barwidth = 7, barheight = 1,
                                 title.position = "top", title.hjust = 0.5))
  
  grid.arrange(pl1, pl2, ncol=2)
  
 
  #-------------------------------------------------------------------------
  #Computational time
  comput.time <- sapply(results.full, function(x) x$time)[3, ]
  names(comput.time) <- methods.name
  saveRDS(comput.time, "comput.time.RData")
 

##############################################################################################################################################################

#Concordance Analysis based on Hammer data

  ###### Set working directory
  setwd('Hammer')
 

  ##### Loading annotated and processed data
  read <- readRDS("Hammer_Data.RData")
  counts <- read$counts
  group <- read$group
  counts <- counts[which(rowSums(counts[, group == levels(group)[1]]) > 0 &
                           rowSums(counts[, group == levels(group)[2]]) > 0),]
  dim(counts)
  #15908 mRNA genes are selected
  
  ### Exploratory Data Analysis 
  #Library size
  colSums(counts)
  
  #Correlation summary
  cor.summary <- function(counts, group){
    group <- as.factor(group)
    counts <- counts[, c(which(group == levels(group)[1]), 
                         which(group == levels(group)[2]))]
    
    WC1 <- cor(counts[, which(group == levels(group)[1])])
    WC1 <- WC1[lower.tri(WC1, diag = FALSE)]
    WC2 <- cor(counts[, which(group == levels(group)[2])])
    WC2 <- WC2[lower.tri(WC2, diag = FALSE)]
    
    WC.summary <- quantile(c(WC1, WC2), prob=c(0, 0.25, 0.5, 0.75, 1))
    
    BC <- cor(counts)[1:length(which(group == levels(group)[1])),
                      (length(which(group == levels(group)[1]))+1):length(group)]
    BC <- BC[lower.tri(BC, diag = FALSE)]
    BC.summary <- quantile(BC, prob=c(0, 0.25, 0.5, 0.75, 1))
    
    return(list(within.cor=WC.summary, between.cor =BC.summary ))
  }
  cor.summary(counts, group)
  
  #Exolring biological coefficient of variability (BCV) using edgeR
  library(edgeR)
  win.graph()
  y <- DGEList(counts=counts, group=group)
  y <- calcNormFactors(y)
  design <- model.matrix(~group)
  y <- estimateCommonDisp(y, design)
  y <- estimateGLMCommonDisp(y, design, verbose=TRUE)
  y <- estimateGLMTrendedDisp(y, design)
  y <- estimateGLMTagwiseDisp(y, design)
  plotBCV(y, ylim=c(0, 6), main="Hammer (mRNA)", cex.lab=1.5)
  text(7, 4, "Common Dispersion = 0.011 \n Common BCV = 0.104", cex=1.5, col=2)
  
  
  #MDS plot
  library(edgeR)
  y <- DGEList(counts=counts, group=group)
  y <- calcNormFactors(y)
  par(bg = 'gray88')
  rect(par("usr")[1], par("usr")[3], par("usr")[2], par("usr")[4], col = 
         "grey88")
  plotMDS(y, method="bcv", col=as.numeric(y$samples$group), panel.first=grid(col = "white", lty=1), bg="gray88")
  legend("bottomleft", as.character(unique(y$samples$group)), col=1:3, pch=20)
  
  
  ###Running DGE analysis
  ###### Set analysis output object
  results.full <- list()
  
  # edgeR - classic
  results.full["edgeR_classic"] <- list(runedgeR_classic(count.dat=counts, conditions=group,
                                                         colors=colors,path=outputpath))
  # edgeR - glm
  results.full["edgeR_glm"] <- list(runedgeR_glm(count.dat=counts, conditions=group,
                                                 colors=colors,path=outputpath))
  # edgeR - robust 
  results.full["edgeR_rob"] <- list(runedgeR_rob(count.dat=counts, conditions=group,
                                                 colors=colors,path=outputpath))
  # edgeR - quasi-likelihood 
  results.full["edgeR_ql"] <- list(runedgeR_ql(count.dat=counts, conditions=group,
                                               colors=colors,path=outputpath))
  
  # DESeq
  results.full["DESeq"] <- list(runDESeq(count.dat=counts, conditions=group,
                                         colors=colors,path=outputpath))
  # DESeq2
  results.full["DESeq2"] <- list(runDESeq2(count.dat=counts, conditions=group,
                                           colors=colors,path=outputpath))
  # Limma + quantile normalization
  results.full["LimmaQN"] <- list(runLimmaQN(count.dat=counts, conditions=group,
                                             colors=colors,path=outputpath))
  # LimmaVoom (without quality weights)
  results.full["LimmaVoom"] <- list(runLimmaVoom(count.dat=counts, conditions=group,
                                                 colors=colors,path=outputpath))
  # LimmaVoom (with quality weights)
  results.full["LimmaVoom_QW"] <- list(runLimmaVoom_QW(count.dat=counts, conditions=group,
                                                       colors=colors,path=outputpath))
  # LimmaVst 
  results.full["LimmaVst"] <- list(runLimmaVst(count.dat=counts, conditions=group,
                                               colors=colors,path=outputpath))
  # BaySeq
  results.full["BaySeq"] <- list(runBaySeq(count.dat=counts, conditions=group,
                                           colors=colors,path=outputpath))
  
  # PoissonSeq -> Note: pass adapted cut-off to method if required
  results.full["PoissonSeq"] <- list(runPoissonSeq(count.dat=counts, conditions=group,
                                                   colors=colors,path=outputpath))
  # SAMSeq
  results.full["SAMSeq"] <- list(runSAMSeq(count.dat=counts, conditions=group,
                                           colors=colors,path=outputpath))
  
  # QuasiSeq
  results.full["QuasiSeq"] <- list(runQuasiSeq(count.dat=counts, conditions=group,
                                               colors=colors,path=outputpath))
  
  
  #Saving result
  saveRDS(results.full, file="result_full_Hammer.RData")
  
  
  
  ###Concordance Analysis between DE tools 
  #Loading saved result of CRC AZA analysis
  results.full <- readRDS("result_full_Hammer.RData")
  methods <- names(results.full)
  
  ## organaizing results
  library(DESeq)
  cds <- DESeq::newCountDataSet(counts, group)
  cds <- DESeq::estimateSizeFactors(cds)
  norm.counts <- counts(cds, normalized=TRUE)
  
  classical.LFC.estimates <- data.frame(classical.LFC = apply(norm.counts, 1, function(x) {
    mu.g1 <- mean(x[group==levels(group)[1]])
    mu.g2 <- mean(x[group==levels(group)[2]])
    if(mu.g1 != 0 & mu.g2 != 0) {lfc <- log2(mu.g2/mu.g1)}
    else if(mu.g1 != 0 & mu.g2 == 0) {lfc <- -log2(mu.g1)}
    else if(mu.g1 == 0 & mu.g2 != 0) {lfc <- log2(mu.g2)}
    return(lfc) }))
  classical.LFC.estimates$ID <- rownames(classical.LFC.estimates)
  
  Merge.DE.results <- function(results.full, na.treat ="keep"){
    #A function that returns the rank of genes for all methods 
    methods <-  names(results.full)
    
    df1 <- results.full[1][[paste(methods[1])]]$summary
    df1 <- merge(df1, classical.LFC.estimates, by="ID", all.x=T, all.y=T)
    df1$pval[is.na(df1$pval)] <- 1
    df1$signed.pval <- sign(df1$classical.LFC)*(df1$pval+1e-5)  #A constant +1e-5 is added to each pvalues to avoid 0 signed p-value when p-value is 0
    df1$pi.score <- abs(df1$classical.LFC)*(-log10(df1$pval+1e-5))
    
    df2 <- results.full[2][[paste(methods[2])]]$summary
    df2 <- merge(df2, classical.LFC.estimates, by="ID", all.x=T, all.y=T)
    df2$pval[is.na(df2$pval)] <- 1
    df2$signed.pval <- sign(df2$classical.LFC)*(df2$pval+1e-5)
    df2$pi.score <- abs(df2$classical.LFC)*(-log10(df2$pval+1e-5))
    
    
    summary.all <- merge(df1, df2, by ="ID", all.x=T, all.y=T)
    colnames(summary.all) <- c("ID", paste(methods[1],".", c(colnames(df1)), sep="")[-1], 
                               paste(methods[2],".", c(colnames(df2)), sep="")[-1])
    
    for(i in 3:length(methods)){
      df.i <- results.full[i][[paste(methods[i])]]$summary
      df.i <- merge(df.i, classical.LFC.estimates, by="ID", all.x=T, all.y=T)
      df.i$pval[is.na(df.i$pval)] <- 1
      
      if(methods[i] != "SAMSeq"){
        df.i$signed.pval <- sign(df.i$classical.LFC)*(df.i$pval+1e-5)
        df.i$pi.score <- abs(df.i$classical.LFC)*(-log10(df.i$pval+1e-5))
      }
      
      if(methods[i] == "SAMSeq"){
        df.i$stat[is.na(df.i$stat)] <- 0
        df.i$signed.pval <- sign(df.i$classical.LFC)*(1/abs(df.i$stat+1e-5))
        df.i$pi.score <- abs(df.i$classical.LFC)*(-log10(1/abs(df.i$stat+1e-5)))
      }
      colnames(df.i) <- c("ID", paste(methods[i], ".", colnames(df.i), sep="")[-1])
      
      summary.all <- merge(summary.all, df.i, by ="ID", all.x=T, all.y=T)
      #colnames(summary.all) <- c("ID", methods[1:i])
    }
    
    rownames(summary.all) <- summary.all$ID
    summary.all <- summary.all[,-1]
    
    return(summary.all)
  }
  
  
  #Merging summary results of all the methods
  summary.all <- Merge.DE.results(results.full)
  dim(summary.all)
  
  methods.name <- c("edgeR exact", "edgeR GLM", "edgeR robust", "edgeR QL", "DESeq", "DESeq2", "limmaQN", "limmaVoom", "limmaVoom + QW", "limmaVst", 
                    "baySeq", "PoissonSeq", "SAMSeq", "QuasiSeq")
  
  
  #------------------------------------------------------------------------#
  #GENE RANK ANALYSIS 
  #Spearman's Rank Correlation Matrix
  #columns <- paste(methods,".", "signed.pval", sep="")
  columns <- paste(methods,".", "pi.score", sep="")
  score.matrix <- summary.all[,c(columns)]
  colnames(score.matrix) <- methods.name
  
  #classical LFC estimates
  columns <- paste(methods,".", "classical.LFC", sep="")
  LFC.matrix <- summary.all[,c(columns)]
  colnames(LFC.matrix) <- methods.name
  LFC.matrix <- as.data.frame(lapply(LFC.matrix, function(x) replace(x, is.infinite(x),NA)))
  rownames(LFC.matrix) <- rownames(summary.all)
  
  
  #subsetting the top commonly identifed SDE genes across methods
  columns <- paste(methods,".", "padj", sep="")
  padj.matrix <- summary.all[,c(columns)]
  padj.matrix[is.na(padj.matrix)] = 1   #replacing NA values by 1
  colnames(padj.matrix) <- methods.name
  
  common.SDE.genes <- names(which(apply(padj.matrix, 1, function(x) {
    if(max(x) < 1) {return(1)}
    else {return(0)}}) == 1))
  length(common.SDE.genes)
  
  #Rank correlation, ranks scores and if there are ties, it uses auxillary information to break ties
  rank.cov <- function(y, x=NULL, na.last=TRUE, ties.method="average"){
    r <- y
    if(is.null(x)) {r <- rank(y, na.last=na.last, ties.method=ties.method)}
    else if(!is.null(x)){
      r.temp <- rank(y, na.last=na.last, ties.method="min")
      t.r <- table(r.temp)
      ties <- as.numeric(names(which(t.r>1)))
      if(length(ties)>=1) {
        for(i in 1:length(ties)){
          r.cov <- rank(x[r.temp==ties[i]])-1
          r.temp[r.temp==ties[i]] <- r.temp[r.temp==ties[i]] + r.cov
        }
      }
      else{
        r.temp <- rank(y, na.last=na.last, ties.method=ties.method)
      }
      r <- r.temp 
    }
    return(r)
  }
  
  rank.matrix <- apply(score.matrix, 2, function(v){
    rank.cov(v, x=LFC.matrix[,1])
  })
  
  rank.matrix <- rank.matrix[common.SDE.genes, ]
  
  cor.rank <- round(cor(rank.matrix, use = "pairwise.complete.obs", method ="spearman"), 3)
  cor.rank.2 <- cor.rank
  diag(cor.rank.2) <- NA
  mean.cor <- apply(cor.rank.2, 1, function(x) mean(x, na.rm=T))
  saveRDS(mean.cor, "mean.rank.cor.RData")
  
  cor.rank[lower.tri(cor.rank, diag = T)] <- NA
  cor.rank
  
  
  
  library(reshape2)
  cor.dat <- melt(cor.rank, na.rm = TRUE)
  colnames(cor.dat) <- c("X1", "X2", "value")
  cor.dat$X1<- factor(cor.dat$X1, levels = methods.name)
  cor.dat$X2<- factor(cor.dat$X2, levels = methods.name)
  cor.dat <- cor.dat[!is.na(cor.dat$value),]
  
  library(ggplot2)
  library("scales") 
  
  win.graph()
  ggplot(cor.dat, aes(X2, ordered(X1, levels=methods.name), fill = value))+
    geom_tile(aes(fill = value))+
    scale_fill_gradientn(limit = c(0.9, 1), space = "Lab", colours = c("white", "blue"),
                         name="Spearman\nCorrelation") +
    theme_minimal()+ # minimal theme
    theme(axis.text.x = element_text(angle = 45, vjust = 1, 
                                     size = 12, hjust = 1))+
    scale_x_discrete(breaks=methods.name, labels=methods.name)+
    scale_y_discrete(breaks=methods.name, labels=methods.name)+
    coord_fixed()+
    geom_text(aes(X2, X1, label = value), color = "black", size = 4) +
    theme(
      axis.title.x = element_blank(),
      axis.title.y = element_blank(),
      panel.grid.major = element_blank(),
      panel.border = element_blank(),
      panel.background = element_blank(),
      axis.ticks = element_blank(),
      legend.justification = c(1, 0),
      legend.position = c(0.6, 0.7),
      legend.direction = "horizontal")+
    guides(fill = guide_colorbar(barwidth = 7, barheight = 1,
                                 title.position = "top", title.hjust = 0.5))
  
  
  #------------------------------------------------------------------------#
  #ANALYSIS OF NUMBER OF DE GENES and CLLASSIFICATION OVERLAPPING
  columns <- paste(methods,".", "padj", sep="")
  padj.matrix <- summary.all[,c(columns)]
  colnames(padj.matrix) <- methods
  
  DE.indicator <- padj.matrix
  for(i in 1:nrow(padj.matrix)){
    for(j in 1:ncol(padj.matrix)){
      if(padj.matrix[i,j] < 0.05 & is.na(padj.matrix[i,j]) == F) DE.indicator[i,j] <- 1
      else if(padj.matrix[i,j] >= 0.05 & is.na(padj.matrix[i,j]) == F) DE.indicator[i,j] <- 0
    }
  }
  
  avgExp <- rowMeans(norm.counts)
  q <- quantile(avgExp, prob=c(0.25, 0.5, 0.75))
  q
  #     25%        50%        75% 
  #43.72581 282.92268 965.98144
  
  avgExp.cat <- NULL
  avgExp.cat[avgExp<=q[1]] <- "Q1"
  avgExp.cat[avgExp>q[1] & avgExp<=q[2]] <- "Q2"
  avgExp.cat[avgExp>q[2] & avgExp<=q[3]] <- "Q3"
  avgExp.cat[avgExp>q[3]] <- "Q4"
  avgExp.cat[is.na(avgExp)] <- NA
  
  library(reshape)
  DE.indicator2 <- melt(DE.indicator)
  DE.indicator2 <- data.frame(DE.indicator2, avgExp.cat =rep(avgExp.cat, times=length(methods)))
  colnames(DE.indicator2) <- c("Methods", "DE", "GE.Category")
  
  
  agr <- aggregate(DE~Methods+GE.Category, data=DE.indicator2, FUN=sum)
  agr.all <- aggregate(DE~Methods, data=DE.indicator2, FUN=sum)
  agr.all$Methods <- agr$Methods <- methods.name
  saveRDS(list(agr.all=agr.all, agr=agr), "SDE.summary.RData")
  
  library(ggplot2)
  library(gridExtra)
  win.graph()
  pl1 <- ggplot(agr[order(agr$GE.Category, decreasing = F),], 
                aes(x=reorder(Methods, DE), y=DE, fill=GE.Category)) + 
    geom_bar(stat="identity", position = "stack")+ 
    theme(axis.text.x = element_text(angle = 45, hjust = 1), 
          legend.position=c(0.1, 0.8)) + 
    scale_x_discrete(breaks=methods.name, labels=methods.name)+
    labs(title="A", x="DE tools", y="mumber of SDE genes (at 5% FDR)",
         fill="Quartiles")
  
  pl2 <- ggplot(agr,  aes(x=Methods, y=DE, fill=GE.Category)) + 
    geom_bar(stat="identity", position = "fill")+
    theme(axis.text.x = element_text(angle = 45, hjust = 1), legend.position='none') + 
    scale_x_discrete(breaks=methods.name, labels=methods.name)+
    labs(title="B", x="DE tools", y="proportion")
  grid.arrange(pl1, pl2, ncol=2)
  
  
  #Overlapping of DE classification
  overlap <- matrix(NA, ncol=length(methods), nrow=length(methods))
  for(i in 1:nrow(overlap)){
    for(j in 1:ncol(overlap)){
      overlap[i,j] <- length(which(DE.indicator[,i]==1 & DE.indicator[,j]==1))
    }
  }
  colnames(overlap) <- methods.name
  rownames(overlap) <- methods.name
  
  non.overlap.A <- matrix(NA, ncol=length(methods), nrow=length(methods))
  for(i in 1:nrow(non.overlap.A)){
    for(j in 1:ncol(non.overlap.A)){
      non.overlap.A[i,j] <- length(which(DE.indicator[,i]==1 & DE.indicator[,j]==0))
    }
  }
  colnames(non.overlap.A) <- methods
  rownames(non.overlap.A) <- methods

  non.overlap.B <- matrix(NA, ncol=length(methods), nrow=length(methods))
  for(i in 1:nrow(non.overlap.B)){
    for(j in 1:ncol(non.overlap.B)){
      non.overlap.B[i,j] <- length(which(DE.indicator[,i]==0 & DE.indicator[,j]==1))
    }
  }
  colnames(non.overlap.B) <- methods
  rownames(non.overlap.B) <- methods

  overlap.prop <-overlap/(non.overlap.A+overlap+non.overlap.B)
  rownames(overlap.prop) <- methods.name
  colnames(overlap.prop) <- methods.name
  
  # number_of.SDE <- diag(overlap)
  # base <- overlap
  # for(i in 1:nrow(base)){
  #   for(j in 1:ncol(base)){
  #     base[i,j] <- min(number_of.SDE[i], number_of.SDE[j])
  #   }
  # }
  # overlap.prop <- overlap/base
  # rownames(overlap.prop) <- methods.name
  # colnames(overlap.prop) <- methods.name
  
  overlap.prop.2 <- overlap.prop
  diag(overlap.prop.2) <- NA
  mean.overlap <- apply(overlap.prop.2, 1, function(x) mean(x, na.rm=T))
  saveRDS(mean.overlap, "mean.overlap.prop.RData")
  
  
  library(reshape2)
  overlap.prop[lower.tri(overlap.prop, diag = T)] <- NA
  overlap.dat <- melt(overlap.prop, na.rm = TRUE)
  colnames(overlap.dat) <- c("X1", "X2", "value")
  overlap.dat$X1<- factor(overlap.dat$X1, levels = methods.name)
  overlap.dat$X2<- factor(overlap.dat$X2, levels = methods.name)
  overlap.dat <- overlap.dat[!is.na(overlap.dat$value),]
  overlap.dat[, "value"] <- round(overlap.dat[, "value"], 3)
  
  library(ggplot2)
  library("scales") 
  
  win.graph()
  ggplot(overlap.dat, aes(X2, ordered(X1, levels=methods.name), fill = value))+
    geom_tile(aes(fill = value))+
    scale_fill_gradientn(limit = c(0.35, 1), space = "Lab", colours = c("white", "blue"),
                         name="overlap proportion") +
    theme_minimal()+ # minimal theme
    theme(axis.text.x = element_text(angle = 45, vjust = 1, 
                                     size = 12, hjust = 1))+
    scale_x_discrete(breaks=methods.name, labels=methods.name)+
    scale_y_discrete(breaks=methods.name, labels=methods.name)+
    coord_fixed()+
    geom_text(aes(X2, X1, label = value), color = "black", size = 4) +
    theme(
      axis.title.x = element_blank(),
      axis.title.y = element_blank(),
      panel.grid.major = element_blank(),
      panel.border = element_blank(),
      panel.background = element_blank(),
      axis.ticks = element_blank(),
      legend.justification = c(1, 0),
      legend.position = c(0.6, 0.7),
      legend.direction = "horizontal")+
    guides(fill = guide_colorbar(barwidth = 7, barheight = 1,
                                 title.position = "top", title.hjust = 0.5))
  
  #------------------------------------------------------------------------#
  #ANALYSIS OF LFC
  columns <- paste(methods,".", "logFC", sep="")
  LFC.matrix <- summary.all[,c(columns)]
  colnames(LFC.matrix) <- methods.name
  LFC.matrix <- as.data.frame(lapply(LFC.matrix, function(x) replace(x, is.infinite(x),NA)))
  rownames(LFC.matrix) <- rownames(summary.all)
  
  ## Correlation b/n LFC estimates from each method
  cor.lfc <- cor(LFC.matrix[-13], method ="pearson", use="pairwise.complete.obs")
  rownames(cor.lfc) <- colnames(cor.lfc) <- methods.name[-13]
  cor.lfc.2 <- cor.lfc
  diag(cor.lfc.2) <- NA
  mean.cor.lfc <- apply(cor.lfc.2, 1, function(x) mean(x, na.rm=T))
  names(mean.cor.lfc) <- methods.name[-13]
  saveRDS(mean.cor.lfc, "mean.lfc.cor.RData")
  
  
  library(reshape2)
  cor.lfc[lower.tri(cor.lfc, diag = T)] <- NA
  cor.lfc.dat <- melt(cor.lfc, na.rm = TRUE)
  colnames(cor.lfc.dat) <- c("X1", "X2", "value")
  cor.lfc.dat$X1<- factor(cor.lfc.dat$X1, levels = methods.name[-13])
  cor.lfc.dat$X2<- factor(cor.lfc.dat$X2, levels = methods.name[-13])
  cor.lfc.dat <- cor.lfc.dat[!is.na(cor.lfc.dat$value),]
  cor.lfc.dat[, "value"] <- round(cor.lfc.dat[, "value"], 3)
  
  
  library(ggplot2)
  library("scales") 
  
  win.graph()
  ggplot(cor.lfc.dat, aes(X2, ordered(X1, levels=methods.name[-13]), fill = value))+
    geom_tile(aes(fill = value))+
    scale_fill_gradientn(limit = c(0.9, 1), space = "Lab", colours = c("white", "blue"),
                         name="Pearson correlation \n between LFC estimates") +
    theme_minimal()+ # minimal theme
    theme(axis.text.x = element_text(angle = 45, vjust = 1, 
                                     size = 12, hjust = 1))+
    scale_x_discrete(breaks=methods.name[-13], labels=methods.name[-13])+
    scale_y_discrete(breaks=methods.name[-13], labels=methods.name[-13])+
    coord_fixed()+
    geom_text(aes(X2, X1, label = value), color = "black", size = 4) +
    theme(
      axis.title.x = element_blank(),
      axis.title.y = element_blank(),
      panel.grid.major = element_blank(),
      panel.border = element_blank(),
      panel.background = element_blank(),
      axis.ticks = element_blank(),
      legend.justification = c(1, 0),
      legend.position = c(0.6, 0.7),
      legend.direction = "horizontal")+
    guides(fill = guide_colorbar(barwidth = 7, barheight = 1,
                                 title.position = "top", title.hjust = 0.5))
  
  #Scatter plots between LFC estimates of selected DE tools, 
  # with partitioning genes into 4 different abundance levels (quartiles)
  methods2 <- methods[c(1,5, 6,8,11, 12)]
  methods.name2 <- methods.name[c(1,5, 6,8,11, 12)]
  LFC.matrix2 <- LFC.matrix[, c(1,5, 6,8,11, 12)]
  LFC.matrix2$avgExp.cat <- avgExp.cat
  pairs <- t(combn(length(methods2), 2))  [c(2,3,6,7,10,11,12,13,14),]
  cols <- c("dodgerblue4", "firebrick4", "goldenrod4", "mediumseagreen")
  win.graph()
  par(mfrow=c(3,3))
  for(i in 1:nrow(pairs)){
    plot(LFC.matrix2[,pairs[i,1]], LFC.matrix2[, pairs[i,2]], type="n", xlab=paste0(methods.name2[pairs[i,1]]), ylab=paste0(methods.name2[pairs[i,2]]),
         xlim=c(-4, 15), ylim=c(-4, 15))
    points(LFC.matrix2[LFC.matrix2$avgExp.cat =="Q1",pairs[i,1]], LFC.matrix2[LFC.matrix2$avgExp.cat =="Q1",pairs[i,2]], pch=6, col=cols[1])
    points(LFC.matrix2[LFC.matrix2$avgExp.cat =="Q2",pairs[i,1]], LFC.matrix2[LFC.matrix2$avgExp.cat =="Q2",pairs[i,2]], pch=1, col=cols[2])
    points(LFC.matrix2[LFC.matrix2$avgExp.cat =="Q3",pairs[i,1]], LFC.matrix2[LFC.matrix2$avgExp.cat =="Q3",pairs[i,2]], pch=0, col=cols[3])
    points(LFC.matrix2[LFC.matrix2$avgExp.cat =="Q4",pairs[i,1]], LFC.matrix2[LFC.matrix2$avgExp.cat =="Q4",pairs[i,2]], pch=17, col=cols[4])
    abline(0,1, lty=2, lwd=2)
    legend("topleft", c(paste0("Q1 ", "(r=", round(cor(LFC.matrix2[LFC.matrix2$avgExp.cat =="Q1",pairs[i,1]], 
                                                       LFC.matrix2[LFC.matrix2$avgExp.cat =="Q1",pairs[i,2]], use = "pairwise.complete.obs"), 3), ")"),
                        paste0("Q2 ", "(r=", round(cor(LFC.matrix2[LFC.matrix2$avgExp.cat =="Q2",pairs[i,1]], 
                                                       LFC.matrix2[LFC.matrix2$avgExp.cat =="Q2",pairs[i,2]], use = "pairwise.complete.obs"), 3), ")"),
                        paste0("Q3 ", "(r=", round(cor(LFC.matrix2[LFC.matrix2$avgExp.cat =="Q3",pairs[i,1]], 
                                                       LFC.matrix2[LFC.matrix2$avgExp.cat =="Q3",pairs[i,2]], use = "pairwise.complete.obs"), 3), ")"),
                        paste0("Q4 ", "(r=", round(cor(LFC.matrix2[LFC.matrix2$avgExp.cat =="Q4",pairs[i,1]], 
                                                       LFC.matrix2[LFC.matrix2$avgExp.cat =="Q4",pairs[i,2]], use = "pairwise.complete.obs"), 3), ")")),
           pch=c(6, 1, 0, 17), col=cols, bty="n", cex=1.5, ncol=2)
  }
  
  
  #-------------------------------------------------------------------#
  #MA plots
  win.graph()
  par(mfrow=c(2,2))
  
  ##edgeR_classic
  x <- summary.all[,c("edgeR_classic.avgExpr", "edgeR_classic.logFC", "edgeR_classic.padj")]
  colnames(x) <- c("baseMean", "log2FoldChange", "padj" )
  x$avgExp.cat <- avgExp.cat
  plot(x$baseMean, x$log2FoldChange, col = ifelse(x$padj>=0.05, "gray32", "red3"), main="edgeR Exact",
       xlab = "mean of normalized counts", ylab = "LFC", log = "x", cex=0.45, ylim=c(-5, 15))
  abline(v=q, lty=2, col="darkcyan")
  abline(h=c(-1, 1), lty=2, col="darkcyan")
  text(c(1E01, 1.5E02, 0.5E03, 1E04), c(13, 13, 13, 13), c("Q1", "Q2", "Q3", "Q4"))
  text(c(2e05, 2e05), c(-1.75, 1.75), c("LFC = -1", "LFC =1"))
  legend("topright", c("Non SDE Genes", "SDE genes"), col=c("gray32", "red3"), pch=20, bty="n")
  ##DESeq2
  x <- summary.all[,c("edgeR_classic.avgExpr", "DESeq2.logFC", "DESeq2.padj")]
  colnames(x) <- c("baseMean", "log2FoldChange", "padj" )
  x$avgExp.cat <- avgExp.cat
  plot(x$baseMean, x$log2FoldChange, col = ifelse(x$padj>=0.05, "gray32", "red3"), main="DESeq2",
       xlab = "mean of normalized counts", ylab = "LFC", log = "x", cex=0.45, ylim=c(-5, 15))
  abline(v=q, lty=2, col="darkcyan")
  abline(h=c(-1, 1), lty=2, col="darkcyan")
  text(c(1E01, 1.5E02, 0.5E03, 1E04), c(13, 13, 13, 13), c("Q1", "Q2", "Q3", "Q4"))
  text(c(2e05, 2e05), c(-1.75, 1.75), c("LFC = -1", "LFC =1"))
  legend("topright", c("Non SDE Genes", "SDE genes"), col=c("gray32", "red3"), pch=20, bty="n")
  
  ##limmaVoom
  x <- summary.all[,c("edgeR_classic.avgExpr", "LimmaVoom.logFC", "LimmaVoom.padj")]
  colnames(x) <- c("baseMean", "log2FoldChange", "padj" )
  x$avgExp.cat <- avgExp.cat
  plot(x$baseMean, x$log2FoldChange, col = ifelse(x$padj>=0.05, "gray32", "red3"), main="limmaVoom",
       xlab = "mean of normalized counts", ylab = "LFC", log = "x", cex=0.45, ylim=c(-5, 15))
  abline(v=q, lty=2, col="darkcyan")
  abline(h=c(-1, 1), lty=2, col="darkcyan")
  text(c(1E01, 1.5E02, 0.5E03, 1E04), c(13, 13, 13, 13), c("Q1", "Q2", "Q3", "Q4"))
  text(c(2e05, 2e05), c(-1.75, 1.75), c("LFC = -1", "LFC =1"))
  legend("topright", c("Non SDE Genes", "SDE genes"), col=c("gray32", "red3"), pch=20, bty="n")
  
  ##PoissonSeq
  x <- summary.all[,c("edgeR_classic.avgExpr", "PoissonSeq.logFC", "PoissonSeq.padj")]
  colnames(x) <- c("baseMean", "log2FoldChange", "padj" )
  x$avgExp.cat <- avgExp.cat
  plot(x$baseMean, x$log2FoldChange, col = ifelse(x$padj>=0.05, "gray32", "red3"), main="PoissonSeq",
       xlab = "mean of normalized counts", ylab = "LFC", log = "x", cex=0.45, ylim=c(-5, 15))
  abline(v=q, lty=2, col="darkcyan")
  abline(h=c(-1, 1), lty=2, col="darkcyan")
  text(c(1E01, 1.5E02, 0.5E03, 1E04), c(13, 13, 13, 13), c("Q1", "Q2", "Q3", "Q4"))
  text(c(2e05, 2e05), c(-1.75, 1.75), c("LFC = -1", "LFC =1"))
  legend("topright", c("Non SDE Genes", "SDE genes"), col=c("gray32", "red3"), pch=20, bty="n")
  
  #-------------------------------------------------------------------------
  #Computational time
  comput.time <- sapply(results.full, function(x) x$time)[3, ]
  names(comput.time) <- methods.name
  saveRDS(comput.time, "comput.time.RData")


##############################################################################################################################################################

#Concordance Analysis based on Bottomly data

  
  
  ###### Set working directory
  setwd('Bottomly')
  
  ##### Loading annotated and processed data
  read <- readRDS("Bottomly_Data.RData")
  counts <- read$counts
  group <- read$group
  counts <- counts[which(rowSums(counts[, group == levels(group)[1]]) > 0 &
                           rowSums(counts[, group == levels(group)[2]]) > 0),]
  dim(counts)
  #12784 mRNA genes are selected
  
  ###Exploratory Data Analysis 
  
  #Correlation summary
  cor.summary <- function(counts, group){
    group <- as.factor(group)
    counts <- counts[, c(which(group == levels(group)[1]), 
                         which(group == levels(group)[2]))]
    
    WC1 <- cor(counts[, which(group == levels(group)[1])])
    WC1 <- WC1[lower.tri(WC1, diag = FALSE)]
    WC2 <- cor(counts[, which(group == levels(group)[2])])
    WC2 <- WC2[lower.tri(WC2, diag = FALSE)]
    
    WC.summary <- quantile(c(WC1, WC2), prob=c(0, 0.25, 0.5, 0.75, 1))
    
    BC <- cor(counts)[1:length(which(group == levels(group)[1])),
                      (length(which(group == levels(group)[1]))+1):length(group)]
    BC <- BC[lower.tri(BC, diag = FALSE)]
    BC.summary <- quantile(BC, prob=c(0, 0.25, 0.5, 0.75, 1))
    
    return(list(within.cor=WC.summary, between.cor =BC.summary ))
  }
  cor.summary(counts, group)
  
  #library size
  summary(colSums(counts))
  
  #Exolring biological coefficient of variability (BCV) using edgeR
  library(edgeR)
  win.graph()
  y <- DGEList(counts=counts, group=group)
  y <- calcNormFactors(y)
  design <- model.matrix(~group)
  y <- estimateCommonDisp(y, design)
  y <- estimateGLMCommonDisp(y, design, verbose=TRUE)
  y <- estimateGLMTrendedDisp(y, design)
  y <- estimateGLMTagwiseDisp(y, design)
  plotBCV(y, ylim=c(0, 6), main="Bottomly (mRNA)", cex.lab=1.5)
  text(7, 4, "Common Dispersion = 0.039 \n Common BCV = 0.197", cex=1.5, col=2)
  
  
  #MDS plot
  library(edgeR)
  y <- DGEList(counts=counts, group=group)
  y <- calcNormFactors(y)
  par(bg = 'gray88')
  rect(par("usr")[1], par("usr")[3], par("usr")[2], par("usr")[4], col = 
         "grey88")
  plotMDS(y, method="bcv", col=as.numeric(y$samples$group), panel.first=grid(col = "white", lty=1), bg="gray88")
  legend("bottomleft", as.character(unique(y$samples$group)), col=1:3, pch=20)
  
  
  ### Running DGE analysis 
  ###### Set analysis output object
  results.full <- list()
  
  # edgeR - classic
  results.full["edgeR_classic"] <- list(runedgeR_classic(count.dat=counts, conditions=group,
                                                         colors=colors,path=outputpath))
  # edgeR - glm
  results.full["edgeR_glm"] <- list(runedgeR_glm(count.dat=counts, conditions=group,
                                                 colors=colors,path=outputpath))
  # edgeR - robust 
  results.full["edgeR_rob"] <- list(runedgeR_rob(count.dat=counts, conditions=group,
                                                 colors=colors,path=outputpath))
  # edgeR - quasi-likelihood 
  results.full["edgeR_ql"] <- list(runedgeR_ql(count.dat=counts, conditions=group,
                                               colors=colors,path=outputpath))
  
  # DESeq
  results.full["DESeq"] <- list(runDESeq(count.dat=counts, conditions=group,
                                         colors=colors,path=outputpath))
  # DESeq2
  results.full["DESeq2"] <- list(runDESeq2(count.dat=counts, conditions=group,
                                           colors=colors,path=outputpath))
  # Limma + quantile normalization
  results.full["LimmaQN"] <- list(runLimmaQN(count.dat=counts, conditions=group,
                                             colors=colors,path=outputpath))
  # LimmaVoom (without quality weights)
  results.full["LimmaVoom"] <- list(runLimmaVoom(count.dat=counts, conditions=group,
                                                 colors=colors,path=outputpath))
  # LimmaVoom (with quality weights)
  results.full["LimmaVoom_QW"] <- list(runLimmaVoom_QW(count.dat=counts, conditions=group,
                                                       colors=colors,path=outputpath))
  # LimmaVst 
  results.full["LimmaVst"] <- list(runLimmaVst(count.dat=counts, conditions=group,
                                               colors=colors,path=outputpath))
  # BaySeq
  results.full["BaySeq"] <- list(runBaySeq(count.dat=counts, conditions=group,
                                           colors=colors,path=outputpath))
  
  # PoissonSeq 
  results.full["PoissonSeq"] <- list(runPoissonSeq(count.dat=counts, conditions=group,
                                                   colors=colors,path=outputpath))
  # SAMSeq
  results.full["SAMSeq"] <- list(runSAMSeq(count.dat=counts, conditions=group,
                                           colors=colors,path=outputpath))
  
  # QuasiSeq
  results.full["QuasiSeq"] <- list(runQuasiSeq(count.dat=counts, conditions=group,
                                               colors=colors,path=outputpath))
  
  #Saving result
  saveRDS(results.full, file="result_full_Bottomly.RData")
  
  
  
  ###Concordance Analysis between DE tools 
  #Loading saved result of CRC AZA analysis
  results.full <- readRDS("result_full_Bottomly.RData")
  methods <- names(results.full)
  
  ## organaizing results
  library(DESeq)
  cds <- DESeq::newCountDataSet(counts, group)
  cds <- DESeq::estimateSizeFactors(cds)
  norm.counts <- counts(cds, normalized=TRUE)
  
  classical.LFC.estimates <- data.frame(classical.LFC = apply(norm.counts, 1, function(x) {
    mu.g1 <- mean(x[group==levels(group)[1]])
    mu.g2 <- mean(x[group==levels(group)[2]])
    if(mu.g1 != 0 & mu.g2 != 0) {lfc <- log2(mu.g2/mu.g1)}
    else if(mu.g1 != 0 & mu.g2 == 0) {lfc <- -log2(mu.g1)}
    else if(mu.g1 == 0 & mu.g2 != 0) {lfc <- log2(mu.g2)}
    return(lfc) }))
  classical.LFC.estimates$ID <- rownames(classical.LFC.estimates)
  
  Merge.DE.results <- function(results.full, na.treat ="keep"){
    #A function that returns the rank of genes for all methods 
    methods <-  names(results.full)
    
    df1 <- results.full[1][[paste(methods[1])]]$summary
    df1 <- merge(df1, classical.LFC.estimates, by="ID", all.x=T, all.y=T)
    df1$pval[is.na(df1$pval)] <- 1
    df1$signed.pval <- sign(df1$classical.LFC)*(df1$pval+1e-5)  #A constant +1e-5 is added to each pvalues to avoid 0 signed p-value when p-value is 0
    df1$pi.score <- abs(df1$classical.LFC)*(-log10(df1$pval+1e-5))
    
    df2 <- results.full[2][[paste(methods[2])]]$summary
    df2 <- merge(df2, classical.LFC.estimates, by="ID", all.x=T, all.y=T)
    df2$pval[is.na(df2$pval)] <- 1
    df2$signed.pval <- sign(df2$classical.LFC)*(df2$pval+1e-5)
    df2$pi.score <- abs(df2$classical.LFC)*(-log10(df2$pval+1e-5))
    
    
    summary.all <- merge(df1, df2, by ="ID", all.x=T, all.y=T)
    colnames(summary.all) <- c("ID", paste(methods[1],".", c(colnames(df1)), sep="")[-1], 
                               paste(methods[2],".", c(colnames(df2)), sep="")[-1])
    
    for(i in 3:length(methods)){
      df.i <- results.full[i][[paste(methods[i])]]$summary
      df.i <- merge(df.i, classical.LFC.estimates, by="ID", all.x=T, all.y=T)
      df.i$pval[is.na(df.i$pval)] <- 1
      
      if(methods[i] != "SAMSeq"){
        df.i$signed.pval <- sign(df.i$classical.LFC)*(df.i$pval+1e-5)
        df.i$pi.score <- abs(df.i$classical.LFC)*(-log10(df.i$pval+1e-5))
      }
      
      if(methods[i] == "SAMSeq"){
        df.i$stat[is.na(df.i$stat)] <- 0
        df.i$signed.pval <- sign(df.i$classical.LFC)*(1/abs(df.i$stat+1e-5))
        df.i$pi.score <- abs(df.i$classical.LFC)*(-log10(1/abs(df.i$stat+1e-5)))
      }
      colnames(df.i) <- c("ID", paste(methods[i], ".", colnames(df.i), sep="")[-1])
      
      summary.all <- merge(summary.all, df.i, by ="ID", all.x=T, all.y=T)
      #colnames(summary.all) <- c("ID", methods[1:i])
    }
    
    rownames(summary.all) <- summary.all$ID
    summary.all <- summary.all[,-1]
    
    return(summary.all)
  }
  
  
  #Merging summary results of all the methods
  summary.all <- Merge.DE.results(results.full)
  dim(summary.all)
  
  methods.name <- c("edgeR exact", "edgeR GLM", "edgeR robust", "edgeR QL", "DESeq", "DESeq2", "limmaQN", "limmaVoom", "limmaVoom + QW", "limmaVst", 
                    "baySeq", "PoissonSeq", "SAMSeq", "QuasiSeq")
  
  
  
  #------------------------------------------------------------------------#
  #GENE RANK ANALYSIS 
  #Spearman's Rank Correlation Matrix
  #columns <- paste(methods,".", "signed.pval", sep="")
  columns <- paste(methods,".", "pi.score", sep="")
  score.matrix <- summary.all[,c(columns)]
  colnames(score.matrix) <- methods.name
  
  #classical LFC estimates
  columns <- paste(methods,".", "classical.LFC", sep="")
  LFC.matrix <- summary.all[,c(columns)]
  colnames(LFC.matrix) <- methods.name
  LFC.matrix <- as.data.frame(lapply(LFC.matrix, function(x) replace(x, is.infinite(x),NA)))
  rownames(LFC.matrix) <- rownames(summary.all)
  
  
  #subsetting the top commonly identifed SDE genes across methods
  columns <- paste(methods,".", "padj", sep="")
  padj.matrix <- summary.all[,c(columns)]
  padj.matrix[is.na(padj.matrix)] = 1   #replacing NA values by 1
  colnames(padj.matrix) <- methods.name
  
  common.SDE.genes <- names(which(apply(padj.matrix, 1, function(x) {
    if(max(x) < 1) {return(1)}
    else {return(0)}}) == 1))
  length(common.SDE.genes)
  
  #Rank correlation, ranks scores and if there are ties, it uses auxillary information to break ties
  rank.cov <- function(y, x=NULL, na.last=TRUE, ties.method="average"){
    r <- y
    if(is.null(x)) {r <- rank(y, na.last=na.last, ties.method=ties.method)}
    else if(!is.null(x)){
      r.temp <- rank(y, na.last=na.last, ties.method="min")
      t.r <- table(r.temp)
      ties <- as.numeric(names(which(t.r>1)))
      if(length(ties)>=1) {
        for(i in 1:length(ties)){
          r.cov <- rank(x[r.temp==ties[i]])-1
          r.temp[r.temp==ties[i]] <- r.temp[r.temp==ties[i]] + r.cov
        }
      }
      else{
        r.temp <- rank(y, na.last=na.last, ties.method=ties.method)
      }
      r <- r.temp 
    }
    return(r)
  }
  
  rank.matrix <- apply(score.matrix, 2, function(v){
    rank.cov(v, x=LFC.matrix[,1])
  })
  
  rank.matrix <- rank.matrix[common.SDE.genes, ]
  
  cor.rank <- round(cor(rank.matrix, use = "pairwise.complete.obs", method ="spearman"), 3)
  cor.rank.2 <- cor.rank
  diag(cor.rank.2) <- NA
  mean.cor <- apply(cor.rank.2, 1, function(x) mean(x, na.rm=T))
  saveRDS(mean.cor, "mean.rank.cor.RData")
  
  cor.rank[lower.tri(cor.rank, diag = T)] <- NA
  cor.rank
  
  
  
  library(reshape2)
  cor.dat <- melt(cor.rank, na.rm = TRUE)
  colnames(cor.dat) <- c("X1", "X2", "value")
  cor.dat$X1<- factor(cor.dat$X1, levels = methods.name)
  cor.dat$X2<- factor(cor.dat$X2, levels = methods.name)
  cor.dat <- cor.dat[!is.na(cor.dat$value),]
  
  library(ggplot2)
  library("scales") 
  
  win.graph()
  ggplot(cor.dat, aes(X2, ordered(X1, levels=methods.name), fill = value))+
    geom_tile(aes(fill = value))+
    scale_fill_gradientn(limit = c(0.9, 1), space = "Lab", colours = c("white", "blue"),
                         name="Spearman\nCorrelation") +
    theme_minimal()+ # minimal theme
    theme(axis.text.x = element_text(angle = 45, vjust = 1, 
                                     size = 12, hjust = 1))+
    scale_x_discrete(breaks=methods.name, labels=methods.name)+
    scale_y_discrete(breaks=methods.name, labels=methods.name)+
    coord_fixed()+
    geom_text(aes(X2, X1, label = value), color = "black", size = 4) +
    theme(
      axis.title.x = element_blank(),
      axis.title.y = element_blank(),
      panel.grid.major = element_blank(),
      panel.border = element_blank(),
      panel.background = element_blank(),
      axis.ticks = element_blank(),
      legend.justification = c(1, 0),
      legend.position = c(0.6, 0.7),
      legend.direction = "horizontal")+
    guides(fill = guide_colorbar(barwidth = 7, barheight = 1,
                                 title.position = "top", title.hjust = 0.5))
  
  
  #------------------------------------------------------------------------#
  #ANALYSIS OF NUMBER OF DE GENES and CLLASSIFICATION OVERLAPPING
  
  columns <- paste(methods,".", "padj", sep="")
  padj.matrix <- summary.all[,c(columns)]
  colnames(padj.matrix) <- methods
  
  DE.indicator <- padj.matrix
  for(i in 1:nrow(padj.matrix)){
    for(j in 1:ncol(padj.matrix)){
      if(padj.matrix[i,j] < 0.05 & is.na(padj.matrix[i,j]) == F) DE.indicator[i,j] <- 1
      else if(padj.matrix[i,j] >= 0.05 & is.na(padj.matrix[i,j]) == F) DE.indicator[i,j] <- 0
    }
  }
  
  avgExp <- rowMeans(norm.counts)
  q <- quantile(avgExp, prob=c(0.25, 0.5, 0.75))
  q
  #     25%        50%        75% 
  #4.013417  39.593452 241.991414
  
  avgExp.cat <- NULL
  avgExp.cat[avgExp<=q[1]] <- "Q1"
  avgExp.cat[avgExp>q[1] & avgExp<=q[2]] <- "Q2"
  avgExp.cat[avgExp>q[2] & avgExp<=q[3]] <- "Q3"
  avgExp.cat[avgExp>q[3]] <- "Q4"
  avgExp.cat[is.na(avgExp)] <- NA
  
  library(reshape)
  DE.indicator2 <- melt(DE.indicator)
  DE.indicator2 <- data.frame(DE.indicator2, avgExp.cat =rep(avgExp.cat, times=length(methods)))
  colnames(DE.indicator2) <- c("Methods", "DE", "GE.Category")
  
  
  agr <- aggregate(DE~Methods+GE.Category, data=DE.indicator2, FUN=sum)
  agr.all <- aggregate(DE~Methods, data=DE.indicator2, FUN=sum)
  agr.all$Methods <- agr$Methods <- methods.name
  saveRDS(list(agr.all=agr.all, agr=agr), "SDE.summary.RData")
  
  library(ggplot2)
  library(gridExtra)
  
  win.graph()
  pl1 <- ggplot(agr[order(agr$GE.Category, decreasing = F),], 
                aes(x=reorder(Methods, DE), y=DE, fill=GE.Category)) + 
    geom_bar(stat="identity", position = "stack")+ 
    theme(axis.text.x = element_text(angle = 45, hjust = 1), 
          legend.position=c(0.1, 0.8)) + 
    scale_x_discrete(breaks=methods.name, labels=methods.name)+
    labs(title="A", x="DE tools", y="mumber of SDE genes (at 5% FDR)",
         fill="Quartiles")
  
  pl2 <- ggplot(agr,  aes(x=Methods, y=DE, fill=GE.Category)) + 
    geom_bar(stat="identity", position = "fill")+
    theme(axis.text.x = element_text(angle = 45, hjust = 1), legend.position='none') + 
    scale_x_discrete(breaks=methods.name, labels=methods.name)+
    labs(title="B", x="DE tools", y="proportion")
  grid.arrange(pl1, pl2, ncol=2)
  
  
  
  #Overlapping of DE classification
  overlap <- matrix(NA, ncol=length(methods), nrow=length(methods))
  for(i in 1:nrow(overlap)){
    for(j in 1:ncol(overlap)){
      overlap[i,j] <- length(which(DE.indicator[,i]==1 & DE.indicator[,j]==1))
    }
  }
  colnames(overlap) <- methods.name
  rownames(overlap) <- methods.name
  
  non.overlap.A <- matrix(NA, ncol=length(methods), nrow=length(methods))
  for(i in 1:nrow(non.overlap.A)){
    for(j in 1:ncol(non.overlap.A)){
      non.overlap.A[i,j] <- length(which(DE.indicator[,i]==1 & DE.indicator[,j]==0))
    }
  }
  colnames(non.overlap.A) <- methods
  rownames(non.overlap.A) <- methods

  non.overlap.B <- matrix(NA, ncol=length(methods), nrow=length(methods))
  for(i in 1:nrow(non.overlap.B)){
    for(j in 1:ncol(non.overlap.B)){
      non.overlap.B[i,j] <- length(which(DE.indicator[,i]==0 & DE.indicator[,j]==1))
    }
  }
  colnames(non.overlap.B) <- methods
  rownames(non.overlap.B) <- methods

  overlap.prop <-overlap/(non.overlap.A+overlap+non.overlap.B)
  rownames(overlap.prop) <- methods.name
  colnames(overlap.prop) <- methods.name
  
  # number_of.SDE <- diag(overlap)
  # base <- overlap
  # for(i in 1:nrow(base)){
  #   for(j in 1:ncol(base)){
  #     base[i,j] <- min(number_of.SDE[i], number_of.SDE[j])
  #   }
  # }
  # overlap.prop <- overlap/base
  # rownames(overlap.prop) <- methods.name
  # colnames(overlap.prop) <- methods.name
  
  overlap.prop.2 <- overlap.prop
  diag(overlap.prop.2) <- NA
  mean.overlap <- apply(overlap.prop.2, 1, function(x) mean(x, na.rm=T))
  saveRDS(mean.overlap, "mean.overlap.prop.RData")
  
  
  library(reshape2)
  overlap.prop[lower.tri(overlap.prop, diag = T)] <- NA
  overlap.dat <- melt(overlap.prop, na.rm = TRUE)
  colnames(overlap.dat) <- c("X1", "X2", "value")
  overlap.dat$X1<- factor(overlap.dat$X1, levels = methods.name)
  overlap.dat$X2<- factor(overlap.dat$X2, levels = methods.name)
  overlap.dat <- overlap.dat[!is.na(overlap.dat$value),]
  overlap.dat[, "value"] <- round(overlap.dat[, "value"], 3)
  
  library(ggplot2)
  library("scales") 
  
  win.graph()
  ggplot(overlap.dat, aes(X2, ordered(X1, levels=methods.name), fill = value))+
    geom_tile(aes(fill = value))+
    scale_fill_gradientn(limit = c(0.20, 1), space = "Lab", colours = c("white", "blue"),
                         name="overlap proportion") +
    theme_minimal()+ # minimal theme
    theme(axis.text.x = element_text(angle = 45, vjust = 1, 
                                     size = 12, hjust = 1))+
    scale_x_discrete(breaks=methods.name, labels=methods.name)+
    scale_y_discrete(breaks=methods.name, labels=methods.name)+
    coord_fixed()+
    geom_text(aes(X2, X1, label = value), color = "black", size = 4) +
    theme(
      axis.title.x = element_blank(),
      axis.title.y = element_blank(),
      panel.grid.major = element_blank(),
      panel.border = element_blank(),
      panel.background = element_blank(),
      axis.ticks = element_blank(),
      legend.justification = c(1, 0),
      legend.position = c(0.6, 0.7),
      legend.direction = "horizontal")+
    guides(fill = guide_colorbar(barwidth = 7, barheight = 1,
                                 title.position = "top", title.hjust = 0.5))
  
  #------------------------------------------------------------------------#
  #ANALYSIS OF LFC
  columns <- paste(methods,".", "logFC", sep="")
  LFC.matrix <- summary.all[,c(columns)]
  colnames(LFC.matrix) <- methods.name
  LFC.matrix <- as.data.frame(lapply(LFC.matrix, function(x) replace(x, is.infinite(x),NA)))
  rownames(LFC.matrix) <- rownames(summary.all)
  
  ## Correlation b/n LFC estimates from each method
  cor.lfc <- cor(LFC.matrix[-13], method ="pearson", use="pairwise.complete.obs")
  rownames(cor.lfc) <- colnames(cor.lfc) <- methods.name[-13]
  cor.lfc.2 <- cor.lfc
  diag(cor.lfc.2) <- NA
  mean.cor.lfc <- apply(cor.lfc.2, 1, function(x) mean(x, na.rm=T))
  names(mean.cor.lfc) <- methods.name[-13]
  saveRDS(mean.cor.lfc, "mean.lfc.cor.RData")
  
  
  library(reshape2)
  cor.lfc[lower.tri(cor.lfc, diag = T)] <- NA
  cor.lfc.dat <- melt(cor.lfc, na.rm = TRUE)
  colnames(cor.lfc.dat) <- c("X1", "X2", "value")
  cor.lfc.dat$X1<- factor(cor.lfc.dat$X1, levels = rownames(cor.lfc))
  cor.lfc.dat$X2<- factor(cor.lfc.dat$X2, levels = rownames(cor.lfc))
  cor.lfc.dat <- cor.lfc.dat[!is.na(cor.lfc.dat$value),]
  cor.lfc.dat[, "value"] <- round(cor.lfc.dat[, "value"], 3)
  
  
  library(ggplot2)
  library("scales") 
  
  win.graph()
  ggplot(cor.lfc.dat, aes(X2, ordered(X1, levels=rownames(cor.lfc)), fill = value))+
    geom_tile(aes(fill = value))+
    scale_fill_gradientn(limit = c(0.65, 1), space = "Lab", colours = c("white", "blue"),
                         name="Pearson correlation \n between LFC estimates") +
    theme_minimal()+ # minimal theme
    theme(axis.text.x = element_text(angle = 45, vjust = 1, 
                                     size = 12, hjust = 1))+
    scale_x_discrete(breaks=rownames(cor.lfc), labels=rownames(cor.lfc))+
    scale_y_discrete(breaks=rownames(cor.lfc), labels=rownames(cor.lfc))+
    coord_fixed()+
    geom_text(aes(X2, X1, label = value), color = "black", size = 4) +
    theme(
      axis.title.x = element_blank(),
      axis.title.y = element_blank(),
      panel.grid.major = element_blank(),
      panel.border = element_blank(),
      panel.background = element_blank(),
      axis.ticks = element_blank(),
      legend.justification = c(1, 0),
      legend.position = c(0.6, 0.7),
      legend.direction = "horizontal")+
    guides(fill = guide_colorbar(barwidth = 7, barheight = 1,
                                 title.position = "top", title.hjust = 0.5))
  
  #Scatter plots between LFC estimates of selected DE tools, 
  # with partitioning genes into 4 different abundance levels (quartiles)
  methods2 <- methods[c(1,5, 6,8,11, 12)]
  methods.name2 <- methods.name[c(1,5, 6,8,11, 12)]
  LFC.matrix2 <- LFC.matrix[, c(1,5, 6,8,11, 12)]
  LFC.matrix2$avgExp.cat <- avgExp.cat
  pairs <- t(combn(length(methods2), 2))  [c(2,3,6,7,10,11,12,13,14),]
  cols <- c("dodgerblue4", "firebrick4", "goldenrod4", "mediumseagreen")
  win.graph()
  par(mfrow=c(3,3))
  for(i in 1:nrow(pairs)){
    plot(LFC.matrix2[,pairs[i,1]], LFC.matrix2[, pairs[i,2]], type="n", xlab=paste0(methods.name2[pairs[i,1]]), ylab=paste0(methods.name2[pairs[i,2]]),
         xlim=c(-7, 7), ylim=c(-7, 15))
    points(LFC.matrix2[LFC.matrix2$avgExp.cat =="Q1",pairs[i,1]], LFC.matrix2[LFC.matrix2$avgExp.cat =="Q1",pairs[i,2]], pch=6, col=cols[1])
    points(LFC.matrix2[LFC.matrix2$avgExp.cat =="Q2",pairs[i,1]], LFC.matrix2[LFC.matrix2$avgExp.cat =="Q2",pairs[i,2]], pch=1, col=cols[2])
    points(LFC.matrix2[LFC.matrix2$avgExp.cat =="Q3",pairs[i,1]], LFC.matrix2[LFC.matrix2$avgExp.cat =="Q3",pairs[i,2]], pch=0, col=cols[3])
    points(LFC.matrix2[LFC.matrix2$avgExp.cat =="Q4",pairs[i,1]], LFC.matrix2[LFC.matrix2$avgExp.cat =="Q4",pairs[i,2]], pch=17, col=cols[4])
    abline(0,1, lty=2, lwd=2)
    legend("topleft", c(paste0("Q1 ", "(r=", round(cor(LFC.matrix2[LFC.matrix2$avgExp.cat =="Q1",pairs[i,1]], 
                                                       LFC.matrix2[LFC.matrix2$avgExp.cat =="Q1",pairs[i,2]], use = "pairwise.complete.obs"), 3), ")"),
                        paste0("Q2 ", "(r=", round(cor(LFC.matrix2[LFC.matrix2$avgExp.cat =="Q2",pairs[i,1]], 
                                                       LFC.matrix2[LFC.matrix2$avgExp.cat =="Q2",pairs[i,2]], use = "pairwise.complete.obs"), 3), ")"),
                        paste0("Q3 ", "(r=", round(cor(LFC.matrix2[LFC.matrix2$avgExp.cat =="Q3",pairs[i,1]], 
                                                       LFC.matrix2[LFC.matrix2$avgExp.cat =="Q3",pairs[i,2]], use = "pairwise.complete.obs"), 3), ")"),
                        paste0("Q4 ", "(r=", round(cor(LFC.matrix2[LFC.matrix2$avgExp.cat =="Q4",pairs[i,1]], 
                                                       LFC.matrix2[LFC.matrix2$avgExp.cat =="Q4",pairs[i,2]], use = "pairwise.complete.obs"), 3), ")")),
           pch=c(6, 1, 0, 17), col=cols, bty="n", cex=1.5, ncol=2)
  }
  
  
  #-------------------------------------------------------------------#
  #MA plots
  win.graph()
  par(mfrow=c(2,2))
  
  ##edgeR_classic
  x <- summary.all[,c("edgeR_classic.avgExpr", "edgeR_classic.logFC", "edgeR_classic.padj")]
  colnames(x) <- c("baseMean", "log2FoldChange", "padj" )
  x$avgExp.cat <- avgExp.cat
  plot(x$baseMean, x$log2FoldChange, col = ifelse(x$padj>=0.05, "gray32", "red3"), main="edgeR Exact",
       xlab = "mean of normalized counts", ylab = "LFC", log = "x", cex=0.45, ylim=c(-5, 15))
  abline(v=q, lty=2, col="darkcyan")
  abline(h=c(-1, 1), lty=2, col="darkcyan")
  text(c(2.5, 10, 100, 1000), c(13, 13, 13, 13), c("Q1", "Q2", "Q3", "Q4"))
  text(c(2e05, 2e05), c(-1.75, 1.75), c("LFC = -1", "LFC =1"))
  legend("topright", c("Non SDE Genes", "SDE genes"), col=c("gray32", "red3"), pch=20, bty="n")
  ##DESeq2
  x <- summary.all[,c("edgeR_classic.avgExpr", "DESeq2.logFC", "DESeq2.padj")]
  colnames(x) <- c("baseMean", "log2FoldChange", "padj" )
  x$avgExp.cat <- avgExp.cat
  plot(x$baseMean, x$log2FoldChange, col = ifelse(x$padj>=0.05, "gray32", "red3"), main="DESeq2",
       xlab = "mean of normalized counts", ylab = "LFC", log = "x", cex=0.45, ylim=c(-5, 15))
  abline(v=q, lty=2, col="darkcyan")
  abline(h=c(-1, 1), lty=2, col="darkcyan")
  text(c(2.5, 10, 100, 1000), c(13, 13, 13, 13), c("Q1", "Q2", "Q3", "Q4"))
  text(c(2e05, 2e05), c(-1.75, 1.75), c("LFC = -1", "LFC =1"))
  legend("topright", c("Non SDE Genes", "SDE genes"), col=c("gray32", "red3"), pch=20, bty="n")
  
  ##limmaVoom
  x <- summary.all[,c("edgeR_classic.avgExpr", "LimmaVoom.logFC", "LimmaVoom.padj")]
  colnames(x) <- c("baseMean", "log2FoldChange", "padj" )
  x$avgExp.cat <- avgExp.cat
  plot(x$baseMean, x$log2FoldChange, col = ifelse(x$padj>=0.05, "gray32", "red3"), main="limmaVoom",
       xlab = "mean of normalized counts", ylab = "LFC", log = "x", cex=0.45, ylim=c(-5, 15))
  abline(v=q, lty=2, col="darkcyan")
  abline(h=c(-1, 1), lty=2, col="darkcyan")
  text(c(2.5, 10, 100, 1000), c(13, 13, 13, 13), c("Q1", "Q2", "Q3", "Q4"))
  text(c(2e05, 2e05), c(-1.75, 1.75), c("LFC = -1", "LFC =1"))
  legend("topright", c("Non SDE Genes", "SDE genes"), col=c("gray32", "red3"), pch=20, bty="n")
  
  ##PoissonSeq
  x <- summary.all[,c("edgeR_classic.avgExpr", "PoissonSeq.logFC", "PoissonSeq.padj")]
  colnames(x) <- c("baseMean", "log2FoldChange", "padj" )
  x$avgExp.cat <- avgExp.cat
  plot(x$baseMean, x$log2FoldChange, col = ifelse(x$padj>=0.05, "gray32", "red3"), main="PoissonSeq",
       xlab = "mean of normalized counts", ylab = "LFC", log = "x", cex=0.45, ylim=c(-5, 15))
  abline(v=q, lty=2, col="darkcyan")
  abline(h=c(-1, 1), lty=2, col="darkcyan")
  text(c(2.5, 10, 100, 1000), c(13, 13, 13, 13), c("Q1", "Q2", "Q3", "Q4"))
  text(c(2e05, 2e05), c(-1.75, 1.75), c("LFC = -1", "LFC =1"))
  legend("topright", c("Non SDE Genes", "SDE genes"), col=c("gray32", "red3"), pch=20, bty="n")
  
  #-------------------------------------------------------------------------
  #Computational time
  comput.time <- sapply(results.full, function(x) x$time)[3, ]
  names(comput.time) <- methods.name
  saveRDS(comput.time, "comput.time.RData")
  

##############################################################################################################################################################

#Concordance Analysis based on GTEx data
  
  
  
  ###### Set working directory
  setwd('GTEx')
  
  ##### Loading annotated and processed data
  read <- readRDS("GTEx_Data_20and20.RData")
  counts <- read$counts
  group <- read$group
  counts <- counts[which(rowSums(counts[, group == levels(group)[1]]) > 0 &
                           rowSums(counts[, group == levels(group)[2]]) > 0),]
  dim(counts)
  #18632 mRNA genes are selected
  
  ###Exploratory Data Analysis 

  #Correlation summary
  cor.summary <- function(counts, group){
    group <- as.factor(group)
    counts <- counts[, c(which(group == levels(group)[1]), 
                         which(group == levels(group)[2]))]
    
    WC1 <- cor(counts[, which(group == levels(group)[1])])
    WC1 <- WC1[lower.tri(WC1, diag = FALSE)]
    WC2 <- cor(counts[, which(group == levels(group)[2])])
    WC2 <- WC2[lower.tri(WC2, diag = FALSE)]
    
    WC.summary <- quantile(c(WC1, WC2), prob=c(0, 0.25, 0.5, 0.75, 1))
    
    BC <- cor(counts)[1:length(which(group == levels(group)[1])),
                      (length(which(group == levels(group)[1]))+1):length(group)]
    BC <- BC[lower.tri(BC, diag = FALSE)]
    BC.summary <- quantile(BC, prob=c(0, 0.25, 0.5, 0.75, 1))
    
    return(list(within.cor=WC.summary, between.cor =BC.summary ))
  }
  cor.summary(counts, group)
  
  #Library size 
  summary(colSums(counts))
  
  #Exolring biological coefficient of variability (BCV) using edgeR
  library(edgeR)
  win.graph()
  y <- DGEList(counts=counts, group=group)
  y <- calcNormFactors(y)
  design <- model.matrix(~group)
  y <- estimateCommonDisp(y, design)
  y <- estimateGLMCommonDisp(y, design, verbose=TRUE)
  y <- estimateGLMTrendedDisp(y, design)
  y <- estimateGLMTagwiseDisp(y, design)
  plotBCV(y, ylim=c(0, 6), main="GTEx (mRNA)", cex.lab=1.5)
  text(7, 4, "Common Dispersion = 0.295 \n Common BCV = 0.543", cex=1.5, col=2)
  
  
  #MDS plot
  library(edgeR)
  y <- DGEList(counts=counts, group=group)
  y <- calcNormFactors(y)
  par(bg = 'gray88')
  rect(par("usr")[1], par("usr")[3], par("usr")[2], par("usr")[4], col = 
         "grey88")
  plotMDS(y, method="bcv", col=as.numeric(y$samples$group), panel.first=grid(col = "white", lty=1), bg="gray88")
  legend("bottomleft", as.character(unique(y$samples$group)), col=1:3, pch=20)
  
  
  ### Running DGE analysis 
  ###### Set analysis output object
  results.full <- list()
  
  # edgeR - classic
  results.full["edgeR_classic"] <- list(runedgeR_classic(count.dat=counts, conditions=group,
                                                         colors=colors,path=outputpath))
  # edgeR - glm
  results.full["edgeR_glm"] <- list(runedgeR_glm(count.dat=counts, conditions=group,
                                                 colors=colors,path=outputpath))
  # edgeR - robust 
  results.full["edgeR_rob"] <- list(runedgeR_rob(count.dat=counts, conditions=group,
                                                 colors=colors,path=outputpath))
  # edgeR - quasi-likelihood 
  results.full["edgeR_ql"] <- list(runedgeR_ql(count.dat=counts, conditions=group,
                                               colors=colors,path=outputpath))
  
  # DESeq
  results.full["DESeq"] <- list(runDESeq(count.dat=counts, conditions=group,
                                         colors=colors,path=outputpath))
  # DESeq2
  results.full["DESeq2"] <- list(runDESeq2(count.dat=counts, conditions=group,
                                           colors=colors,path=outputpath))
  # Limma + quantile normalization
  results.full["LimmaQN"] <- list(runLimmaQN(count.dat=counts, conditions=group,
                                             colors=colors,path=outputpath))
  # LimmaVoom (without quality weights)
  results.full["LimmaVoom"] <- list(runLimmaVoom(count.dat=counts, conditions=group,
                                                 colors=colors,path=outputpath))
  # LimmaVoom (with quality weights)
  results.full["LimmaVoom_QW"] <- list(runLimmaVoom_QW(count.dat=counts, conditions=group,
                                                       colors=colors,path=outputpath))
  # LimmaVst 
  results.full["LimmaVst"] <- list(runLimmaVst(count.dat=counts, conditions=group,
                                               colors=colors,path=outputpath))
  # BaySeq
  results.full["BaySeq"] <- list(runBaySeq(count.dat=counts, conditions=group,
                                           colors=colors,path=outputpath))
  
  # PoissonSeq 
  results.full["PoissonSeq"] <- list(runPoissonSeq(count.dat=counts, conditions=group,
                                                   colors=colors,path=outputpath))
  # SAMSeq
  results.full["SAMSeq"] <- list(runSAMSeq(count.dat=counts, conditions=group,
                                           colors=colors,path=outputpath))
  
  # QuasiSeq
  results.full["QuasiSeq"] <- list(runQuasiSeq(count.dat=counts, conditions=group,
                                               colors=colors,path=outputpath))
  
  #Saving result
  saveRDS(results.full, file="result_full_GTEx.RData")
  
  
  
  ### Concordance Analysis between DE tools 
  #Loading saved result of CRC AZA analysis
  results.full <- readRDS("result_full_GTEx.RData")
  methods <- names(results.full)
  
  ## organaizing results
  library(DESeq)
  cds <- DESeq::newCountDataSet(counts, group)
  cds <- DESeq::estimateSizeFactors(cds)
  norm.counts <- counts(cds, normalized=TRUE)
  
  classical.LFC.estimates <- data.frame(classical.LFC = apply(norm.counts, 1, function(x) {
    mu.g1 <- mean(x[group==levels(group)[1]])
    mu.g2 <- mean(x[group==levels(group)[2]])
    if(mu.g1 != 0 & mu.g2 != 0) {lfc <- log2(mu.g2/mu.g1)}
    else if(mu.g1 != 0 & mu.g2 == 0) {lfc <- -log2(mu.g1)}
    else if(mu.g1 == 0 & mu.g2 != 0) {lfc <- log2(mu.g2)}
    return(lfc) }))
  classical.LFC.estimates$ID <- rownames(classical.LFC.estimates)
  
  Merge.DE.results <- function(results.full, na.treat ="keep"){
    #A function that returns the rank of genes for all methods 
    methods <-  names(results.full)
    
    df1 <- results.full[1][[paste(methods[1])]]$summary
    df1 <- merge(df1, classical.LFC.estimates, by="ID", all.x=T, all.y=T)
    df1$pval[is.na(df1$pval)] <- 1
    df1$signed.pval <- sign(df1$classical.LFC)*(df1$pval+1e-5)  #A constant +1e-5 is added to each pvalues to avoid 0 signed p-value when p-value is 0
    df1$pi.score <- abs(df1$classical.LFC)*(-log10(df1$pval+1e-5))
    
    df2 <- results.full[2][[paste(methods[2])]]$summary
    df2 <- merge(df2, classical.LFC.estimates, by="ID", all.x=T, all.y=T)
    df2$pval[is.na(df2$pval)] <- 1
    df2$signed.pval <- sign(df2$classical.LFC)*(df2$pval+1e-5)
    df2$pi.score <- abs(df2$classical.LFC)*(-log10(df2$pval+1e-5))
    
    
    summary.all <- merge(df1, df2, by ="ID", all.x=T, all.y=T)
    colnames(summary.all) <- c("ID", paste(methods[1],".", c(colnames(df1)), sep="")[-1], 
                               paste(methods[2],".", c(colnames(df2)), sep="")[-1])
    
    for(i in 3:length(methods)){
      df.i <- results.full[i][[paste(methods[i])]]$summary
      df.i <- merge(df.i, classical.LFC.estimates, by="ID", all.x=T, all.y=T)
      df.i$pval[is.na(df.i$pval)] <- 1
      
      if(methods[i] != "SAMSeq"){
        df.i$signed.pval <- sign(df.i$classical.LFC)*(df.i$pval+1e-5)
        df.i$pi.score <- abs(df.i$classical.LFC)*(-log10(df.i$pval+1e-5))
      }
      
      if(methods[i] == "SAMSeq"){
        df.i$stat[is.na(df.i$stat)] <- 0
        df.i$signed.pval <- sign(df.i$classical.LFC)*(1/abs(df.i$stat+1e-5))
        df.i$pi.score <- abs(df.i$classical.LFC)*(-log10(1/abs(df.i$stat+1e-5)))
      }
      colnames(df.i) <- c("ID", paste(methods[i], ".", colnames(df.i), sep="")[-1])
      
      summary.all <- merge(summary.all, df.i, by ="ID", all.x=T, all.y=T)
      #colnames(summary.all) <- c("ID", methods[1:i])
    }
    
    rownames(summary.all) <- summary.all$ID
    summary.all <- summary.all[,-1]
    
    return(summary.all)
  }
  
  
  #Merging summary results of all the methods
  summary.all <- Merge.DE.results(results.full)
  dim(summary.all)
  
  methods.name <- c("edgeR exact", "edgeR GLM", "edgeR robust", "edgeR QL", "DESeq", "DESeq2", "limmaQN", "limmaVoom", "limmaVoom + QW", "limmaVst", 
                    "baySeq", "PoissonSeq", "SAMSeq", "QuasiSeq")
  
  
  
  #------------------------------------------------------------------------#
  #GENE RANK ANALYSIS 
  #Spearman's Rank Correlation Matrix
  #columns <- paste(methods,".", "signed.pval", sep="")
  columns <- paste(methods,".", "pi.score", sep="")
  score.matrix <- summary.all[,c(columns)]
  colnames(score.matrix) <- methods.name
  
  #classical LFC estimates
  columns <- paste(methods,".", "classical.LFC", sep="")
  LFC.matrix <- summary.all[,c(columns)]
  colnames(LFC.matrix) <- methods.name
  LFC.matrix <- as.data.frame(lapply(LFC.matrix, function(x) replace(x, is.infinite(x),NA)))
  rownames(LFC.matrix) <- rownames(summary.all)
  
  
  #subsetting the top commonly identifed SDE genes across methods
  columns <- paste(methods,".", "padj", sep="")
  padj.matrix <- summary.all[,c(columns)]
  padj.matrix[is.na(padj.matrix)] = 1   #replacing NA values by 1
  colnames(padj.matrix) <- methods.name
  
  common.SDE.genes <- names(which(apply(padj.matrix, 1, function(x) {
    if(max(x) < 1) {return(1)}
    else {return(0)}}) == 1))
  length(common.SDE.genes)
  
  #Rank correlation, ranks scores and if there are ties, it uses auxillary information to break ties
  rank.cov <- function(y, x=NULL, na.last=TRUE, ties.method="average"){
    r <- y
    if(is.null(x)) {r <- rank(y, na.last=na.last, ties.method=ties.method)}
    else if(!is.null(x)){
      r.temp <- rank(y, na.last=na.last, ties.method="min")
      t.r <- table(r.temp)
      ties <- as.numeric(names(which(t.r>1)))
      if(length(ties)>=1) {
        for(i in 1:length(ties)){
          r.cov <- rank(x[r.temp==ties[i]])-1
          r.temp[r.temp==ties[i]] <- r.temp[r.temp==ties[i]] + r.cov
        }
      }
      else{
        r.temp <- rank(y, na.last=na.last, ties.method=ties.method)
      }
      r <- r.temp 
    }
    return(r)
  }
  
  rank.matrix <- apply(score.matrix, 2, function(v){
    rank.cov(v, x=LFC.matrix[,1])
  })
  
  rank.matrix <- rank.matrix[common.SDE.genes, ]
  
  cor.rank <- round(cor(rank.matrix, use = "pairwise.complete.obs", method ="spearman"), 3)
  cor.rank.2 <- cor.rank
  diag(cor.rank.2) <- NA
  mean.cor <- apply(cor.rank.2, 1, function(x) mean(x, na.rm=T))
  saveRDS(mean.cor, "mean.rank.cor.RData")
  
  cor.rank[lower.tri(cor.rank, diag = T)] <- NA
  cor.rank
  
  
  
  library(reshape2)
  cor.dat <- melt(cor.rank, na.rm = TRUE)
  colnames(cor.dat) <- c("X1", "X2", "value")
  cor.dat$X1<- factor(cor.dat$X1, levels = methods.name)
  cor.dat$X2<- factor(cor.dat$X2, levels = methods.name)
  cor.dat <- cor.dat[!is.na(cor.dat$value),]
  
  library(ggplot2)
  library("scales") 
  
  win.graph()
  ggplot(cor.dat, aes(X2, ordered(X1, levels=methods.name), fill = value))+
    geom_tile(aes(fill = value))+
    scale_fill_gradientn(limit = c(0.85, 1), space = "Lab", colours = c("white", "blue"),
                         name="Spearman\nCorrelation") +
    theme_minimal()+ # minimal theme
    theme(axis.text.x = element_text(angle = 45, vjust = 1, 
                                     size = 12, hjust = 1))+
    scale_x_discrete(breaks=methods.name, labels=methods.name)+
    scale_y_discrete(breaks=methods.name, labels=methods.name)+
    coord_fixed()+
    geom_text(aes(X2, X1, label = value), color = "black", size = 4) +
    theme(
      axis.title.x = element_blank(),
      axis.title.y = element_blank(),
      panel.grid.major = element_blank(),
      panel.border = element_blank(),
      panel.background = element_blank(),
      axis.ticks = element_blank(),
      legend.justification = c(1, 0),
      legend.position = c(0.6, 0.7),
      legend.direction = "horizontal")+
    guides(fill = guide_colorbar(barwidth = 7, barheight = 1,
                                 title.position = "top", title.hjust = 0.5))
  
  
  #------------------------------------------------------------------------#
  #ANALYSIS OF NUMBER OF DE GENES and CLLASSIFICATION OVERLAPPING
  columns <- paste(methods,".", "padj", sep="")
  padj.matrix <- summary.all[,c(columns)]
  colnames(padj.matrix) <- methods
  
  DE.indicator <- padj.matrix
  for(i in 1:nrow(padj.matrix)){
    for(j in 1:ncol(padj.matrix)){
      if(padj.matrix[i,j] < 0.05 & is.na(padj.matrix[i,j]) == F) DE.indicator[i,j] <- 1
      else if(padj.matrix[i,j] >= 0.05 & is.na(padj.matrix[i,j]) == F) DE.indicator[i,j] <- 0
    }
  }
  
  avgExp <- rowMeans(norm.counts)
  q <- quantile(avgExp, prob=c(0.25, 0.5, 0.75))
  q
  #     25%        50%        75% 
  #57.48034  538.13629 1716.95958 
  
  avgExp.cat <- NULL
  avgExp.cat[avgExp<=q[1]] <- "Q1"
  avgExp.cat[avgExp>q[1] & avgExp<=q[2]] <- "Q2"
  avgExp.cat[avgExp>q[2] & avgExp<=q[3]] <- "Q3"
  avgExp.cat[avgExp>q[3]] <- "Q4"
  avgExp.cat[is.na(avgExp)] <- NA
  
  library(reshape)
  DE.indicator2 <- melt(DE.indicator)
  DE.indicator2 <- data.frame(DE.indicator2, avgExp.cat =rep(avgExp.cat, times=length(methods)))
  colnames(DE.indicator2) <- c("Methods", "DE", "GE.Category")
  
  
  
  agr <- aggregate(DE~Methods+GE.Category, data=DE.indicator2, FUN=sum)
  agr.all <- aggregate(DE~Methods, data=DE.indicator2, FUN=sum)
  agr.all$Methods <- agr$Methods <- methods.name
  saveRDS(list(agr.all=agr.all, agr=agr), "SDE.summary.RData")
  
  library(ggplot2)
  library(gridExtra)
  win.graph()
  pl1 <- ggplot(agr[order(agr$GE.Category, decreasing = F),], 
                aes(x=reorder(Methods, DE), y=DE, fill=GE.Category)) + 
    geom_bar(stat="identity", position = "stack")+ 
    theme(axis.text.x = element_text(angle = 45, hjust = 1), 
          legend.position=c(0.1, 0.8)) + 
    scale_x_discrete(breaks=methods.name, labels=methods.name)+
    labs(title="A", x="DE tools", y="mumber of SDE genes (at 5% FDR)",
         fill="Quartiles")
  
  pl2 <- ggplot(agr,  aes(x=Methods, y=DE, fill=GE.Category)) + 
    geom_bar(stat="identity", position = "fill")+
    theme(axis.text.x = element_text(angle = 45, hjust = 1), legend.position='none') + 
    scale_x_discrete(breaks=methods.name, labels=methods.name)+
    labs(title="B", x="DE tools", y="proportion")
  grid.arrange(pl1, pl2, ncol=2)
  
  
  #Overlapping of DE classification
  overlap <- matrix(NA, ncol=length(methods), nrow=length(methods))
  for(i in 1:nrow(overlap)){
    for(j in 1:ncol(overlap)){
      overlap[i,j] <- length(which(DE.indicator[,i]==1 & DE.indicator[,j]==1))
    }
  }
  colnames(overlap) <- methods.name
  rownames(overlap) <- methods.name
  
  non.overlap.A <- matrix(NA, ncol=length(methods), nrow=length(methods))
  for(i in 1:nrow(non.overlap.A)){
    for(j in 1:ncol(non.overlap.A)){
      non.overlap.A[i,j] <- length(which(DE.indicator[,i]==1 & DE.indicator[,j]==0))
    }
  }
  colnames(non.overlap.A) <- methods
  rownames(non.overlap.A) <- methods

  non.overlap.B <- matrix(NA, ncol=length(methods), nrow=length(methods))
  for(i in 1:nrow(non.overlap.B)){
    for(j in 1:ncol(non.overlap.B)){
      non.overlap.B[i,j] <- length(which(DE.indicator[,i]==0 & DE.indicator[,j]==1))
    }
  }
  colnames(non.overlap.B) <- methods
  rownames(non.overlap.B) <- methods

  overlap.prop <-overlap/(non.overlap.A+overlap+non.overlap.B)
  rownames(overlap.prop) <- methods.name
  colnames(overlap.prop) <- methods.name
  
  # number_of.SDE <- diag(overlap)
  # base <- overlap
  # for(i in 1:nrow(base)){
  #   for(j in 1:ncol(base)){
  #     base[i,j] <- min(number_of.SDE[i], number_of.SDE[j])
  #   }
  # }
  # overlap.prop <- overlap/base
  # rownames(overlap.prop) <- methods.name
  # colnames(overlap.prop) <- methods.name
  
  overlap.prop.2 <- overlap.prop
  diag(overlap.prop.2) <- NA
  mean.overlap <- apply(overlap.prop.2, 1, function(x) mean(x, na.rm=T))
  saveRDS(mean.overlap, "mean.overlap.prop.RData")
  
  
  library(reshape2)
  overlap.prop[lower.tri(overlap.prop, diag = T)] <- NA
  overlap.dat <- melt(overlap.prop, na.rm = TRUE)
  colnames(overlap.dat) <- c("X1", "X2", "value")
  overlap.dat$X1<- factor(overlap.dat$X1, levels = methods.name)
  overlap.dat$X2<- factor(overlap.dat$X2, levels = methods.name)
  overlap.dat <- overlap.dat[!is.na(overlap.dat$value),]
  overlap.dat[, "value"] <- round(overlap.dat[, "value"], 3)
  
  library(ggplot2)
  library("scales") 
  
  win.graph()
  ggplot(overlap.dat, aes(X2, ordered(X1, levels=methods.name), fill = value))+
    geom_tile(aes(fill = value))+
    scale_fill_gradientn(limit = c(0.3, 1), space = "Lab", colours = c("white", "blue"),
                         name="overlap proportion") +
    theme_minimal()+ # minimal theme
    theme(axis.text.x = element_text(angle = 45, vjust = 1, 
                                     size = 12, hjust = 1))+
    scale_x_discrete(breaks=methods.name, labels=methods.name)+
    scale_y_discrete(breaks=methods.name, labels=methods.name)+
    coord_fixed()+
    geom_text(aes(X2, X1, label = value), color = "black", size = 4) +
    theme(
      axis.title.x = element_blank(),
      axis.title.y = element_blank(),
      panel.grid.major = element_blank(),
      panel.border = element_blank(),
      panel.background = element_blank(),
      axis.ticks = element_blank(),
      legend.justification = c(1, 0),
      legend.position = c(0.6, 0.7),
      legend.direction = "horizontal")+
    guides(fill = guide_colorbar(barwidth = 7, barheight = 1,
                                 title.position = "top", title.hjust = 0.5))
  
  #------------------------------------------------------------------------#
  #ANALYSIS OF LFC
  columns <- paste(methods,".", "logFC", sep="")
  LFC.matrix <- summary.all[,c(columns)]
  colnames(LFC.matrix) <- methods.name
  LFC.matrix <- as.data.frame(lapply(LFC.matrix, function(x) replace(x, is.infinite(x),NA)))
  rownames(LFC.matrix) <- rownames(summary.all)
  
  ## Correlation b/n LFC estimates from each method
  cor.lfc <- cor(LFC.matrix[-13], method ="pearson", use="pairwise.complete.obs")
  rownames(cor.lfc) <- colnames(cor.lfc) <- methods.name[-13]
  cor.lfc.2 <- cor.lfc
  diag(cor.lfc.2) <- NA
  mean.cor.lfc <- apply(cor.lfc.2, 1, function(x) mean(x, na.rm=T))
  names(mean.cor.lfc) <- methods.name[-13]
  saveRDS(mean.cor.lfc, "mean.lfc.cor.RData")
  
  
  library(reshape2)
  cor.lfc[lower.tri(cor.lfc, diag = T)] <- NA
  cor.lfc.dat <- melt(cor.lfc, na.rm = TRUE)
  colnames(cor.lfc.dat) <- c("X1", "X2", "value")
  cor.lfc.dat$X1<- factor(cor.lfc.dat$X1, levels = rownames(cor.lfc))
  cor.lfc.dat$X2<- factor(cor.lfc.dat$X2, levels = rownames(cor.lfc))
  cor.lfc.dat <- cor.lfc.dat[!is.na(cor.lfc.dat$value),]
  cor.lfc.dat[, "value"] <- round(cor.lfc.dat[, "value"], 3)
  
  
  library(ggplot2)
  library("scales") 
  
  win.graph()
  ggplot(cor.lfc.dat, aes(X2, ordered(X1, levels=rownames(cor.lfc)), fill = value))+
    geom_tile(aes(fill = value))+
    scale_fill_gradientn(limit = c(0.75, 1), space = "Lab", colours = c("white", "blue"),
                         name="Pearson correlation \n between LFC estimates") +
    theme_minimal()+ # minimal theme
    theme(axis.text.x = element_text(angle = 45, vjust = 1, 
                                     size = 12, hjust = 1))+
    scale_x_discrete(breaks=rownames(cor.lfc), labels=rownames(cor.lfc))+
    scale_y_discrete(breaks=rownames(cor.lfc), labels=rownames(cor.lfc))+
    coord_fixed()+
    geom_text(aes(X2, X1, label = value), color = "black", size = 4) +
    theme(
      axis.title.x = element_blank(),
      axis.title.y = element_blank(),
      panel.grid.major = element_blank(),
      panel.border = element_blank(),
      panel.background = element_blank(),
      axis.ticks = element_blank(),
      legend.justification = c(1, 0),
      legend.position = c(0.6, 0.7),
      legend.direction = "horizontal")+
    guides(fill = guide_colorbar(barwidth = 7, barheight = 1,
                                 title.position = "top", title.hjust = 0.5))
  
  #Scatter plots between LFC estimates of selected DE tools, 
  # with partitioning genes into 4 different abundance levels (quartiles)
  methods2 <- methods[c(1,5, 6,8,11, 12)]
  methods.name2 <- methods.name[c(1,5, 6,8,11, 12)]
  LFC.matrix2 <- LFC.matrix[, c(1,5, 6,8,11, 12)]
  LFC.matrix2$avgExp.cat <- avgExp.cat
  pairs <- t(combn(length(methods2), 2))  [c(2,3,6,7,10,11,12,13,14),]
  cols <- c("dodgerblue4", "firebrick4", "goldenrod4", "mediumseagreen")
  win.graph()
  par(mfrow=c(3,3))
  for(i in 1:nrow(pairs)){
    plot(LFC.matrix2[,pairs[i,1]], LFC.matrix2[, pairs[i,2]], type="n", xlab=paste0(methods.name2[pairs[i,1]]), ylab=paste0(methods.name2[pairs[i,2]]),
         xlim=c(-8, 10), ylim=c(-8, 15))
    points(LFC.matrix2[LFC.matrix2$avgExp.cat =="Q1",pairs[i,1]], LFC.matrix2[LFC.matrix2$avgExp.cat =="Q1",pairs[i,2]], pch=6, col=cols[1])
    points(LFC.matrix2[LFC.matrix2$avgExp.cat =="Q2",pairs[i,1]], LFC.matrix2[LFC.matrix2$avgExp.cat =="Q2",pairs[i,2]], pch=1, col=cols[2])
    points(LFC.matrix2[LFC.matrix2$avgExp.cat =="Q3",pairs[i,1]], LFC.matrix2[LFC.matrix2$avgExp.cat =="Q3",pairs[i,2]], pch=0, col=cols[3])
    points(LFC.matrix2[LFC.matrix2$avgExp.cat =="Q4",pairs[i,1]], LFC.matrix2[LFC.matrix2$avgExp.cat =="Q4",pairs[i,2]], pch=17, col=cols[4])
    abline(0,1, lty=2, lwd=2)
    legend("topleft", c(paste0("Q1 ", "(r=", round(cor(LFC.matrix2[LFC.matrix2$avgExp.cat =="Q1",pairs[i,1]], 
                                                       LFC.matrix2[LFC.matrix2$avgExp.cat =="Q1",pairs[i,2]], use = "pairwise.complete.obs"), 3), ")"),
                        paste0("Q2 ", "(r=", round(cor(LFC.matrix2[LFC.matrix2$avgExp.cat =="Q2",pairs[i,1]], 
                                                       LFC.matrix2[LFC.matrix2$avgExp.cat =="Q2",pairs[i,2]], use = "pairwise.complete.obs"), 3), ")"),
                        paste0("Q3 ", "(r=", round(cor(LFC.matrix2[LFC.matrix2$avgExp.cat =="Q3",pairs[i,1]], 
                                                       LFC.matrix2[LFC.matrix2$avgExp.cat =="Q3",pairs[i,2]], use = "pairwise.complete.obs"), 3), ")"),
                        paste0("Q4 ", "(r=", round(cor(LFC.matrix2[LFC.matrix2$avgExp.cat =="Q4",pairs[i,1]], 
                                                       LFC.matrix2[LFC.matrix2$avgExp.cat =="Q4",pairs[i,2]], use = "pairwise.complete.obs"), 3), ")")),
           pch=c(6, 1, 0, 17), col=cols, bty="n", cex=1.5, ncol=2)
  }
  
  
  #-------------------------------------------------------------------#
  #MA plots
  win.graph()
  par(mfrow=c(2,2))
  
  ##edgeR_classic
  x <- summary.all[,c("edgeR_classic.avgExpr", "edgeR_classic.logFC", "edgeR_classic.padj")]
  colnames(x) <- c("baseMean", "log2FoldChange", "padj" )
  x$avgExp.cat <- avgExp.cat
  plot(x$baseMean, x$log2FoldChange, col = ifelse(x$padj>=0.05, "gray32", "red3"), main="edgeR Exact",
       xlab = "mean of normalized counts", ylab = "LFC", log = "x", cex=0.45, ylim=c(-5, 15))
  abline(v=q, lty=2, col="darkcyan")
  abline(h=c(-1, 1), lty=2, col="darkcyan")
  text(c(10, 100, 1000, 10000), c(13, 13, 13, 13), c("Q1", "Q2", "Q3", "Q4"))
  text(c(2e05, 2e05), c(-1.75, 1.75), c("LFC = -1", "LFC =1"))
  legend("topright", c("Non SDE Genes", "SDE genes"), col=c("gray32", "red3"), pch=20, bty="n")
  ##DESeq2
  x <- summary.all[,c("edgeR_classic.avgExpr", "DESeq2.logFC", "DESeq2.padj")]
  colnames(x) <- c("baseMean", "log2FoldChange", "padj" )
  x$avgExp.cat <- avgExp.cat
  plot(x$baseMean, x$log2FoldChange, col = ifelse(x$padj>=0.05, "gray32", "red3"), main="DESeq2",
       xlab = "mean of normalized counts", ylab = "LFC", log = "x", cex=0.45, ylim=c(-5, 15))
  abline(v=q, lty=2, col="darkcyan")
  abline(h=c(-1, 1), lty=2, col="darkcyan")
  text(c(10, 100, 1000, 10000), c(13, 13, 13, 13), c("Q1", "Q2", "Q3", "Q4"))
  text(c(2e05, 2e05), c(-1.75, 1.75), c("LFC = -1", "LFC =1"))
  legend("topright", c("Non SDE Genes", "SDE genes"), col=c("gray32", "red3"), pch=20, bty="n")
  
  ##limmaVoom
  x <- summary.all[,c("edgeR_classic.avgExpr", "LimmaVoom.logFC", "LimmaVoom.padj")]
  colnames(x) <- c("baseMean", "log2FoldChange", "padj" )
  x$avgExp.cat <- avgExp.cat
  plot(x$baseMean, x$log2FoldChange, col = ifelse(x$padj>=0.05, "gray32", "red3"), main="limmaVoom",
       xlab = "mean of normalized counts", ylab = "LFC", log = "x", cex=0.45, ylim=c(-5, 15))
  abline(v=q, lty=2, col="darkcyan")
  abline(h=c(-1, 1), lty=2, col="darkcyan")
  text(c(10, 100, 1000, 10000), c(13, 13, 13, 13), c("Q1", "Q2", "Q3", "Q4"))
  text(c(2e05, 2e05), c(-1.75, 1.75), c("LFC = -1", "LFC =1"))
  legend("topright", c("Non SDE Genes", "SDE genes"), col=c("gray32", "red3"), pch=20, bty="n")
  
  ##PoissonSeq
  x <- summary.all[,c("edgeR_classic.avgExpr", "PoissonSeq.logFC", "PoissonSeq.padj")]
  colnames(x) <- c("baseMean", "log2FoldChange", "padj" )
  x$avgExp.cat <- avgExp.cat
  plot(x$baseMean, x$log2FoldChange, col = ifelse(x$padj>=0.05, "gray32", "red3"), main="PoissonSeq",
       xlab = "mean of normalized counts", ylab = "LFC", log = "x", cex=0.45, ylim=c(-5, 15))
  abline(v=q, lty=2, col="darkcyan")
  abline(h=c(-1, 1), lty=2, col="darkcyan")
  text(c(10, 100, 1000, 10000), c(13, 13, 13, 13), c("Q1", "Q2", "Q3", "Q4"))
  text(c(2e05, 2e05), c(-1.75, 1.75), c("LFC = -1", "LFC =1"))
  legend("topright", c("Non SDE Genes", "SDE genes"), col=c("gray32", "red3"), pch=20, bty="n")
  
  #-------------------------------------------------------------------------
  #Computational time
  comput.time <- sapply(results.full, function(x) x$time)[3, ]
  names(comput.time) <- methods.name
  saveRDS(comput.time, "comput.time.RData")
  


##############################################################################################################################################################

#Concordance Analysis based on Zhangdata
  
  ###### Set working directory
  setwd('Zhang')
  
  #importing data
  read <- readRDS("data/Zhang_Data_20and20.RData")
  counts  <- read$counts
  group  <- read$group
  mRNA <- read$mRNA ; mRNA <- rownames(counts)[which(rownames(counts) %in% mRNA)]
  lncRNA <- read$lncRNA ; lncRNA <- rownames(counts)[which(rownames(counts) %in% lncRNA)]

  counts <- counts[which(rowSums(counts[, group == levels(group)[1]]) > 0 &
                           rowSums(counts[, group == levels(group)[2]]) > 0),]
  counts.mRNA   <- counts[rownames(counts) %in% mRNA, ]
  counts.lncRNA <- counts[rownames(counts) %in% lncRNA, ]
  
  dim(counts) ; dim(counts.mRNA) ; dim(counts.lncRNA)
  #29303 genes, in which 19252 mRNA genes and 10051 lncRNAs
  
  ### Exploratory Data Analysis 
  
  #Correlation summary
  cor.summary <- function(counts, group){
    group <- as.factor(group)
    counts <- counts[, c(which(group == levels(group)[1]), 
                         which(group == levels(group)[2]))]
    
    WC1 <- cor(counts[, which(group == levels(group)[1])])
    WC1 <- WC1[lower.tri(WC1, diag = FALSE)]
    WC2 <- cor(counts[, which(group == levels(group)[2])])
    WC2 <- WC2[lower.tri(WC2, diag = FALSE)]
    
    WC.summary <- quantile(c(WC1, WC2), prob=c(0, 0.25, 0.5, 0.75, 1))
    
    BC <- cor(counts)[1:length(which(group == levels(group)[1])),
                      (length(which(group == levels(group)[1]))+1):length(group)]
    BC <- BC[lower.tri(BC, diag = FALSE)]
    BC.summary <- quantile(BC, prob=c(0, 0.25, 0.5, 0.75, 1))
    
    return(list(within.cor=WC.summary, between.cor =BC.summary ))
  }
  cor.summary(counts.full[mRNA,], group.full)
  cor.summary(counts.full[lncRNA,], group.full)
  
  #Library sizes
  summary(colSums(counts.full[mRNA,])) ; summary(colSums(counts.full[lncRNA,]))
  #Exolring biological coefficient of variability (BCV) using edgeR
 
  library(edgeR)
  win.graph()
  par(mfrow=c(1,2))
  #mRNA
  y.mRNA <- DGEList(counts=counts.full[mRNA,], group=group.full)
  y.mRNA <- calcNormFactors(y.mRNA)
  y.mRNA <- estimateDisp(y.mRNA, design)
  plotBCV(y.mRNA, ylim=c(0, 12), main="Zhang (mRNA)", cex.lab=1.5)
  text(7, 4, "Common Dispersion = 0.453 \n Common BCV = 0.673", cex=1.5, col=2)
  
  #lncRNA
  y.lncRNA <- DGEList(counts=counts.full[lncRNA,], group=group.full)
  y.lncRNA <- calcNormFactors(y.lncRNA)
  design <- model.matrix(~group.full)
  y.lncRNA <- estimateCommonDisp(y.lncRNA, design)
  y.lncRNA <- estimateGLMCommonDisp(y.lncRNA, design, verbose=TRUE)
  y.lncRNA <- estimateGLMTrendedDisp(y.lncRNA, design)
  y.lncRNA <- estimateGLMTagwiseDisp(y.lncRNA, design)
  plotBCV(y.lncRNA, ylim=c(0, 12), main="Zhang (lncRNA)", cex.lab=1.5)
  text(7, 4, "Common Dispersion = 0.541 \n Common BCV = 0.735", cex=1.5, col=2)
  
  y <- DGEList(counts=counts.full, group=group.full)
  y <- calcNormFactors(y)
  design <- model.matrix(~group.full)
  y <- estimateDisp(y, design)
  biotype <- rep(NA, nrow(counts.full))
  biotype[which(rownames(counts.full) %in% mRNA)] <- "mRNA"
  biotype[which(rownames(counts.full) %in% lncRNA)] <- "lncRNA"
  vioplot::vioplot(log(y$tagwise.dispersion)~biotype)
  
  
  #PCA plot to setect batch effect
  library("DESeq2")
  dds <- DESeqDataSetFromMatrix(counts, DataFrame(group), ~ group)
  dds <- estimateSizeFactors(dds)
  dds <- dds[ rowSums(counts(dds, normalize=T)) > 1, ]
  nrow(dds)
  rld <- rlog(dds, blind = FALSE)
  DESeq2::plotPCA(rld, intgroup="group", ntop = 1000)
  
  
  #### Running DGE analysis
  ###### Set analysis output object
  results.full <- list()
  
  # edgeR - classic
  results.full["edgeR_classic"] <- list(runedgeR_classic(count.dat=counts, conditions=group,
                                                         colors=colors,path=outputpath))
  # edgeR - glm
  results.full["edgeR_glm"] <- list(runedgeR_glm(count.dat=counts, conditions=group,
                                                 colors=colors,path=outputpath))
  # edgeR - robust 
  results.full["edgeR_rob"] <- list(runedgeR_rob(count.dat=counts, conditions=group,
                                                 colors=colors,path=outputpath))
  # edgeR - quasi-likelihood 
  results.full["edgeR_ql"] <- list(runedgeR_ql(count.dat=counts, conditions=group,
                                               colors=colors,path=outputpath))
  
  # DESeq
  results.full["DESeq"] <- list(runDESeq(count.dat=counts, conditions=group,
                                         colors=colors,path=outputpath))
  # DESeq2
  results.full["DESeq2"] <- list(runDESeq2(count.dat=counts, conditions=group,
                                           colors=colors,path=outputpath))
  # Limma + quantile normalization
  results.full["LimmaQN"] <- list(runLimmaQN(count.dat=counts, conditions=group,
                                             colors=colors,path=outputpath))
  # LimmaVoom (without quality weights)
  results.full["LimmaVoom"] <- list(runLimmaVoom(count.dat=counts, conditions=group,
                                                 colors=colors,path=outputpath))
  # LimmaVoom (with quality weights)
  results.full["LimmaVoom_QW"] <- list(runLimmaVoom_QW(count.dat=counts, conditions=group,
                                                       colors=colors,path=outputpath))
  # LimmaVst 
  results.full["LimmaVst"] <- list(runLimmaVst(count.dat=counts, conditions=group,
                                               colors=colors,path=outputpath))
  # BaySeq
  results.full["BaySeq"] <- list(runBaySeq(count.dat=counts, conditions=group,
                                           colors=colors,path=outputpath))
  
  # PoissonSeq 
  results.full["PoissonSeq"] <- list(runPoissonSeq(count.dat=counts, conditions=group,
                                                   colors=colors,path=outputpath))
  # SAMSeq
  results.full["SAMSeq"] <- list(runSAMSeq(count.dat=counts, conditions=group,
                                           colors=colors,path=outputpath))
  
  # QuasiSeq
  results.full["QuasiSeq"] <- list(runQuasiSeq(count.dat=counts, conditions=group,
                                               colors=colors,path=outputpath))
  
  #Saving result
  saveRDS(results.full, file="result_full_Zhang.RData")
  
  
  
  #### Concordance Analysis between DE tools 
  #Loading saved result of CRC AZA analysis
  results.full <- readRDS("result_full_Zhang.RData")
  methods <- names(results.full)
  
  ## organaizing results
  library(DESeq)
  cds <- DESeq::newCountDataSet(counts, group)
  cds <- DESeq::estimateSizeFactors(cds)
  norm.counts <- counts(cds, normalized=TRUE)
  
  classical.LFC.estimates <- data.frame(classical.LFC = apply(norm.counts, 1, function(x) {
    mu.g1 <- mean(x[group==levels(group)[1]])
    mu.g2 <- mean(x[group==levels(group)[2]])
    if(mu.g1 != 0 & mu.g2 != 0) {lfc <- log2(mu.g2/mu.g1)}
    else if(mu.g1 != 0 & mu.g2 == 0) {lfc <- -log2(mu.g1)}
    else if(mu.g1 == 0 & mu.g2 != 0) {lfc <- log2(mu.g2)}
    return(lfc) }))
  classical.LFC.estimates$ID <- rownames(classical.LFC.estimates)
  
  Merge.DE.results <- function(results.full, na.treat ="keep"){
    #A function that returns the rank of genes for all methods 
    methods <-  names(results.full)
    
    df1 <- results.full[1][[paste(methods[1])]]$summary
    df1 <- merge(df1, classical.LFC.estimates, by="ID", all.x=T, all.y=T)
    df1$pval[is.na(df1$pval)] <- 1
    df1$signed.pval <- sign(df1$classical.LFC)*(df1$pval+1e-5)  #A constant +1e-5 is added to each pvalues to avoid 0 signed p-value when p-value is 0
    df1$pi.score <- abs(df1$classical.LFC)*(-log10(df1$pval+1e-5))
    
    df2 <- results.full[2][[paste(methods[2])]]$summary
    df2 <- merge(df2, classical.LFC.estimates, by="ID", all.x=T, all.y=T)
    df2$pval[is.na(df2$pval)] <- 1
    df2$signed.pval <- sign(df2$classical.LFC)*(df2$pval+1e-5)
    df2$pi.score <- abs(df2$classical.LFC)*(-log10(df2$pval+1e-5))
    
    
    summary.all <- merge(df1, df2, by ="ID", all.x=T, all.y=T)
    colnames(summary.all) <- c("ID", paste(methods[1],".", c(colnames(df1)), sep="")[-1], 
                               paste(methods[2],".", c(colnames(df2)), sep="")[-1])
    
    for(i in 3:length(methods)){
      df.i <- results.full[i][[paste(methods[i])]]$summary
      df.i <- merge(df.i, classical.LFC.estimates, by="ID", all.x=T, all.y=T)
      df.i$pval[is.na(df.i$pval)] <- 1
      
      if(methods[i] != "SAMSeq"){
        df.i$signed.pval <- sign(df.i$classical.LFC)*(df.i$pval+1e-5)
        df.i$pi.score <- abs(df.i$classical.LFC)*(-log10(df.i$pval+1e-5))
      }
      
      if(methods[i] == "SAMSeq"){
        df.i$stat[is.na(df.i$stat)] <- 0
        df.i$signed.pval <- sign(df.i$classical.LFC)*(1/abs(df.i$stat+1e-5))
        df.i$pi.score <- abs(df.i$classical.LFC)*(-log10(1/abs(df.i$stat+1e-5)))
      }
      colnames(df.i) <- c("ID", paste(methods[i], ".", colnames(df.i), sep="")[-1])
      
      summary.all <- merge(summary.all, df.i, by ="ID", all.x=T, all.y=T)
      #colnames(summary.all) <- c("ID", methods[1:i])
    }
    
    rownames(summary.all) <- summary.all$ID
    summary.all <- summary.all[,-1]
    
    return(summary.all)
  }
  
  
  #Merging summary results of all the methods
  summary.all <- Merge.DE.results(results.full)
  dim(summary.all)
  
  methods.name <- c("edgeR exact", "edgeR GLM", "edgeR robust", "edgeR QL", "DESeq", "DESeq2", "limmaQN", "limmaVoom", "limmaVoom + QW", "limmaVst", 
                    "baySeq", "PoissonSeq", "SAMSeq", "QuasiSeq")
  
  
  
  #------------------------------------------------------------------------#
  #GENE RANK ANALYSIS 
  #Spearman's Rank Correlation Matrix
  #columns <- paste(methods,".", "signed.pval", sep="")
  columns <- paste(methods,".", "pi.score", sep="")
  score.matrix <- summary.all[,c(columns)]
  colnames(score.matrix) <- methods.name
  
  #classical LFC estimates
  columns <- paste(methods,".", "classical.LFC", sep="")
  LFC.matrix <- summary.all[,c(columns)]
  colnames(LFC.matrix) <- methods.name
  LFC.matrix <- as.data.frame(lapply(LFC.matrix, function(x) replace(x, is.infinite(x),NA)))
  rownames(LFC.matrix) <- rownames(summary.all)
  
  
  #subsetting the top commonly identifed SDE genes across methods
  columns <- paste(methods,".", "padj", sep="")
  padj.matrix <- summary.all[,c(columns)]
  padj.matrix[is.na(padj.matrix)] = 1   #replacing NA values by 1
  colnames(padj.matrix) <- methods.name
  
  common.SDE.genes <- names(which(apply(padj.matrix, 1, function(x) {
    if(max(x) < 1) {return(1)}
    else {return(0)}}) == 1))
  length(common.SDE.genes)
  common.SDE.genes.mRNA <- common.SDE.genes[which(common.SDE.genes %in% mRNA)]
  common.SDE.genes.lncRNA <- common.SDE.genes[which(common.SDE.genes %in% lncRNA)]
  length(common.SDE.genes.mRNA) ; length(common.SDE.genes.lncRNA)
  
  #Rank correlation, ranks scores and if there are ties, it uses auxillary information to break ties
  rank.cov <- function(y, x=NULL, na.last=TRUE, ties.method="average"){
    r <- y
    if(is.null(x)) {r <- rank(y, na.last=na.last, ties.method=ties.method)}
    else if(!is.null(x)){
      r.temp <- rank(y, na.last=na.last, ties.method="min")
      t.r <- table(r.temp)
      ties <- as.numeric(names(which(t.r>1)))
      if(length(ties)>=1) {
        for(i in 1:length(ties)){
          r.cov <- rank(x[r.temp==ties[i]])-1
          r.temp[r.temp==ties[i]] <- r.temp[r.temp==ties[i]] + r.cov
        }
      }
      else{
        r.temp <- rank(y, na.last=na.last, ties.method=ties.method)
      }
      r <- r.temp 
    }
    return(r)
  }
  
  #mRNA
  rank.matrix.mRNA <- apply(score.matrix[which(rownames(score.matrix) %in% mRNA), ], 2, function(v){
    rank.cov(v, x=LFC.matrix[which(rownames(LFC.matrix) %in% mRNA), 1])
  })
  rank.matrix.mRNA <- rank.matrix.mRNA[common.SDE.genes.mRNA, ]
  
  #lncRNA
  rank.matrix.lncRNA <- apply(score.matrix[which(rownames(score.matrix) %in% lncRNA), ], 2, function(v){
    rank.cov(v, x=LFC.matrix[which(rownames(LFC.matrix) %in% lncRNA), 1])
  })
  rank.matrix.lncRNA <- rank.matrix.lncRNA[common.SDE.genes.lncRNA, ]
  
  
  #mRNA
  cor.rank.mRNA <- round(cor(rank.matrix.mRNA, use = "pairwise.complete.obs", method ="spearman"), 3)
  cor.rank.mRNA.2 <- cor.rank.mRNA
  diag(cor.rank.mRNA.2) <- NA
  mean.cor.mRNA <- apply(cor.rank.mRNA.2, 1, function(x) mean(x, na.rm=T))
  saveRDS(mean.cor.mRNA, "mean.rank.cor.mRNA.RData")
  
  cor.rank.mRNA[lower.tri(cor.rank.mRNA, diag = T)] <- NA
  cor.rank.mRNA
  
  library(reshape2)
  cor.dat.mRNA <- melt(cor.rank.mRNA, na.rm = TRUE)
  colnames(cor.dat.mRNA) <- c("X1", "X2", "value")
  cor.dat.mRNA$X1<- factor(cor.dat.mRNA$X1, levels = methods.name)
  cor.dat.mRNA$X2<- factor(cor.dat.mRNA$X2, levels = methods.name)
  cor.dat.mRNA <- cor.dat.mRNA[!is.na(cor.dat.mRNA$value),]
  
  
  #lncRNA
  cor.rank.lncRNA <- round(cor(rank.matrix.lncRNA, use = "pairwise.complete.obs", method ="spearman"), 3)
  cor.rank.lncRNA.2 <- cor.rank.lncRNA
  diag(cor.rank.lncRNA.2) <- NA
  mean.cor.lncRNA <- apply(cor.rank.lncRNA.2, 1, function(x) mean(x, na.rm=T))
  saveRDS(mean.cor.lncRNA, "mean.rank.cor.lncRNA.RData")
  
  cor.rank.lncRNA[lower.tri(cor.rank.lncRNA, diag = T)] <- NA
  cor.rank.lncRNA
  
  library(reshape2)
  cor.dat.lncRNA <- melt(cor.rank.lncRNA, na.rm = TRUE)
  colnames(cor.dat.lncRNA) <- c("X1", "X2", "value")
  cor.dat.lncRNA$X1<- factor(cor.dat.lncRNA$X1, levels = methods.name)
  cor.dat.lncRNA$X2<- factor(cor.dat.lncRNA$X2, levels = methods.name)
  cor.dat.lncRNA <- cor.dat.lncRNA[!is.na(cor.dat.lncRNA$value),]
  

  
  library(ggplot2)
  library("scales") 
  library(gridExtra)
  
  win.graph()
  pl1 <- ggplot(cor.dat.mRNA, aes(X2, ordered(X1, levels=methods.name), fill = value))+
    geom_tile(aes(fill = value))+labs(title="mRNA")+
    scale_fill_gradientn(limit = c(0.75, 1), space = "Lab", colours = c("white", "blue"),
                         name="Spearman\n rank correlation") +
    theme_minimal()+ # minimal theme
    theme(axis.text.x = element_text(angle = 45, vjust = 1, 
                                     size = 12, hjust = 1))+
    scale_x_discrete(breaks=methods.name, labels=methods.name)+
    scale_y_discrete(breaks=methods.name, labels=methods.name)+
    coord_fixed()+
    geom_text(aes(X2, X1, label = value), color = "black", size = 4) +
    theme(
      axis.title.x = element_blank(),
      axis.title.y = element_blank(),
      panel.grid.major = element_blank(),
      panel.border = element_blank(),
      panel.background = element_blank(),
      axis.ticks = element_blank(),
      legend.justification = c(1, 0),
      legend.position = c(0.6, 0.7),
      legend.direction = "horizontal")+
    guides(fill = guide_colorbar(barwidth = 7, barheight = 1,
                                 title.position = "top", title.hjust = 0.5))
  
  pl2 <- ggplot(cor.dat.lncRNA, aes(X2, ordered(X1, levels=methods.name), fill = value))+
    geom_tile(aes(fill = value))+labs(title="lncRNA")+
    scale_fill_gradientn(limit = c(0.75, 1), space = "Lab", colours = c("white", "blue"),
                         name="Spearman\n rank correlation") +
    theme_minimal()+ # minimal theme
    theme(axis.text.x = element_text(angle = 45, vjust = 1, 
                                     size = 12, hjust = 1))+
    scale_x_discrete(breaks=methods.name, labels=methods.name)+
    scale_y_discrete(breaks=methods.name, labels=methods.name)+
    coord_fixed()+
    geom_text(aes(X2, X1, label = value), color = "black", size = 4) +
    theme(
      axis.title.x = element_blank(),
      axis.title.y = element_blank(),
      panel.grid.major = element_blank(),
      panel.border = element_blank(),
      panel.background = element_blank(),
      axis.ticks = element_blank(),
      legend.justification = c(1, 0),
      legend.position = c(0.6, 0.7),
      legend.direction = "horizontal")+
    guides(fill = guide_colorbar(barwidth = 7, barheight = 1,
                                 title.position = "top", title.hjust = 0.5))
  
  grid.arrange(pl1, pl2, ncol=2)
  
  #------------------------------------------------------------------------#
  #ANALYSIS OF NUMBER OF DE GENES and CLLASSIFICATION OVERLAPPING
  columns <- paste(methods,".", "padj", sep="")
  padj.matrix <- summary.all[,c(columns)]
  colnames(padj.matrix) <- methods
  
  DE.indicator <- padj.matrix
  for(i in 1:nrow(padj.matrix)){
    for(j in 1:ncol(padj.matrix)){
      if(padj.matrix[i,j] < 0.05 & is.na(padj.matrix[i,j]) == F) DE.indicator[i,j] <- 1
      else if(padj.matrix[i,j] >= 0.05 & is.na(padj.matrix[i,j]) == F) DE.indicator[i,j] <- 0
    }
  }
  

  biotype <- ifelse(rownames(DE.indicator) %in% mRNA, "mRNA", "lncRNA")
  library(reshape)
  DE.indicator2 <- melt(DE.indicator)
  DE.indicator2 <- data.frame(DE.indicator2, biotype =rep(biotype, times=length(methods)))
  colnames(DE.indicator2) <- c("Methods", "DE", "biotype")
  
  agr <- aggregate(DE~Methods+biotype, data=DE.indicator2, FUN=sum)
  agr.all <- aggregate(DE~Methods, data=DE.indicator2, FUN=sum)
  agr.all$Methods <- agr$Methods <- methods.name
  saveRDS(list(agr.all=agr.all, agr=agr), "SDE.summary.RData")
  
  library(ggplot2)
  library(gridExtra)
  
  win.graph()
  pl1 <- ggplot(agr, aes(x=reorder(Methods, DE), y=DE, fill=biotype)) + 
    geom_bar(stat="identity", position = "stack")+ 
    theme(axis.text.x = element_text(angle = 45, hjust = 1), 
          legend.position=c(0.2, 0.9)) + 
    scale_x_discrete(breaks=methods.name, labels=methods.name)+
    labs(title="A", x="DE tools", y="mumber of SDE genes (at 5% FDR)",
         fill="genes biotypes")
  
  pl2 <- ggplot(agr,  aes(x=Methods, y=DE, fill=biotype)) + 
    geom_bar(stat="identity", position = "fill")+
    theme(axis.text.x = element_text(angle = 45, hjust = 1), legend.position='none') + 
    scale_x_discrete(breaks=methods.name, labels=methods.name)+
    labs(title="B", x="DE tools", y="proportion")
  grid.arrange(pl1, pl2, ncol=2)
  
  
  #Overlapping of DE classification
  #mRNA
  DE.indicator.mRNA <- DE.indicator[which(rownames(DE.indicator) %in% mRNA), ]
  overlap.mRNA <- matrix(NA, ncol=length(methods), nrow=length(methods))
  for(i in 1:nrow(overlap.mRNA)){
    for(j in 1:ncol(overlap.mRNA)){
      overlap.mRNA[i,j] <- length(which(DE.indicator.mRNA[,i]==1 & DE.indicator.mRNA[,j]==1))
    }
  }
  colnames(overlap.mRNA) <- methods.name
  rownames(overlap.mRNA) <- methods.name
  
  non.overlap.mRNA.A <- matrix(NA, ncol=length(methods), nrow=length(methods))
  for(i in 1:nrow(non.overlap.mRNA.A)){
    for(j in 1:ncol(non.overlap.mRNA.A)){
      non.overlap.mRNA.A[i,j] <- length(which(DE.indicator.mRNA[,i]==1 & DE.indicator.mRNA[,j]==0))
    }
  }
  colnames(non.overlap.mRNA.A) <- methods.name
  rownames(non.overlap.mRNA.A) <- methods.name

  non.overlap.mRNA.B <- t(non.overlap.mRNA.A)

  overlap.mRNA.prop <-overlap.mRNA/(non.overlap.mRNA.A+overlap.mRNA+non.overlap.mRNA.B)
  rownames(overlap.mRNA.prop) <- methods.name
  colnames(overlap.mRNA.prop) <- methods.name
  
  # number_of.SDE.mRNA <- diag(overlap.mRNA)
  # base.mRNA <- overlap.mRNA
  # for(i in 1:nrow(base.mRNA)){
  #   for(j in 1:ncol(base.mRNA)){
  #     base.mRNA[i,j] <- min(number_of.SDE.mRNA[i], number_of.SDE.mRNA[j])
  #   }
  # }
  # overlap.prop.mRNA <- overlap.mRNA/base.mRNA
  # rownames(overlap.prop.mRNA) <- methods.name
  # colnames(overlap.prop.mRNA) <- methods.name
  
  overlap.prop.mRNA <-  overlap.mRNA.prop
  overlap.prop.mRNA.2 <- overlap.prop.mRNA
  diag(overlap.prop.mRNA.2) <- NA
  mean.overlap.mRNA <- apply( overlap.prop.mRNA.2, 1, function(x) mean(x, na.rm=T))
  saveRDS(mean.overlap.mRNA, "mean.overlap.prop.mRNA.RData")
  
  
  library(reshape2)
  overlap.prop.mRNA[lower.tri(overlap.prop.mRNA, diag = T)] <- NA
  overlap.mRNA.dat <- melt(overlap.prop.mRNA, na.rm = TRUE)
  colnames(overlap.mRNA.dat) <- c("X1", "X2", "value")
  overlap.mRNA.dat$X1<- factor(overlap.mRNA.dat$X1, levels = methods.name)
  overlap.mRNA.dat$X2<- factor(overlap.mRNA.dat$X2, levels = methods.name)
  overlap.mRNA.dat <- overlap.mRNA.dat[!is.na(overlap.mRNA.dat$value),]
  overlap.mRNA.dat[, "value"] <- round(overlap.mRNA.dat[, "value"], 3)
  
  #lncRNA
  DE.indicator.lncRNA <- DE.indicator[which(rownames(DE.indicator) %in% lncRNA), ]
  overlap.lncRNA <- matrix(NA, ncol=length(methods), nrow=length(methods))
  for(i in 1:nrow(overlap.lncRNA)){
    for(j in 1:ncol(overlap.lncRNA)){
      overlap.lncRNA[i,j] <- length(which(DE.indicator.lncRNA[,i]==1 & DE.indicator.lncRNA[,j]==1))
    }
  }
  colnames(overlap.lncRNA) <- methods.name
  rownames(overlap.lncRNA) <- methods.name
  
  non.overlap.lncRNA.A <- matrix(NA, ncol=length(methods), nrow=length(methods))
  for(i in 1:nrow(non.overlap.lncRNA.A)){
    for(j in 1:ncol(non.overlap.lncRNA.A)){
      non.overlap.lncRNA.A[i,j] <- length(which(DE.indicator.lncRNA[,i]==1 & DE.indicator.lncRNA[,j]==0))
    }
  }
  colnames(non.overlap.lncRNA.A) <- methods.name
  rownames(non.overlap.lncRNA.A) <- methods.name

  non.overlap.lncRNA.B <- t(non.overlap.lncRNA.A)

  overlap.lncRNA.prop <-overlap.lncRNA/(non.overlap.lncRNA.A+overlap.lncRNA+non.overlap.lncRNA.B)
  rownames(overlap.lncRNA.prop) <- methods.name
  colnames(overlap.lncRNA.prop) <- methods.name
  
  # number_of.SDE.lncRNA <- diag(overlap.lncRNA)
  # base.lncRNA <- overlap.lncRNA
  # for(i in 1:nrow(base.lncRNA)){
  #   for(j in 1:ncol(base.lncRNA)){
  #     base.lncRNA[i,j] <- min(number_of.SDE.lncRNA[i], number_of.SDE.lncRNA[j])
  #   }
  # }
  # overlap.prop.lncRNA <- overlap.lncRNA/base.lncRNA
  # rownames(overlap.prop.lncRNA) <- methods.name
  # colnames(overlap.prop.lncRNA) <- methods.name
  
  overlap.prop.lncRNA <- overlap.lncRNA.prop
  overlap.prop.lncRNA.2 <- overlap.prop.lncRNA
  diag(overlap.prop.lncRNA.2) <- NA
  mean.overlap.lncRNA <- apply( overlap.prop.lncRNA.2, 1, function(x) mean(x, na.rm=T))
  saveRDS(mean.overlap.lncRNA, "mean.overlap.prop.lncRNA.RData")
  
  
  library(reshape2)
  overlap.prop.lncRNA[lower.tri(overlap.prop.lncRNA, diag = T)] <- NA
  overlap.lncRNA.dat <- melt(overlap.prop.lncRNA, na.rm = TRUE)
  colnames(overlap.lncRNA.dat) <- c("X1", "X2", "value")
  overlap.lncRNA.dat$X1<- factor(overlap.lncRNA.dat$X1, levels = methods.name)
  overlap.lncRNA.dat$X2<- factor(overlap.lncRNA.dat$X2, levels = methods.name)
  overlap.lncRNA.dat <- overlap.lncRNA.dat[!is.na(overlap.lncRNA.dat$value),]
  overlap.lncRNA.dat[, "value"] <- round(overlap.lncRNA.dat[, "value"], 3)
  
  
  library(ggplot2)
  library("scales") 
  library(gridExtra)
  
  win.graph()
  pl1 <- ggplot(overlap.mRNA.dat, aes(X2, ordered(X1, levels=methods.name), fill = value))+
    geom_tile(aes(fill = value))+labs(title="mRNA")+
    scale_fill_gradientn(limit = c(0.0, 1), space = "Lab", colours = c("white", "blue"),
                         name="overlap proportion") +
    theme_minimal()+ # minimal theme
    theme(axis.text.x = element_text(angle = 45, vjust = 1, 
                                     size = 12, hjust = 1))+
    scale_x_discrete(breaks=methods.name, labels=methods.name)+
    scale_y_discrete(breaks=methods.name, labels=methods.name)+
    coord_fixed()+
    geom_text(aes(X2, X1, label = value), color = "black", size = 4) +
    theme(
      axis.title.x = element_blank(),
      axis.title.y = element_blank(),
      panel.grid.major = element_blank(),
      panel.border = element_blank(),
      panel.background = element_blank(),
      axis.ticks = element_blank(),
      legend.justification = c(1, 0),
      legend.position = c(0.6, 0.7),
      legend.direction = "horizontal")+
    guides(fill = guide_colorbar(barwidth = 7, barheight = 1,
                                 title.position = "top", title.hjust = 0.5))
  pl2 <- ggplot(overlap.lncRNA.dat, aes(X2, ordered(X1, levels=methods.name), fill = value))+
    geom_tile(aes(fill = value))+labs(title="lncRNA")+
    scale_fill_gradientn(limit = c(0.0, 1), space = "Lab", colours = c("white", "blue"),
                         name="overlap proportion") +
    theme_minimal()+ # minimal theme
    theme(axis.text.x = element_text(angle = 45, vjust = 1, 
                                     size = 12, hjust = 1))+
    scale_x_discrete(breaks=methods.name, labels=methods.name)+
    scale_y_discrete(breaks=methods.name, labels=methods.name)+
    coord_fixed()+
    geom_text(aes(X2, X1, label = value), color = "black", size = 4) +
    theme(
      axis.title.x = element_blank(),
      axis.title.y = element_blank(),
      panel.grid.major = element_blank(),
      panel.border = element_blank(),
      panel.background = element_blank(),
      axis.ticks = element_blank(),
      legend.justification = c(1, 0),
      legend.position = c(0.6, 0.7),
      legend.direction = "horizontal")+
    guides(fill = guide_colorbar(barwidth = 7, barheight = 1,
                                 title.position = "top", title.hjust = 0.5))
  grid.arrange(pl1, pl2, ncol=2)
  
  #------------------------------------------------------------------------#
  #ANALYSIS OF LFC
  columns <- paste(methods,".", "logFC", sep="")
  LFC.matrix <- summary.all[,c(columns)]
  colnames(LFC.matrix) <- methods.name
  LFC.matrix <- as.data.frame(lapply(LFC.matrix, function(x) replace(x, is.infinite(x),NA)))
  rownames(LFC.matrix) <- rownames(summary.all)
  
  #Correlation b/n LFC estimates from each method
  ## mRNA
  cor.lfc.mRNA <- cor(LFC.matrix[which(rownames(LFC.matrix) %in% mRNA),-13], 
                      method ="pearson", use="pairwise.complete.obs")
  colnames(cor.lfc.mRNA) <- rownames(cor.lfc.mRNA) <- methods.name[-13]
  cor.lfc.mRNA.2 <- cor.lfc.mRNA
  diag(cor.lfc.mRNA.2) <- NA
  mean.cor.lfc.mRNA <- apply(cor.lfc.mRNA.2, 1, function(x) mean(x, na.rm=T))
  names(mean.cor.lfc.mRNA) <- methods.name[-13]
  saveRDS(mean.cor.lfc.mRNA, "mean.lfc.cor.mRNA.RData")
  
  
  library(reshape2)
  cor.lfc.mRNA[lower.tri(cor.lfc.mRNA, diag = T)] <- NA
  cor.lfc.dat.mRNA <- melt(cor.lfc.mRNA, na.rm = TRUE)
  colnames(cor.lfc.dat.mRNA) <- c("X1", "X2", "value")
  cor.lfc.dat.mRNA$X1<- factor(cor.lfc.dat.mRNA$X1, levels = rownames(cor.lfc.mRNA))
  cor.lfc.dat.mRNA$X2<- factor(cor.lfc.dat.mRNA$X2, levels = rownames(cor.lfc.mRNA))
  cor.lfc.dat.mRNA <- cor.lfc.dat.mRNA[!is.na(cor.lfc.dat.mRNA$value),]
  cor.lfc.dat.mRNA[, "value"] <- round(cor.lfc.dat.mRNA[, "value"], 3)
  
  ## lncRNA
  cor.lfc.lncRNA <- cor(LFC.matrix[which(rownames(LFC.matrix) %in% lncRNA),-13], 
                        method ="pearson", use="pairwise.complete.obs")
  colnames(cor.lfc.lncRNA) <- rownames(cor.lfc.lncRNA) <- methods.name[-13]
  cor.lfc.lncRNA.2 <- cor.lfc.lncRNA
  diag(cor.lfc.lncRNA.2) <- NA
  mean.cor.lfc.lncRNA <- apply(cor.lfc.lncRNA.2, 1, function(x) mean(x, na.rm=T))
  names(mean.cor.lfc.lncRNA) <- methods.name[-13]
  saveRDS(mean.cor.lfc.lncRNA, "mean.lfc.cor.lncRNA.RData")
  
  
  library(reshape2)
  cor.lfc.lncRNA[lower.tri(cor.lfc.lncRNA, diag = T)] <- NA
  cor.lfc.dat.lncRNA <- melt(cor.lfc.lncRNA, na.rm = TRUE)
  colnames(cor.lfc.dat.lncRNA) <- c("X1", "X2", "value")
  cor.lfc.dat.lncRNA$X1<- factor(cor.lfc.dat.lncRNA$X1, levels = rownames(cor.lfc.lncRNA))
  cor.lfc.dat.lncRNA$X2<- factor(cor.lfc.dat.lncRNA$X2, levels = rownames(cor.lfc.lncRNA))
  cor.lfc.dat.lncRNA <- cor.lfc.dat.lncRNA[!is.na(cor.lfc.dat.lncRNA$value),]
  cor.lfc.dat.lncRNA[, "value"] <- round(cor.lfc.dat.lncRNA[, "value"], 3)
  
  
  
  library(ggplot2)
  library("scales") 
  library(gridExtra)
  
  win.graph()
  pl1 <- ggplot(cor.lfc.dat.mRNA, aes(X2, ordered(X1, levels=rownames(cor.lfc.mRNA)), fill = value))+
    geom_tile(aes(fill = value))+labs(title="mRNA")+
    scale_fill_gradientn(limit = c(0.7, 1), space = "Lab", colours = c("white", "blue"),
                         name="Pearson correlation \n between LFC estimates") +
    theme_minimal()+ # minimal theme
    theme(axis.text.x = element_text(angle = 45, vjust = 1, 
                                     size = 12, hjust = 1))+
    scale_x_discrete(breaks=rownames(cor.lfc.mRNA), labels=rownames(cor.lfc.mRNA))+
    scale_y_discrete(breaks=rownames(cor.lfc.mRNA), labels=rownames(cor.lfc.mRNA))+
    coord_fixed()+
    geom_text(aes(X2, X1, label = value), color = "black", size = 4) +
    theme(
      axis.title.x = element_blank(),
      axis.title.y = element_blank(),
      panel.grid.major = element_blank(),
      panel.border = element_blank(),
      panel.background = element_blank(),
      axis.ticks = element_blank(),
      legend.justification = c(1, 0),
      legend.position = c(0.6, 0.7),
      legend.direction = "horizontal")+
    guides(fill = guide_colorbar(barwidth = 7, barheight = 1,
                                 title.position = "top", title.hjust = 0.5))
  pl2 <- ggplot(cor.lfc.dat.lncRNA, aes(X2, ordered(X1, levels=rownames(cor.lfc.lncRNA)), fill = value))+
    geom_tile(aes(fill = value))+labs(title="lncRNA")+
    scale_fill_gradientn(limit = c(0.7, 1), space = "Lab", colours = c("white", "blue"),
                         name="Pearson correlation \n between LFC estimates") +
    theme_minimal()+ # minimal theme
    theme(axis.text.x = element_text(angle = 45, vjust = 1, 
                                     size = 12, hjust = 1))+
    scale_x_discrete(breaks=rownames(cor.lfc.lncRNA), labels=rownames(cor.lfc.lncRNA))+
    scale_y_discrete(breaks=rownames(cor.lfc.lncRNA), labels=rownames(cor.lfc.lncRNA))+
    coord_fixed()+
    geom_text(aes(X2, X1, label = value), color = "black", size = 4) +
    theme(
      axis.title.x = element_blank(),
      axis.title.y = element_blank(),
      panel.grid.major = element_blank(),
      panel.border = element_blank(),
      panel.background = element_blank(),
      axis.ticks = element_blank(),
      legend.justification = c(1, 0),
      legend.position = c(0.6, 0.7),
      legend.direction = "horizontal")+
    guides(fill = guide_colorbar(barwidth = 7, barheight = 1,
                                 title.position = "top", title.hjust = 0.5))
  
  grid.arrange(pl1, pl2, ncol=2)
  
#------------------------------------------------------------------------#
  #For outlying genes 
  Range <- function(count, group.size, cut.point=4){
    range <- matrix(ncol=2, nrow=nrow(count))
    colnames(count) <- rep(c("condA", "condB"), each=group.size)
    for(i in 1:nrow(range)){
      range[i,1] <- (max(count[i,which(colnames(count)=="condA")]) -  min(count[i,which(colnames(count)=="condA")]) - 
                       IQR(count[i,which(colnames(count)=="condA")]))/median(count[i,])
      if(is.infinite(range[i,1])==T) range[i,1] = NA
      
      range[i,2] <- (max(count[i,which(colnames(count)=="condB")]) -  min(count[i,which(colnames(count)=="condB")]) -
                       IQR(count[i,which(colnames(count)=="condB")]))/median(count[i,])
      if(is.infinite(range[i,2])==T) range[i,2] = NA
    }
    range <- round(range, 3)
    colnames(range) <- c("condA", "condB")
    rownames(range) <- rownames(count)
    range <- range[which(range[,1] > cut.point | range[,2] > cut.point), ]
    return(range)
  }
  
  outllying.genes <- Range(count=norm.counts, group.size=20, cut.point = 1000)
  outllying.genes2  <- rownames(outllying.genes)
  
  
  
  #selected.genes <- c("ALX1", "BRS3", "CALB2", "DEFA3", "FGF3", "MYCNUN", "SLC6A3", "TUBA3C")
  selected.genes <- c("KLK4", "PENK", "RP11-17A4.2", "CLEC4M", "METTL21B", "CTAG1A", "FGF3", "SLC6A5")
  View(floor(norm.counts[selected.genes,]))
  win.graph()
  par(mfrow=c(2,4))
  func <- function(gene){
    if(gene %in% lncRNA) return("lncRNA")
    if(gene %in% mRNA) return("mRNA")
  }
  for(i in 1:length(selected.genes)){
    barplot(norm.counts[selected.genes[i], ], col=rep(c("chocolate4",  "darkcyan"), each=20),
            main = paste(selected.genes[i], "(", func(selected.genes[i]) ,")"),
            ylab="normalized counts", xlab="samples", xaxt="n", cex.lab=1.5, cex.main=2.25)
    axis(1, at = 1:40, labels = rep(c(1:20), times=2))
    abline(v=20.5, lty=2, col=1, lwd=0.5)
  }
  
  #DE results for thse outlying genes.
  resultoutlying.genes <- round(padj.matrix[selected.genes,], 3)
  
  ##adjusted.pvalues
  # Genes edgeR_classic edgeR_glm edgeR_rob edgeR_ql DESeq DESeq2 LimmaQN LimmaVoom LimmaVoom_QW LimmaVst BaySeq PoissonSeq SAMSeq QuasiSeq
  # KLK4                0.043     0.044     0.548    0.057 0.753  0.789   0.702     0.766        0.915    0.813  0.581      0.027  1.000    0.030
  # PENK                0.017     0.015     0.303    0.040 0.780  0.300   0.442     0.347        0.170    0.435  0.655      0.008  0.230    0.020
  # RP11-17A4.2         0.000     0.000     0.114    0.002 0.622  0.989   0.322     0.325        0.172    0.432  0.001      0.007  0.371    0.001
  # CLEC4M              0.928     0.894     0.171    0.896 1.000  0.365   0.477     0.405        0.144    0.458  0.787      0.109  0.120    0.430
  # METTL21B            0.000     0.000     0.242    0.000 0.426  0.000   0.201     0.095        0.132    0.210  0.000      0.005  0.307    0.000
  # CTAG1A              0.022     0.025     0.030    0.039 0.795  0.209   0.657     0.381        0.093    0.209  0.003      0.245  0.046    0.020
  # FGF3                0.000     0.000     0.055    0.003 0.655  0.006   0.704     0.580        0.219    0.726  0.000      0.030  0.041    0.002
  # SLC6A5              0.000     0.000     0.000    0.000 0.403  0.010   0.011     0.009        0.008    0.035  0.001      0.002  0.011    0.000

  library(xtable)
  xtable(resultoutlying.genes)
  
  #-------------------------------------------------------------------------
  #Computational time
  comput.time <- sapply(results.full, function(x) x$time)[3, ]
  names(comput.time) <- methods.name
  saveRDS(comput.time, "comput.time.RData")
  
}

#----------------------------------------------------
overall_results_summary <- function(){
  rm(list = ls())
  dir <-"C:\\Users\\Alemu\\Dropbox\\R Analysis\\DataRCodeFinal\\04-Code - Copy\\New file to store R Data\\Overall_results_summary"
  setwd(dir)
  
  #Loading required packages
  #install.packages("devtools")
  library(reshape2)
  library(ggplot2)
  library(corrplot) 
  library(Hmisc) 
  library(gplots)
  
  #Summary of comparison metrics from concordance analysis 
  dir1 <- "C:\\Users\\Alemu\\Dropbox\\R Analysis\\DataRCodeFinal\\04-Code - Copy\\New file to store R Data\\"
  
  
  #data set summary
  datasets.summary <- function(){
    datasets <- data.frame(dataset = c("CRC AZA", "Hammer", "Bottomly", "GTEx", 
                                       "Zhang (mRNA)", "Zhang (lncRNA)", "NGP (mRNA)", "NGP(lncRNA"),
                           number_genes= c(14658, 15908, 12784, 18632, 19254, 10051, 11264, 7942 ),
                           number_of_replicates=c(3, 2, 10.5, 20, 20, 20, 10, 10),
                           median_lib_size = c(36062881, 20510783, 4422073, 44527805, 22576097, 668531.5, 2481000, 177300), 
                           read.length = c(100, 50, 30, 76, 90, 90, 90, 90 ),
                           common.BCV=c(0.098, 0.104, 0.197, 0.577, 0.700, 0.922, 0.432, 0.183))
    datasets$seq_depth <- (datasets$median_lib_size/datasets$number_genes)/50
    datasets
    win.graph()
    plot(seq(0, 50, length.out = 3), seq(0, 1, length.out = 3), type="n", xlab = "sequencing depth",
         ylab="common BCV", xaxt="n", yaxt="n", axes = F, cex.lab=1.25)
    axis(1, at=c(0, 25, 50), labels = c(0, 25, 50),
         lwd=2, col="gray", col.ticks = "gray")
    axis(2, at=c(0, 0.5, 1), labels = c(0, 0.5, 1),
         lwd=2, col="gray", col.ticks = "grey",  las=1)
    points(datasets$seq_depth, datasets$common.BCV, pch=20, cex=c(2, 1, 3, 5, 5, 5)+2)
    datasets2 <- datasets
    datasets2$x= c(49, 28, 5, 45, 25, 4)
    datasets2$y=  c(0.05, 0.05, 0.14, 0.5, 0.6, 0.85)
    text(datasets2$x, datasets2$y, datasets2$dataset)
    
    legend("topright", c("2", "3", "10  ", "  20"), pch=20, pt.cex=c(3, 4, 5, 7), horiz = T,
           title = "number of replicates")
    
    #Emperical distribution of gene wise average expression for each datset
    ##CRC AZA data
    read.CRC_AZA <- readRDS(paste0(dir1, "CRC AZA data analysis//CRC_AZA_data.RData"))
    counts.CRC_AZA <- read.CRC_AZA$counts; group.CRC_AZA <- read.CRC_AZA$group
    counts.CRC_AZA <- counts.CRC_AZA[which(rowSums(counts.CRC_AZA[, group.CRC_AZA == levels(group.CRC_AZA)[1]]) > 0 &
                                             rowSums(counts.CRC_AZA[, group.CRC_AZA == levels(group.CRC_AZA)[2]]) > 0),]
    
    ##Hammer data
    read.Hammer <- readRDS(paste0(dir1, "Hammer//Hammer_data.RData"))
    counts.Hammer <- read.Hammer$counts; group.Hammer <- read.Hammer$group
    counts.Hammer <- counts.Hammer[which(rowSums(counts.Hammer[, group.Hammer == levels(group.Hammer)[1]]) > 0 &
                                           rowSums(counts.Hammer[, group.Hammer == levels(group.Hammer)[2]]) > 0),]
    
    ##Bottomly data
    read.Bottomly <- readRDS(paste0(dir1, "Bottomly//Bottomly_data.RData"))
    counts.Bottomly <- read.Bottomly$counts; group.Bottomly <- read.Bottomly$group
    counts.Bottomly <- counts.Bottomly[which(rowSums(counts.Bottomly[, group.Bottomly == levels(group.Bottomly)[1]]) > 0 &
                                               rowSums(counts.Bottomly[, group.Bottomly == levels(group.Bottomly)[2]]) > 0),]
    
    ##GTEx data
    read.GTEx <- readRDS(paste0(dir1, "GTEx//GTEx_Data_20and20.RData"))
    counts.GTEx <- read.GTEx$counts; group.GTEx <- read.GTEx$group
    counts.GTEx <- counts.GTEx[which(rowSums(counts.GTEx[, group.GTEx == levels(group.GTEx)[1]]) > 0 &
                                       rowSums(counts.GTEx[, group.GTEx == levels(group.GTEx)[2]]) > 0),]
    
    ##Zhang data
    read.Zhang <- readRDS(paste0(dir1, "Zhang//Zhang_Data_20and20.RData"))
    counts.mRNA.Zhang <- read.Zhang$counts.mRNA;counts.lncRNA.Zhang <- read.Zhang$counts.lncRNA; group.Zhang <- read.Zhang$group
    counts.mRNA.Zhang <- counts.mRNA.Zhang[which(rowSums(counts.mRNA.Zhang[, group.Zhang == levels(group.Zhang)[1]]) > 0 &
                                                   rowSums(counts.mRNA.Zhang[, group.Zhang == levels(group.Zhang)[2]]) > 0),]
    
    counts.lncRNA.Zhang <- counts.lncRNA.Zhang[which(rowSums(counts.lncRNA.Zhang[, group.Zhang == levels(group.Zhang)[1]]) > 0 &
                                                       rowSums(counts.lncRNA.Zhang[, group.Zhang == levels(group.Zhang)[2]]) > 0),]
    
    # plot(density(log2(rowMeans(counts.CRC_AZA))), lwd=2, col=1, xaxt="n", yaxt="n", axes=F, 
    #      xlab="log2-mean read counts", ylab="estimated empirical density", main="", cex.lab=1.5)
    # lines(density(log2(rowMeans(counts.Hammer))), lwd=2, col=2)
    # lines(density(log2(rowMeans(counts.Bottomly))), lwd=2, col=3)
    # lines(density(log2(rowMeans(counts.GTEx))), lwd=2, col=4)
    # lines(density(log2(rowMeans(counts.mRNA.Zhang))), lwd=2, col=5)
    # lines(density(log2(rowMeans(counts.lncRNA.Zhang))), lwd=2, col=6)
    
    counts.all <- data.frame(mean.counts = c(rowMeans(counts.lncRNA.Zhang), 
                                             rowMeans(counts.Bottomly), 
                                             rowMeans(counts.mRNA.Zhang),
                                             rowMeans(counts.Hammer),
                                             rowMeans(counts.GTEx),
                                             rowMeans(counts.CRC_AZA)),
                             dats = rep(c("Zhang (lncRNA)", "Bottomly","Zhang (mRNA)",
                                          "Hammer", "GTEx", "CRC AZA"),
                                        c(nrow(counts.lncRNA.Zhang),  nrow(counts.Bottomly),
                                          nrow(counts.mRNA.Zhang), nrow(counts.Hammer),
                                          nrow(counts.GTEx), nrow(counts.CRC_AZA))))
    win.graph()
    p<-ggplot(counts.all, aes(x=factor(dats, as.character(dats)), y=log2(mean.counts), fill=dats)) +
      geom_violin(trim=FALSE, draw_quantiles = c(0.25, 0.5, 0.75)) + 
      labs(x="", y="log2(mean read counts)")+ guides(fill=FALSE)+ theme_minimal()
    p
    
    
  }
  
  #Concordance Analysis results summary
  CA_summary_comparison_metrics <- function(){
    #Number of SDE genes at 5% FDR 
    CRC_AZA.SDE <- readRDS(paste0(dir1,"CRC AZA data analysis\\SDE.summary.RData"))
    CRC_AZA.SDE <-CRC_AZA.SDE[[1]]
    
    Hammer.SDE <- readRDS(paste0(dir1,"Hammer\\SDE.summary.RData"))
    Hammer.SDE <- Hammer.SDE[[1]]
    
    Bottomly.SDE <- readRDS(paste0(dir1,"Bottomly\\SDE.summary.RData"))
    Bottomly.SDE <- Bottomly.SDE[[1]]
    
    GTEx.SDE <- readRDS(paste0(dir1,"GTEx\\SDE.summary.RData"))
    GTEx.SDE <- GTEx.SDE[[1]]
    
    Zhang.SDE <- readRDS(paste0(dir1, "Zhang\\SDE.summary.RData"))
    Zhang.SDE <- Zhang.SDE[[2]]
    Zhang.mRNA.SDE <- Zhang.SDE[Zhang.SDE$biotype=="mRNA", -2]
    Zhang.lncRNA.SDE <- Zhang.SDE[Zhang.SDE$biotype=="lncRNA", -2]
    
    NGP.SDE <- readRDS(paste0(dir1, "NGP Nutlin\\SDE.summary.RData"))
    NGP.SDE <- NGP.SDE[[2]]
    NGP.mRNA.SDE <- NGP.SDE[NGP.SDE$biotype=="mRNA", -2]
    NGP.lncRNA.SDE <- NGP.SDE[NGP.SDE$biotype=="lncRNA", -2]
    
    
    all.SDE <- cbind(CRC_AZA.SDE, Hammer.SDE$DE, Bottomly.SDE$DE, GTEx.SDE$DE, 
                     Zhang.mRNA.SDE$DE, Zhang.lncRNA.SDE$DE, NGP.mRNA.SDE$DE,  NGP.lncRNA.SDE$DE)
    colnames(all.SDE) <- c("Methods", "CRC AZA", "Hammer", "Bottomly", "GTEx", "Zhang (mRNA)", "Zhang (lncRNA)",
                           "NGP Nutlin (mRNA)", "NGP Nutlin (lncRNA)")
    N.CRC_AZA <- 14658; N.Hammer <- 15908 ; N.Bottomly <- 12784
    N.GTEx <- 18632; N.Zhang.mRNA <- 19254 ; N.Zhang.lncRNA <-  10051
    N.NGP.mRNA <- 17489 ; N.NGP.lncRNA <- 8929 
    N <- c(N.CRC_AZA, N.Hammer, N.Bottomly, N.GTEx, N.Zhang.mRNA, N.Zhang.lncRNA, N.NGP.mRNA, N.NGP.lncRNA)
    
    rownames(all.SDE) <- all.SDE$Methods
    all.SDE$Methods<-NULL
    all.SDE.prop <- as.matrix(all.SDE)%*%diag(1/N)
    colnames(all.SDE.prop) <- c("CRC AZA", "Hammer", "Bottomly", "GTEx", "Zhang (mRNA)", "Zhang (lncRNA)",
                           "NGP Nutlin (mRNA)", "NGP Nutlin (lncRNA)")
    
    #Overlap between DE tools at 5% FDR 
    CRC_AZA.mean.overlap <- readRDS(paste0(dir1,"CRC AZA data analysis\\mean.overlap.prop.RData"))
    
    Hammer.mean.overlap <- readRDS(paste0(dir1,"Hammer\\mean.overlap.prop.RData")) 
    
    Bottomly.mean.overlap <- readRDS(paste0(dir1,"Bottomly\\mean.overlap.prop.RData")) 
    
    GTEx.mean.overlap <- readRDS(paste0(dir1,"GTEx\\mean.overlap.prop.RData")) 
    
    Zhang.mean.overlap.mRNA <- readRDS(paste0(dir1, "Zhang\\mean.overlap.mRNA.prop.RData"))
    Zhang.mean.overlap.lncRNA <- readRDS(paste0(dir1, "Zhang\\mean.overlap.lncRNA.prop.RData"))
    
    NGP.mean.overlap.mRNA <- readRDS(paste0(dir1, "NGP Nutlin\\mean.overlap.prop.mRNA.RData"))
    NGP.mean.overlap.lncRNA <- readRDS(paste0(dir1, "NGP Nutlin\\mean.overlap.prop.lncRNA.RData"))
    
    
    all.mean.overlap.prop <-data.frame(CRC_AZA.mean.overlap, Hammer.mean.overlap, Bottomly.mean.overlap, GTEx.mean.overlap, 
                                       Zhang.mean.overlap.mRNA, Zhang.mean.overlap.lncRNA, 
                                       NGP.mean.overlap.mRNA, NGP.mean.overlap.lncRNA)
    colnames(all.mean.overlap.prop) <- c("CRC AZA", "Hammer", "Bottomly", "GTEx", "Zhang (mRNA)", "Zhang (lncRNA)",
                                         "NGP Nutlin (mRNA)", "NGP Nutlin (lncRNA)")
    
    
    #Mean Gene Ranking correlation 
    CRC_AZA.mean.rank.cor <- readRDS(paste0(dir1,"CRC AZA data analysis\\mean.rank.cor.RData")) 
    
    Hammer.mean.rank.cor <- readRDS(paste0(dir1,"Hammer\\mean.rank.cor.RData")) 
    
    Bottomly.mean.rank.cor <- readRDS(paste0(dir1,"Bottomly\\mean.rank.cor.RData")) 
    
    GTEx.mean.rank.cor <- readRDS(paste0(dir1,"GTEx\\mean.rank.cor.RData")) 
    
    Zhang.mean.rank.cor.mRNA <- readRDS(paste0(dir1, "Zhang\\mean.rank.cor.mRNA.RData"))
    Zhang.mean.rank.cor.lncRNA <- readRDS(paste0(dir1, "Zhang\\mean.rank.cor.lncRNA.RData"))
    
    NGP.mean.rank.cor.mRNA <- readRDS(paste0(dir1, "NGP Nutlin\\mean.rank.cor.mRNA.RData"))
    NGP.mean.rank.cor.lncRNA <- readRDS(paste0(dir1, "NGP Nutlin\\mean.rank.cor.lncRNA.RData"))
    
    all.mean.rank.cor <- data.frame(CRC_AZA.mean.rank.cor, Hammer.mean.rank.cor, Bottomly.mean.rank.cor, GTEx.mean.rank.cor, 
                                    Zhang.mean.rank.cor.mRNA, Zhang.mean.rank.cor.lncRNA,
                                    NGP.mean.rank.cor.mRNA, NGP.mean.rank.cor.lncRNA)
    colnames(all.mean.rank.cor) <- c("CRC AZA", "Hammer", "Bottomly", "GTEx", "Zhang (mRNA)", "Zhang (lncRNA)",
                                     "NGP Nutlin (mRNA)", "NGP Nutlin (lncRNA)")
    
    
    
    #Mean LFC correlation summary 
    CRC_AZA.mean.lfc.cor <- readRDS(paste0(dir1,"CRC AZA data analysis\\mean.lfc.cor.RData")) 
    
    Hammer.mean.lfc.cor <- readRDS(paste0(dir1,"Hammer\\mean.lfc.cor.RData")) 
    
    Bottomly.mean.lfc.cor <- readRDS(paste0(dir1,"Bottomly\\mean.lfc.cor.RData")) 
    
    GTEx.mean.lfc.cor <- readRDS(paste0(dir1,"GTEx\\mean.lfc.cor.RData")) 
    
    Zhang.mean.lfc.cor.mRNA <- readRDS(paste0(dir1, "Zhang\\mean.lfc.cor.mRNA.RData"))
    Zhang.mean.lfc.cor.lncRNA <- readRDS(paste0(dir1, "Zhang\\mean.lfc.cor.lncRNA.RData"))
    
    NGP.mean.lfc.cor.mRNA <- readRDS(paste0(dir1, "NGP Nutlin\\mean.lfc.cor.mRNA.RData"))
    NGP.mean.lfc.cor.lncRNA <- readRDS(paste0(dir1, "NGP Nutlin\\mean.lfc.cor.lncRNA.RData"))
    
    all.mean.lfc.cor <- data.frame(CRC_AZA.mean.lfc.cor, Hammer.mean.lfc.cor, Bottomly.mean.lfc.cor, GTEx.mean.lfc.cor, 
                                   Zhang.mean.lfc.cor.mRNA, Zhang.mean.lfc.cor.lncRNA,
                                   NGP.mean.lfc.cor.mRNA, NGP.mean.lfc.cor.lncRNA)
    
    colnames(all.mean.lfc.cor) <- c("CRC AZA", "Hammer", "Bottomly", "GTEx", "Zhang (mRNA)", "Zhang (lncRNA)",
                                    "NGP Nutlin (mRNA)", "NGP Nutlin (lncRNA)")
    
    
    
    #Comuptation time summary 
    CRC_AZA.comp.time <- readRDS(paste0(dir1, "CRC AZA data analysis\\comput.time.RData"))
    Hammer.comp.time <- readRDS(paste0(dir1, "Hammer\\comput.time.RData"))
    Bottomly.comp.time <- readRDS(paste0(dir1, "Bottomly\\comput.time.RData"))
    GTEx.comp.time <- readRDS(paste0(dir1, "GTEx\\comput.time.RData"))
    Zhang.comp.time <- readRDS(paste0(dir1, "Zhang\\comput.time.RData"))
    NGP.comp.time <- readRDS(paste0(dir1, "NGP Nutlin\\comput.time.RData"))
    
    all.comput.time <- data.frame(CRC_AZA.comp.time, Hammer.comp.time, Bottomly.comp.time,
                                  GTEx.comp.time, Zhang.comp.time,  NGP.comp.time)
    colnames(all.comput.time) <- c("CRC AZA", "Hammer", "Bottomly", "GTEx", "Zhang", "NGP Nutlin")
    all.inv.comput.time.log <- log(1/all.comput.time)
    log.inv.comp.time.z_scores <- apply(all.inv.comput.time.log, 2, function(x) (x-mean(x))/sd(x))
    
    
  }
  
  
  #Hierarchical clustering of DE tools for each comparison metrics, across datsest
  metrics_marginal_summary <- function(){
    
    win.graph()
    par(mfrow=c(1,2))
    #Proportion of SDE genes
    SDE.prop.summary <- data.frame(CRC_AZA    = all.SDE.prop[rownames(all.SDE.prop), "CRC AZA"],
                                   Hammer      = all.SDE.prop[rownames(all.SDE.prop), "Hammer"],
                                   Bottomly    = all.SDE.prop[rownames(all.SDE.prop), "Bottomly"],
                                   GTEx        = all.SDE.prop[rownames(all.SDE.prop), "GTEx"],
                                   Zhang.mRNA  = all.SDE.prop[rownames(all.SDE.prop), "Zhang (mRNA)"],
                                   Zhang.lncRNA= all.SDE.prop[rownames(all.SDE.prop), "Zhang (lncRNA)"],
                                   NGP.mRNA  = all.SDE.prop[rownames(all.SDE.prop), "NGP Nutlin (mRNA)"],
                                   NGP.lncRNA= all.SDE.prop[rownames(all.SDE.prop), "NGP Nutlin (lncRNA)"],
                                   row.names = rownames(all.SDE.prop))
    SDE.prop.summary.z_score <- apply(SDE.prop.summary, 2, function(x) (x - mean(x))/sd(x))
    mean.z_score.SDE <- sort(apply(SDE.prop.summary.z_score, 1, mean))
    errbar(x=c(1:length(mean.z_score.SDE)), y=mean.z_score.SDE, 
           yminus = apply(SDE.prop.summary.z_score, 1, min)[names(mean.z_score.SDE)],
           yplus = apply(SDE.prop.summary.z_score, 1, max)[names(mean.z_score.SDE)], axes = FALSE,
           pch=20, cex=2, ylim=c(-3, 3),  xaxt="n", yaxt="n", xlab="", ylab="standard score")
    title(main = "Rank of DE tools based on  proportion of SDE genes (at 5% FDR)")
    axis(2, at=c(-3, 0, 3), labels = c(-3, 0, 3),  las=2, lwd=2, col="gray")
    axis(1, at=c(1:length(mean.z_score.SDE)), labels = FALSE,
         las=2, padj=0, col="gray", lwd=2)
    text(x=1:length(mean.z_score.SDE), y=par()$usr[3]-0.03*(par()$usr[4]-par()$usr[3]),
         labels=names(mean.z_score.SDE), srt=35, adj=1, xpd=TRUE)
    # for(i in 1:length(mean.z_score.SDE)){
    #   y <- SDE.prop.summary.z_score[names(mean.z_score.SDE)[i], ]
    #   text(rep(i+0.25, 6), y,  paste(data.names[names(y), "shoert.names"]), 
    #        cex=0.8, col=as.character(data.names[names(y), "cols"]), offset = 0.2)
    # }
    d <- dist(as.matrix(SDE.prop.summary.z_score))   
    hc <- hclust(d)                
    mypal = c( "#1B676B", "#556270", "#FF6B6B", "#C44D58",  "#4ECDC4")
    clus3 = cutree(hc, 3)
    plot(as.phylo(hc),  tip.color = mypal[clus3], label.offset = 1,
         main="Hierarchical clustering")
    
    win.graph()
    SDE.prop.summary.z_score2 <- SDE.prop.summary.z_score
    colnames(SDE.prop.summary.z_score2) <- c("CRC AZA", "Hammer", "Bottomly", "GTEx", "Zhang (mRNA)", "Zhang (lncRNA)",
                                             "NGP Nutlin (mRNA)", "NGP Nutlin (lncRNA)")
    range <- sort(apply(SDE.prop.summary.z_score2, 2, function(x) mean(x, trim = 0.1)   ))
    
    errbar(x=1:8, y=colMeans(SDE.prop.summary.z_score2)[names(range)], 
           yminus = apply(SDE.prop.summary.z_score2,2,min)[names(range)],
           yplus = apply(SDE.prop.summary.z_score2,2,max)[names(range)], pch=20, cex=2, ylim=c(-3, 3),  
           axes=F, xlab="", ylab="standard score", lwd=2, cex.lab=1.25)
    title(main="")
    abline(h=c(-3,-2, -1, 0, 1, 2, 3), col="gray", lty=3)
    axis(2, at=c(-3, 0, 3), labels = c(-3, 0, 3),  las=2, lwd=2, col="gray")
    axis(1, at=c(1:8), labels = FALSE, las=2, padj=0, col="gray", lwd=2)
    text(x=1:8, y=par()$usr[3]-0.03*(par()$usr[4]-par()$usr[3]),
         labels=names(range), srt=25, adj=1, xpd=TRUE)
    
    
    SDE.prop.summary.z_score2 <- melt(SDE.prop.summary.z_score)
    base_size <- 9
    ggplot(SDE.prop.summary.z_score2, aes(Var2,Var1, fill=value))+
      geom_raster()+
      scale_fill_gradient(low = "red", high = "yellow", limits=c(-3,3))+
      theme_grey(base_size = base_size) + 
      labs(x = "", y = "") + 
      scale_x_discrete(expand = c(0, 0)) +
      scale_y_discrete(expand = c(0, 0)) 
    #Proportion of overlap
    win.graph()
    overlap.prop.summary <- data.frame(CRC_AZA = all.mean.overlap.prop[rownames(all.SDE.prop), "CRC AZA"],
                                       Hammer      = all.mean.overlap.prop[rownames(all.SDE.prop), "Hammer"],
                                       Bottomly    = all.mean.overlap.prop[rownames(all.SDE.prop), "Bottomly"],
                                       GTEx        = all.mean.overlap.prop[rownames(all.SDE.prop), "GTEx"],
                                       Zhang.mRNA  = all.mean.overlap.prop[rownames(all.SDE.prop), "Zhang (mRNA)"],
                                       Zhang.lncRNA= all.mean.overlap.prop[rownames(all.SDE.prop), "Zhang (lncRNA)"],
                                       NGP.mRNA  = all.mean.overlap.prop[rownames(all.SDE.prop), "NGP Nutlin (mRNA)"],
                                       NGP.lncRNA= all.mean.overlap.prop[rownames(all.SDE.prop), "NGP Nutlin (lncRNA)"],
                                       row.names = rownames(all.SDE.prop))
    overlap.prop.summary.z_score <- apply(overlap.prop.summary, 2,  function(x) (x - mean(x))/sd(x))
    mean.z_score.overlap <- sort(apply(overlap.prop.summary.z_score, 1, mean))
    errbar(x=c(1:length(mean.z_score.overlap)), y=mean.z_score.overlap, 
           yminus = apply(overlap.prop.summary.z_score, 1, min)[names(mean.z_score.overlap)],
           yplus = apply(overlap.prop.summary.z_score, 1, max)[names(mean.z_score.overlap)], axes = FALSE,
           pch=20, cex=2, ylim=c(-3, 3),  xaxt="n", yaxt="n", xlab="", ylab="standard score")
    title(main = "Rank of DE tools based on  proportion of overlap (at 5% FDR)")
    axis(2, at=c(-3, 0, 3), labels = c(-3, 0, 3),  las=2, lwd=2, col="gray")
    axis(1, at=c(1:length(mean.z_score.overlap)), labels = FALSE,
         las=2, padj=0, col="gray", lwd=2)
    text(x=1:length(mean.z_score.overlap), y=par()$usr[3]-0.03*(par()$usr[4]-par()$usr[3]),
         labels=names(mean.z_score.overlap), srt=35, adj=1, xpd=TRUE)
    # for(i in 1:length(mean.z_score.overlap)){
    #   y <- overlap.prop.summary.z_score[names(mean.z_score.overlap)[i], ]
    #   text(rep(i+0.25, 6), y,  paste(data.names[names(y), "shoert.names"]), 
    #        cex=0.8, col=as.character(data.names[names(y), "cols"]), offset = 0.2)
    # }
    d <- dist(as.matrix(overlap.prop.summary.z_score))   
    hc <- hclust(d)                
    mypal = c( "#1B676B", "#556270", "#FF6B6B", "#C44D58",  "#4ECDC4")
    clus3 = cutree(hc, 3)
    plot(as.phylo(hc),  tip.color = mypal[clus3], label.offset = 1,
         main="Hierarchical clustering")
    
    
    
    #Mean gene ranking agreement
    win.graph()
    rank.correlation.summary <- data.frame(CRC_AZA = all.mean.rank.cor[rownames(all.SDE.prop), "CRC AZA"],
                                           Hammer      = all.mean.rank.cor[rownames(all.SDE.prop), "Hammer"],
                                           Bottomly    = all.mean.rank.cor[rownames(all.SDE.prop), "Bottomly"],
                                           GTEx        = all.mean.rank.cor[rownames(all.SDE.prop), "GTEx"],
                                           Zhang.mRNA  = all.mean.rank.cor[rownames(all.SDE.prop), "Zhang (mRNA)"],
                                           Zhang.lncRNA= all.mean.rank.cor[rownames(all.SDE.prop), "Zhang (lncRNA)"],
                                           NGP.mRNA  = all.mean.rank.cor[rownames(all.SDE.prop), "NGP Nutlin (mRNA)"],
                                           NGP.lncRNA= all.mean.rank.cor[rownames(all.SDE.prop), "NGP Nutlin (lncRNA)"],
                                           row.names = rownames(all.SDE.prop))
    rank.correlation.summary.z_score <- apply(rank.correlation.summary, 2, function(x) (x - mean(x))/sd(x))
    mean.z_score.cor.rank <- sort(apply(rank.correlation.summary.z_score, 1, mean))
    errbar(x=c(1:length(mean.z_score.cor.rank)), y=mean.z_score.cor.rank, 
           yminus = apply(rank.correlation.summary.z_score, 1, min)[names(mean.z_score.cor.rank)],
           yplus = apply(rank.correlation.summary.z_score, 1, max)[names(mean.z_score.cor.rank)], axes = FALSE,
           pch=20, cex=2, ylim=c(-3.6, 3),  xaxt="n", yaxt="n", xlab="", ylab="standard score")
    title(main = "Rank of DE tools based on  proportion of cor.rank (at 5% FDR)")
    axis(2, at=c(-3, 0, 3), labels = c(-3, 0, 3),  las=2, lwd=2, col="gray")
    axis(1, at=c(1:length(mean.z_score.cor.rank)), labels = FALSE,
         las=2, padj=0, col="gray", lwd=2)
    text(x=1:length(mean.z_score.cor.rank), y=par()$usr[3]-0.03*(par()$usr[4]-par()$usr[3]),
         labels=names(mean.z_score.cor.rank), srt=35, adj=1, xpd=TRUE)
    # for(i in 1:length(mean.z_score.cor.rank)){
    #   y <- cor.rank.prop.summary.z_score[names(mean.z_score.cor.rank)[i], ]
    #   text(rep(i+0.25, 6), y,  paste(data.names[names(y), "shoert.names"]), 
    #        cex=0.8, col=as.character(data.names[names(y), "cols"]), offset = 0.2)
    # }
    d <- dist(as.matrix(rank.correlation.summary.z_score))   
    hc <- hclust(d)                
    mypal = c( "#1B676B", "#556270", "#FF6B6B", "#C44D58",  "#4ECDC4")
    clus3 = cutree(hc, 3)
    plot(as.phylo(hc),  tip.color = mypal[clus3], label.offset = 1,
         main="Hierarchical clustering")
    
    
    #Mean LFC correlation
    win.graph()
    par(mfrow=c(1,2))
    lfc.correlation.summary <- data.frame(CRC_AZA      = all.mean.lfc.cor[rownames(all.SDE.prop), "CRC AZA"],
                                          Hammer      = all.mean.lfc.cor[rownames(all.SDE.prop), "Hammer"],
                                          Bottomly    = all.mean.lfc.cor[rownames(all.SDE.prop), "Bottomly"],
                                          GTEx        = all.mean.lfc.cor[rownames(all.SDE.prop), "GTEx"],
                                          Zhang.mRNA  = all.mean.lfc.cor[rownames(all.SDE.prop), "Zhang (mRNA)"],
                                          Zhang.lncRNA= all.mean.lfc.cor[rownames(all.SDE.prop), "Zhang (lncRNA)"],
                                          NGP.mRNA  = all.mean.lfc.cor[rownames(all.SDE.prop), "NGP Nutlin (mRNA)"],
                                          NGP.lncRNA= all.mean.lfc.cor[rownames(all.SDE.prop), "NGP Nutlin (lncRNA)"],
                                          row.names = rownames(all.SDE.prop))
    lfc.correlation.summary <- lfc.correlation.summary[-c(13),]
    lfc.correlation.summary.z_score <- apply(lfc.correlation.summary, 2, function(x) (x - mean(x))/sd(x))
    mean.lfc.z_score <- sort(apply(lfc.correlation.summary.z_score, 1, mean))
    errbar(x=c(1:length(mean.lfc.z_score)), y=mean.lfc.z_score, 
           yminus = apply(lfc.correlation.summary.z_score, 1, min)[names(mean.lfc.z_score)],
           yplus  = apply(lfc.correlation.summary.z_score, 1, max)[names(mean.lfc.z_score)], axes = FALSE,
           pch=20, cex=2, ylim=c(-3, 3),  xaxt="n", yaxt="n", xlab="", ylab="standard score")
    title(main = "Rank of DE tools based on mean LFC similarity")
    axis(2, at=c(-3, 0, 3), labels = c(-3, 0, 3),  las=2, lwd=2, col="gray")
    axis(1, at=c(1:length(mean.lfc.z_score)), labels = FALSE,
         las=2, padj=0, col="gray", lwd=2)
    text(x=1:length(mean.lfc.z_score), y=par()$usr[3]-0.03*(par()$usr[4]-par()$usr[3]),
         labels=names(mean.lfc.z_score), srt=35, adj=1, xpd=TRUE)
    # for(i in 1:length(mean.rank)){
    #   y <- lfc.correlation.summary.rank[names(mean.rank)[i], ]
    #   text(rep(i+0.2, 6), y,  paste(data.names[names(y), "shoert.names"]), 
    #        cex=0.8, col=as.character(data.names[names(y), "cols"]), offset = 0.2)
    # }
    
    # Hierarchical clustering of DE tools
    d <- dist(as.matrix(lfc.correlation.summary.rank))   # find distance matrix 
    hc <- hclust(d)                # apply hirarchical clustering 
    mypal = c( "#1B676B", "#556270", "#FF6B6B", "#C44D58",  "#4ECDC4")
    # cutting dendrogram in 3 clusters
    clus3 = cutree(hc, 3)
    # plot
    #op = par(bg = "#E8DDCB")
    # Size reflects miles per gallon
    plot(as.phylo(hc),  tip.color = mypal[clus3], label.offset = 1,
         main="Hierarchical clustering")
  }
  
  #Hierarchical clustering of DE tools avaraged over datasets
  marginal_summary <- function(){
    
    Z_scores.DE <- data.frame(SDE.prop = rowMeans(SDE.prop.summary.z_score)[rownames(all.SDE.prop)],
                              mean.overlap = rowMeans(overlap.prop.summary.z_score)[rownames(all.SDE.prop)],
                              mean.gene.rank.cor = rowMeans(rank.correlation.summary.z_score)[rownames(all.SDE.prop)],
                              mean.LFC.cor = rowMeans(lfc.correlation.summary.z_score)[rownames(all.SDE.prop)],
                              mean.inv.comp.time = rowMeans(log.inv.comp.time.z_scores)[rownames(all.SDE.prop)])
    
    Z_scores.DE.sel <- Z_scores.DE[,c(1,2,3,4)]
    
    cor.DE <- cor(t(Z_scores.DE.sel), method = "pearson", use="pairwise.complete.obs")
    
    library(corrplot)
    win.graph()
    col2 <- colorRampPalette(c("#67001F", "#B2182B", "#D6604D", "#F4A582", "#FDDBC7",
                               "#FFFFFF", "#D1E5F0", "#92C5DE", "#4393C3", "#2166AC", "#053061"))  
    
    corrplot(cor.DE, order="hclust", col=c("black", "white"),
             bg="lightblue", tl.srt=45, addrect=3)
    
    # Dissimilarity matrix
    d <- dist(Z_scores.DE.sel)
    # Hierarchical clustering using Ward's method
    res.hc <- hclust(d, method = "ward.D2" )
    # Plot the obtained dendrogram
    
    plot(res.hc, col = "black", col.main = "gray20", col.lab = "gray30", main="",
         col.axis = "gray40", lwd = 2, lty = 1, sub = "", hang = -1, axes = FALSE)
    rect.hclust(res.hc, k = 3, border = c("firebrick", "goldenrod3", "mediumseagreen"))
    axis(side = 2, at = seq(0, 5, 1), col = "gray50", labels = FALSE, 
         lwd = 1.75)
    # add text in margin
    mtext(seq(0, 5, 1), side = 2, at = seq(0, 5, 1), line = 1, lwd=1.5,
          col = "gray50", las = 2)
    
    
    #How the number of clusters are determined
    k.max <- 10# Maximal number of clusters
    data <- dist(Z_scores.DE.sel)
    wss <- sapply(1:k.max, 
                  function(k){kmeans(data, k, nstart=10 )$tot.withinss})
    plot(1:k.max, wss,
         type="b", pch = 19, frame = FALSE, 
         xlab="Number of clusters K",
         ylab="Total within-clusters sum of squares")
    abline(v = 3, lty =2)
    
    
    #Heatmap plot
    Z.scores <- as.matrix(Z_scores.DE.sel[c("limmaQN", "DESeq", "baySeq",  "QuasiSeq", "edgeR exact", 
                                            "edgeR GLM", "edgeR QL", "limmaVst", "PoissonSeq", "SAMSeq", "edgeR robust", "limmaVoom", "DESeq2", "limmaVoom + QW"), ])
    
    colnames(Z.scores) <- c("A", "B", "C", "D")
    
    win.graph()
    par(mar=c(6,2,2,1))
    heatmap.2(t(Z.scores), dendrogram='none', Rowv=FALSE, Colv=FALSE,trace='none', cexRow=0.7)
    
    Z.scores2 <- melt(Z.scores)
    base_size <- 9
    ggplot(Z.scores2, aes(Var1,Var2, fill=value))+
      geom_tile()+
      scale_fill_gradient2(low = "orange", mid = "white", high = "deepskyblue3", limits=c(-2,2))+
      theme_grey(base_size = base_size) + 
      labs(x = "", y = "") + 
      scale_x_discrete(expand = c(0, 0)) +
      scale_y_discrete(expand = c(0, 0)) 
    
    
    #mRNA vs lncRNA
    SDE.prop      <- all.SDE.prop[, c("Zhang (mRNA)", "Zhang (lncRNA)", "NGP Nutlin (mRNA)", "NGP Nutlin (lncRNA)")]
    colnames(SDE.prop) <- paste0("SDE.prop - ", colnames(SDE.prop))
    overlap.prop  <- all.mean.overlap.prop[rownames(SDE.prop), c("Zhang (mRNA)", "Zhang (lncRNA)", "NGP Nutlin (mRNA)", "NGP Nutlin (lncRNA)")]
    colnames(overlap.prop) <- paste0("overlap.prop - ", colnames(overlap.prop))
    mean.rank.cor <- all.mean.rank.cor[rownames(SDE.prop), c("Zhang (mRNA)", "Zhang (lncRNA)", "NGP Nutlin (mRNA)", "NGP Nutlin (lncRNA)")]
    colnames(mean.rank.cor) <- paste0("mean.rank.cor - ", colnames(mean.rank.cor))
    mean.LFC.cor  <- all.mean.lfc.cor[rownames(SDE.prop), c("Zhang (mRNA)", "Zhang (lncRNA)", "NGP Nutlin (mRNA)", "NGP Nutlin (lncRNA)")]
    colnames(mean.LFC.cor) <- paste0("mean.LFC.cor - ", colnames(mean.LFC.cor))
    
    summary.mat <- cbind(SDE.prop, overlap.prop, mean.rank.cor, mean.LFC.cor)
    summary.mat$DE.tool <- rownames(summary.mat)
    summary.mat <- melt(summary.mat) 
    summary.mat$summary.stat <- sapply(1:nrow(summary.mat), function(i) unlist(strsplit(as.character(summary.mat$variable[i]), "[-]"))[1])
    summary.mat$data         <- sapply(1:nrow(summary.mat), function(i) unlist(strsplit(as.character(summary.mat$variable[i]), "[-]"))[2])
    summary.mat$data.name    <- sapply(1:nrow(summary.mat), function(i) unlist(strsplit(as.character(summary.mat$data[i]), "[(]"))[1])
    summary.mat$biotype      <- sapply(1:nrow(summary.mat), function(i) unlist(strsplit(as.character(summary.mat$data[i]), "[(]"))[2])
    summary.mat$biotype      <- ifelse(summary.mat$biotype=="mRNA)", "mRNA", "lncRNA")
    summary.mat              <- summary.mat[, c("data.name", "biotype", "summary.stat", "DE.tool", "value")]
    summary.mat$summary.stat <- sapply(1:nrow(summary.mat), function(i){
      x <-  summary.mat$summary.stat[i]
      if(x=="mean.LFC.cor ")  {"mean LFC correlation"}
      else if(x== "mean.rank.cor ") {"mean gene ranking correlation"}
      else if(x== "overlap.prop ") {"mean proportion of overlap"}
      else if(x== "SDE.prop ") {"proportion of detected DE genes"}
    })
    summary.mat$abline <- NA
    summary.mat$abline[which(summary.mat$summary.stat =="proportion of detected DE genes" & 
                                    summary.mat$biotype == "mRNA" & summary.mat$data.name ==" Zhang ")] <- 0.61
    summary.mat$abline[which(summary.mat$summary.stat =="proportion of detected DE genes" & 
                                    summary.mat$biotype == "lncRNA" & summary.mat$data.name ==" Zhang ")] <- 0.39
    summary.mat$abline[which(summary.mat$summary.stat =="proportion of detected DE genes" & 
                                    summary.mat$biotype == "mRNA" & summary.mat$data.name ==" NGP Nutlin ")] <- 0.63
    summary.mat$abline[which(summary.mat$summary.stat =="proportion of detected DE genes" & 
                                    summary.mat$biotype == "lncRNA" & summary.mat$data.name ==" NGP Nutlin ")] <- 0.37
    
    win.graph()
    ggplot(summary.mat, aes(x=DE.tool, y=value, group=interaction(biotype, data.name, summary.stat), colour=biotype, shape=biotype))+
      geom_point(stat = "identity", position = "identity", size=3)+
      facet_grid(data.name~summary.stat, as.table=TRUE, scales = "free")+
      coord_flip()+
      scale_color_manual("", values = c("orange", "deepskyblue3")) + 
      theme(axis.title.x = element_text(size=15),
            axis.title.y = element_text(size=15),
            panel.background = element_rect(fill = "gray90", colour = "grey90"),
            strip.text = element_text(size=15),
            legend.position = "top",
            legend.title = element_blank())+
      labs(y="proportion", x="", title="")
      #geom_hline(yintercept = summary.mat$abline)
    
    
  }
  
  
  bar_plots <- function(){
    #overall datasets
    Z_scores.DE <- data.frame(SDE.prop = rowMeans(SDE.prop.summary.z_score)[rownames(all.SDE.prop)],
                              mean.overlap = rowMeans(overlap.prop.summary.z_score)[rownames(all.SDE.prop)],
                              mean.gene.rank.cor = rowMeans(rank.correlation.summary.z_score)[rownames(all.SDE.prop)],
                              mean.LFC.cor = rowMeans(lfc.correlation.summary.z_score)[rownames(all.SDE.prop)],
                              mean.inv.comp.time = rowMeans(log.inv.comp.time.z_scores)[rownames(all.SDE.prop)])
    #Z_scores.DE <- Z_scores.DE[rev(rownames(Z_scores.DE )),]
    library(lattice)
    win.graph()
    mytheme <- list()
    mytheme$strip.border$col = 'grey80'
    mytheme$strip.background$col = 'grey90'
    mytheme$axis.line$col = 'grey80'
    mytheme$axis.text$col = 'grey20'
    trellis.par.set(mytheme)
    pl <- dotplot(as.matrix(Z_scores.DE), groups = FALSE, layout = c(5,1),
                  aspect = "fill", origin = 0, lwd=1, type = c("p", "h"), xlim=c(-2.5, 2.5), 
                  main = "", xlab = "standard scores",
                  par.settings = simpleTheme(lwd=2),
                  par.strip.text =list(cex=1.25, lines=1.5),
                  strip=strip.custom(factor.levels=c("number of detection", "proportion of overlap", 
                                                     "gene ranking agreement", "similarity of LFC estimates", "computation time"),
                                     style=1),
                  panel = function(x, y) { 
                    panel.dotplot(x,y, type = c("p", "h"), pch=20, cex=2)
                    panel.abline(v=0, col = "gray", lwd=0.5)},
                  scales = list(alternating=1, y=list(cex=1.5), x=list(at=c(-2, 0, 2), labels=c(-2, 0, 2))))
    pl
    
    #--------------------------------
    methods <- rownames(Z_scores.DE )
    library(lattice)
    library(gridExtra)
    win.graph()
    mytheme <- list()
    mytheme$strip.border$col = 'grey80'
    mytheme$strip.background$col = 'grey90'
    mytheme$axis.line$col = 'grey80'
    mytheme$axis.text$col = 'grey20'
    trellis.par.set(mytheme)
    
    col_fav1 <- c("deepskyblue4", "blue", "darkcyan", "cyan3", "cyan2", "cyan2",  "lightskyblue")
    col_fav2 <- c("sandybrown", "orange2", "orange3", "orange4")
    
    g <- data.frame(y = Z_scores.DE[, 1],x=rownames(Z_scores.DE))
    pl1 <- dotplot(reorder(x, y)~y, groups = FALSE, layout = c(1,1), data=g,
                   aspect = "fill", origin = 0, lwd=1, type = c("p", "h"), xlim=c(-2.5, 2.5), 
                   main = "", xlab = "standard scores",
                   par.settings = simpleTheme(lwd=2, col=),
                   par.strip.text =list(cex=1.0, lines=1.5),
                   strip=strip.custom(var.name=c("number of detection"),
                                      style=1),
                   panel = function(x, y) { 
                     panel.dotplot(x,y, type = c("p", "h"), pch=20, cex=2)
                     panel.abline(v=0, col = "gray", lwd=0.5)},
                   scales = list(alternating=1, y=list(cex=0.75), x=list(at=c(-2, 0, 2), labels=c(-2, 0, 2))))
    g <- data.frame(y = Z_scores.DE[, 2],x=rownames(Z_scores.DE))
    pl2 <- dotplot(reorder(x, y)~y, groups = FALSE, layout = c(1,1), data=g,
                   aspect = "fill", origin = 0, lwd=1, type = c("p", "h"), xlim=c(-2.5, 2.5), 
                   main = "", xlab = "standard scores",
                   par.settings = simpleTheme(lwd=2),
                   par.strip.text =list(cex=1.0, lines=1.5),
                   strip=strip.custom(factor.levels=c("proportion of overlap" ),
                                      style=1),
                   panel = function(x, y) { 
                     panel.dotplot(x,y, type = c("p", "h"), pch=20, cex=2)
                     panel.abline(v=0, col = "gray", lwd=0.5)},
                   scales = list(alternating=1, y=list(cex=0.75), x=list(at=c(-2, 0, 2), labels=c(-2, 0, 2))))
    g <- data.frame(y = Z_scores.DE[, 3],x=rownames(Z_scores.DE))
    pl3 <- dotplot(reorder(x, y)~y, groups = FALSE, layout = c(1,1), data=g,
                   aspect = "fill", origin = 0, lwd=1, type = c("p", "h"), xlim=c(-2.5, 2.5), 
                   main = "", xlab = "standard scores",
                   par.settings = simpleTheme(lwd=2),
                   par.strip.text =list(cex=1.0, lines=1.5),
                   strip=strip.custom(factor.levels=c("gene ranking agreement"),
                                      style=1),
                   panel = function(x, y) { 
                     panel.dotplot(x,y, type = c("p", "h"), pch=20, cex=2)
                     panel.abline(v=0, col = "gray", lwd=0.5)},
                   scales = list(alternating=1, y=list(cex=0.75), x=list(at=c(-2, 0, 2), labels=c(-2, 0, 2))))
    g <- data.frame(y = Z_scores.DE[, 4],x=rownames(Z_scores.DE))
    pl4 <- dotplot(reorder(x, y)~y, groups = FALSE, layout = c(1,1), data=g,
                   aspect = "fill", origin = 0, lwd=1, type = c("p", "h"), xlim=c(-2.5, 2.5), 
                   main = "", xlab = "standard scores",
                   par.settings = simpleTheme(lwd=2),
                   par.strip.text =list(cex=1.0, lines=1.5),
                   strip=strip.custom(factor.levels=c("Similarity of LFC estimates"),
                                      style=1),
                   panel = function(x, y) { 
                     panel.dotplot(x,y, type = c("p", "h"), pch=20, cex=2)
                     panel.abline(v=0, col = "gray", lwd=0.5)},
                   scales = list(alternating=1, y=list(cex=0.75), x=list(at=c(-2, 0, 2), labels=c(-2, 0, 2))))
    
    
    grid.arrange(pl1, pl2, pl3, pl4, ncol=4)   
  }
  
  correlation_plots <- function(){
    datasets.scores <-  data.frame(names=datasets$dataset, 
                                   score.rep_size=datasets$number_of_replicates,
                                   score.seq_depth = datasets$seq_depth,
                                   score.BCV = datasets$common.BCV)
    
    
    library(corrplot)
    #Proportion of SDE genes
    cor.SDE.prop  <- t(sapply(seq_len(nrow(SDE.prop.summary.z_score)), function(i) {
      cor1 <- cor(SDE.prop.summary.z_score[i, ], datasets.scores[, "score.rep_size"])
      cor2 <- cor(SDE.prop.summary.z_score[i, ], datasets.scores[, "score.seq_depth"])
      cor3 <- cor(SDE.prop.summary.z_score[i, ], datasets.scores[, "score.BCV"])
      c(cor1, cor2, cor3)
    }))
    rownames(cor.SDE.prop) <- rownames(SDE.prop.summary.z_score)
    colnames(cor.SDE.prop) <- paste0("SDE_with_" ,colnames(datasets.scores)[-1])
    
    #Proportion of overlap
    cor.overlap.prop  <- t(sapply(seq_len(nrow(overlap.prop.summary.z_score)), function(i) {
      cor1 <- cor(overlap.prop.summary.z_score[i, ], datasets.scores[, "score.rep_size"])
      cor2 <- cor(overlap.prop.summary.z_score[i, ], datasets.scores[, "score.seq_depth"])
      cor3 <- cor(overlap.prop.summary.z_score[i, ], datasets.scores[, "score.BCV"])
      c(cor1, cor2, cor3)
    }))
    rownames(cor.overlap.prop) <- rownames(overlap.prop.summary.z_score)
    colnames(cor.overlap.prop) <- paste0("overlap_with_" ,colnames(datasets.scores)[-1])
    
    
    #Gene ranking correlation
    cor.gene.rank  <- t(sapply(seq_len(nrow(rank.correlation.summary.z_score)), function(i) {
      cor1 <- cor(rank.correlation.summary.z_score[i, ], datasets.scores[, "score.rep_size"])
      cor2 <- cor(rank.correlation.summary.z_score[i, ], datasets.scores[, "score.seq_depth"])
      cor3 <- cor(rank.correlation.summary.z_score[i, ], datasets.scores[, "score.BCV"])
      c(cor1, cor2, cor3)
    }))
    rownames(cor.gene.rank) <- rownames(rank.correlation.summary.z_score)
    colnames(cor.gene.rank) <- paste0("rank_with_" ,colnames(datasets.scores)[-1])
    
    
    #LFC similarity
    cor.lfc.sim  <- t(sapply(seq_len(nrow(lfc.correlation.summary.z_score)), function(i) {
      cor1 <- cor(lfc.correlation.summary.z_score[i, ], datasets.scores[, "score.rep_size"])
      cor2 <- cor(lfc.correlation.summary.z_score[i, ], datasets.scores[, "score.seq_depth"])
      cor3 <- cor(lfc.correlation.summary.z_score[i, ], datasets.scores[, "score.BCV"])
      c(cor1, cor2, cor3)
    }))
    rownames(cor.lfc.sim) <- rownames(lfc.correlation.summary.z_score)
    colnames(cor.lfc.sim) <- paste0("lfc_with_" ,colnames(datasets.scores)[-1])
    t <- as.data.frame(t(cor.lfc.sim))
    t[, "SAMSeq"]  <- rep(NA, 3)
    cor.lfc.sim <- t(t)
    
    ##All together
    cor.mat <- cbind(cor.SDE.prop[rownames(cor.SDE.prop),], 
                     cor.overlap.prop[rownames(cor.SDE.prop),], 
                     cor.gene.rank[rownames(cor.SDE.prop),], 
                     cor.lfc.sim[rownames(cor.SDE.prop),])
    colnames(cor.mat) <- c("A1", "A2", "A3", "B1", "B2", "B3", "C1", "C2", "C3", "D1", "D2", "D3")
    win.graph() 
    wb <- c("coral3","darkcyan")
    corrplot(cor.mat, col=wb, bg="white", tl.col ="gray20",
             mar = c(1, 1, 1, 1))
    
    library(reshape2)
    cor.dat <- melt(round(cor.mat, 2))
    colnames(cor.dat) <- c("X1", "X2", "value")
    cor.dat$X1<- as.factor(cor.dat$X1)
    cor.dat$X2<- as.factor(cor.dat$X2)
    cor.dat <- cor.dat[!is.na(cor.dat$value),]
    
    library(ggplot2)
    library("scales") 
    
    win.graph()
    methods.name <- rownames(cor.mat)
    ggplot(cor.dat, aes(X2, X1, fill = value))+
      geom_tile(aes(fill = value))+
      scale_fill_gradientn(limit = c(-1, 1), space = "Lab", colours = c("red", "white", "blue"),
                           name="Spearman rank \n correlation") +
      theme_minimal()+ # minimal theme
      theme(axis.text.x = element_text(angle = 45, vjust = 1, 
                                       size = 12, hjust = 1))+
      scale_x_discrete(breaks=methods.name, labels=methods.name)+
      scale_y_discrete(breaks=methods.name, labels=methods.name)+
      coord_fixed()+
      geom_text(aes(X2, X1, label = value), color = "black", size = 4) +
      theme(
        axis.title.x = element_blank(),
        axis.title.y = element_blank(),
        panel.grid.major = element_blank(),
        panel.border = element_blank(),
        panel.background = element_blank(),
        axis.ticks = element_blank(),
        legend.justification = c(1, 0),
        legend.position = c(0.6, 0.7),
        legend.direction = "horizontal")+
      guides(fill = guide_colorbar(barwidth = 7, barheight = 1,
                                   title.position = "top", title.hjust = 0.5))
    
    
  }
  
  
  lncRNA_vs_mRNA <- function(){
    library(reshape2)
    SDE.summary.sub       <- melt(as.matrix(SDE.prop.summary[rownames(all.SDE.prop), c(5:8)]))
    overlap.summary.sub   <- melt(as.matrix(overlap.prop.summary[rownames(all.SDE.prop), c(5:8)]))
    rank_cor.summary.sub  <- melt(as.matrix(rank.correlation.summary[rownames(all.SDE.prop), c(5:8)]))
    LFC_cor.summary.sub   <- melt(as.matrix(lfc.correlation.summary[, c(5:8)]))
    
    summary.sub <- rbind(SDE.summary.sub, overlap.summary.sub, rank_cor.summary.sub, LFC_cor.summary.sub)
    summary.sub$metrics <- rep(c("SDE", "overlap", "rank", "LFC"), c(14*4, 14*4, 14*4, 13*4))
    summary.sub$dat <- NA ;  summary.sub$bty <- NA
    for(i in 1:nrow(summary.sub)){
      summary.sub[i, 5:6] <- unlist(strsplit(as.character(summary.sub$X2[i]), split="[.]"))
    }
    summary.sub <- summary.sub[,c(1,3,4,5,6)]
    colnames(summary.sub) <- c("DE.tool","y", "metrics", "dataset", "biotype")  
    summary.sub$y <- ifelse(summary.sub$biotype =="lncRNA", 1*summary.sub$y, summary.sub$y)
    
    
    library(lattice)
    win.graph()
    mytheme <- list()
    mytheme$strip.border$col = 'grey80'
    mytheme$strip.background$col = 'grey90'
    mytheme$axis.line$col = 'grey80'
    mytheme$axis.text$col = 'grey20'
    trellis.par.set(mytheme)
    pl <- dotplot(DE.tool~y|metrics+dataset, groups = biotype, layout = c(4,2), data=summary.sub,
                  aspect = "fill", origin = 0, lwd=1, type = c("p"), xlim=c(0, 1), 
                  main = "", xlab = "standard scores",
                  par.settings = simpleTheme(lwd=2),
                  par.strip.text =list(cex=1.25, lines=1.5),
                  strip=strip.custom( style=1),
                  panel = function(x, y, groups, subscripts, ...) { 
                    panel.dotplot(x,y, groups = groups, subscripts = subscripts, type = c("p"), 
                                  pch=c(18, 20), cex=1.5, col=c("royalblue","saddlebrown"))
                    panel.abline(v=0, col = "gray", lwd=0.5)},
                  scales = list(alternating=1, y=list(cex=1.5), x=list(at=c(0, 0.5), 
                                                                       labels=c(0, 0.5))))
    pl
  }
  
  
  
  radial_plots <- function(){
    library(fmsb)
    
    cols.de.tools <- c("slateblue4", "palegreen1", "palegreen3", "palegreen4", 
                       "skyblue2","royalblue4",
                       "goldenrod1", "salmon1", "salmon4", "lightpink3", 
                       "gray8", 
                       "purple1", 
                       "gray41", 
                       "mediumvioletred")
    #plot(c(1:14), c(1:14), col=cols.de.tools, pch=20, cex=10)
    marginal.summary.z_score <- 
      data.frame(SDE=rowMeans(SDE.prop.summary.z_score)[rownames(SDE.prop.summary.z_score)],
                 overlap = rowMeans(overlap.prop.summary.z_score)[rownames(SDE.prop.summary.z_score)],
                 gene.rank = rowMeans(rank.correlation.summary.z_score)[rownames(SDE.prop.summary.z_score)],
                 lfc.cor = rowMeans(lfc.correlation.summary.z_score)[rownames(SDE.prop.summary.z_score)],
                 comp.time = rowMeans(log.comp.time.z_scores)[rownames(SDE.prop.summary.z_score)])
    
    marginal.summary.z_score.sel <-  marginal.summary.z_score[c("edgeR robust", "DESeq", "DESeq2",
                                                                "limmaVoom", "baySeq", "PoissonSeq", "SAMSeq"), ]
    marginal.summary.z_score.sel2 <- rbind(rep(2.5, 5) , rep(-2.5, 5) , marginal.summary.z_score.sel) #adding the min and max values
    radarchart(marginal.summary.z_score.sel2, 
               pcol=cols.de.tools , plwd=2 , plty=1)
    legend("topleft", legend = rownames(marginal.summary.z_score.sel2[-c(1,2),]), ncol = 1,
           bty = "n", pch=20 , col=cols.de.tools , text.col = "grey", cex=1.2, pt.cex=3)
    
  }
}





#Buble plots for summarizing comparative studies
studies <- data.frame(study            = c("our", "Rapaport", "Soneson", "Fatemeh", "Lin", "Schurch"),
                      Num.DE.tools     = c(14, 6, 11, 8, 3, 9), 
                      num.RNAseq.data  =c(6, 2,3,2,1,1),
                      gene.biotype     = c(2,1,1,1,1,1), 
                      num.perf.metrics =c(10, 4, 7, 4, 3, 4),
                      norm.included    =c(1,1,0,1,1,0))
fill <- c("orange", "deepskyblue1")
study.name <- c("Assefa et al.", "Rapaport et al.", "Soneson et al.", "Fatemeh et al.", "Lin et al.", "Schurch et al.")
win.graph()
#par(mfrow=c(1,2))
plot(c(1:9), seq(1, 15, length.out = 9), type="n", axes = F, xaxt="n", yaxt="n",
     xlab="number of real RNA-seq data used", ylab="number of DE tools tested")
points(studies$num.RNAseq.data, studies$Num.DE.tools, pch=20, col=fill[studies$norm.included+1], 
       cex=studies$num.perf.metrics/1.25)
points(studies$num.RNAseq.data, studies$Num.DE.tools, pch="+", cex=c(3, 2,0,0,0,0), col="black")
points(studies$num.RNAseq.data, studies$Num.DE.tools, pch="-", cex=c(0, 0,2.5,2.5,2.5,2.5), col="black")

text(studies$num.RNAseq.data+0.8, studies$Num.DE.tools, study.name, col=1,  cex=1.0, offset = 1)
axis(1, at=c(1:6), labels = 1:6, col="gray", lwd=2)
axis(2, at=c(14, 6, 11, 8, 3, 9), labels = c(14, 6, 11, 8, 3, 9), col="gray", lwd=2, las=2)
points(rep(8, 4), c(8, 9, 10, 11.5), pch=20, cex=c(3, 4, 7, 10)/1.25)


