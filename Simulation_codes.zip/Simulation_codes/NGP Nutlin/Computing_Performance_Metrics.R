setwd("C:\\Users\\Alemu\\Dropbox\\R Analysis\\Shiny Application\\DGE_tool_choice_guid\\SimSeq Simulation results\\NGP Nutlin\\Individual simulation results and codes\\DE results\\")
PDE <- c(0, 0.05, 0.1, 0.15, 0.2, 0.25, 0.3)  #Proportion of true DE genes in simulated counts

calc.perf.metrics <- function(q, null,  thrld){
  #This function calculates the four performance comparison metrics: TPR, TNR, FPR, FNR, and FDR
  #TPR 
  if(sum(null==1) > 0){
    tpr <- sum(q<thrld & null == 1)/sum(null == 1) 
  }
  else { tpr <- NA }
  
  #TNR
  if(sum(null==0) > 0){
    tnr <- sum(q >= thrld & null == 0)/sum(null == 0)
  }
  else { tnr <- NA }
  
  #FPR 
  if(sum(null==0) > 0){
    fpr <- sum(q<thrld & null == 0)/sum(null == 0)
  }
  else { fpr <- NA }
  
  #FNR
  if(sum(null == 1) >0){
    fnr <- sum(q>=thrld & null == 1)/sum(null == 1)
  }
  else {  fnr <- NA }
  
  #FDR 
  if(sum(q<thrld) > 0){
    fdr <- sum(q<thrld & null == 0)/sum(q<thrld)
  }
  else { fdr <- 0 } #by definition of FDR (BH95)
  
  return(list(TPR=tpr, TNR=tnr, FPR=fpr, FNR=fnr, FDR=fdr))
}

perf.metrics.list <- list()
fdr.thrld= seq(0, 0.2, 0.005)[-1]  #c(0.01, 0.025, 0.05, 0.1, 0.2)
for(i in 1:length(PDE)){
  print(i)
  DE.result <- readRDS(paste0("DE_result", 100*PDE[i], "PDE.RData"))
  perf.metrics.sub.list <- list()
  for(j in 1:length(fdr.thrld)){
    print(j)
    thrld <- fdr.thrld[j]
    perf.metrics <- lapply(DE.result, function(x){
      t(sapply(x, function(y){
        res <- y$result
        sumr.mRNA <- calc.perf.metrics(res$q[res$biotype=="mRNA"], res$de.genes[res$biotype=="mRNA"], thrld = thrld)
        FNR.mRNA <- sumr.mRNA$FNR
        TPR.mRNA <- sumr.mRNA$TPR
        TNR.mRNA <- sumr.mRNA$TNR
        FPR.mRNA <- sumr.mRNA$FPR
        FDR.mRNA <- sumr.mRNA$FDR
        
        sumr.lncRNA <- calc.perf.metrics(res$q[res$biotype=="lncRNA"], res$de.genes[res$biotype=="lncRNA"], thrld = thrld)
        FNR.lncRNA <- sumr.lncRNA$FNR
        TPR.lncRNA <- sumr.lncRNA$TPR
        TNR.lncRNA <- sumr.lncRNA$TNR
        FPR.lncRNA <- sumr.lncRNA$FPR
        FDR.lncRNA <- sumr.lncRNA$FDR
        
        rep.size <- y$inputs$setting$k.ind
        prop.DE  <- y$inputs$setting$p.diff
        biotype.composition <- unlist(y$inputs$gene.biotype.composition)
        c(FNR.mRNA=FNR.mRNA, TPR.mRNA=TPR.mRNA, TNR.mRNA=TNR.mRNA,FPR.mRNA=FPR.mRNA, 
          FDR.mRNA=FDR.mRNA,
          FNR.lncRNA=FNR.lncRNA, TPR.lncRNA=TPR.lncRNA, TNR.lncRNA=TNR.lncRNA,
          FPR.lncRNA=FPR.lncRNA, FDR.lncRNA=FDR.lncRNA,
          rep.size=rep.size, prop.DE=prop.DE, biotype.composition)
      }))
    })
    perf.metrics2 <- as.data.frame(do.call("rbind", perf.metrics))
    perf.metrics2$DE.tool  <- rep(names(perf.metrics), each=120)
    perf.metrics2$alpha    <- thrld
    perf.metrics.sub.list[j] <- list(perf.metrics2)
  }
  perf.metrics.sub.list <- do.call("rbind", perf.metrics.sub.list)
  rm("DE.result")
  perf.metrics.list[i] <- list(perf.metrics.sub.list)
}
library(data.table)
perf.metrics.list <- rbindlist(perf.metrics.list, fill = TRUE)
saveRDS(perf.metrics.list, "results.All.NGP.RData")


#Defaultsetting
setwd("C:\\Users\\Alemu\\Dropbox\\R Analysis\\Shiny Application\\DGE_tool_choice_guid\\SimSeq Simulation results\\NGP Nutlin\\Default_setting\\")
PDE <- 0.2  #Proportion of true DE genes in simulated counts
fdr.thrld= seq(0, 0.2, 0.005)[-1] #c(0.01, 0.025, 0.05, 0.1, 0.2)
DE.result <- readRDS(paste0("DE_result", 100*PDE, "PDE_default.RData"))
DE.result <- list(DESeq2=DE.result$DESeq2, PoissonSeq=DE.result$PoissonSeq, QuasiSeq=DE.result$QuasiSeq)
perf.metrics.sub.list <- list()
for(j in 1:length(fdr.thrld)){
  print(j)
  thrld <- fdr.thrld[j]
  perf.metrics <- lapply(DE.result, function(x){
    t(sapply(x, function(y){
      res <- y$result
      sumr.mRNA <- calc.perf.metrics(res$q[res$biotype=="mRNA"], res$de.genes[res$biotype=="mRNA"], thrld = thrld)
      FNR.mRNA <- sumr.mRNA$FNR
      TPR.mRNA <- sumr.mRNA$TPR
      TNR.mRNA <- sumr.mRNA$TNR
      FPR.mRNA <- sumr.mRNA$FPR
      FDR.mRNA <- sumr.mRNA$FDR
      
      sumr.lncRNA <- calc.perf.metrics(res$q[res$biotype=="lncRNA"], res$de.genes[res$biotype=="lncRNA"], thrld = thrld)
      FNR.lncRNA <- sumr.lncRNA$FNR
      TPR.lncRNA <- sumr.lncRNA$TPR
      TNR.lncRNA <- sumr.lncRNA$TNR
      FPR.lncRNA <- sumr.lncRNA$FPR
      FDR.lncRNA <- sumr.lncRNA$FDR
      
      rep.size <- y$inputs$setting$k.ind
      prop.DE  <- y$inputs$setting$p.diff
      biotype.composition <- unlist(y$inputs$gene.biotype.composition)
      c(FNR.mRNA=FNR.mRNA, TPR.mRNA=TPR.mRNA, TNR.mRNA=TNR.mRNA,FPR.mRNA=FPR.mRNA, 
        FDR.mRNA=FDR.mRNA,
        FNR.lncRNA=FNR.lncRNA, TPR.lncRNA=TPR.lncRNA, TNR.lncRNA=TNR.lncRNA,
        FPR.lncRNA=FPR.lncRNA, FDR.lncRNA=FDR.lncRNA,
        rep.size=rep.size, prop.DE=prop.DE, biotype.composition)
    }))
  })
  perf.metrics2            <- as.data.frame(do.call("rbind", perf.metrics))
  perf.metrics2$DE.tool    <- rep(names(perf.metrics), each=120)
  perf.metrics2$alpha      <- thrld
  perf.metrics.sub.list[j] <- list(perf.metrics2)
}
perf.metrics.sub.list <- do.call("rbind", perf.metrics.sub.list)
#rm("DE.result")
perf.metrics.list <- perf.metrics.sub.list
perf.metrics.list$setting <- "default"

results.All <- readRDS("C:\\Users\\Alemu\\Dropbox\\R Analysis\\Shiny Application\\DGE_tool_choice_guid\\SimSeq Simulation results\\NGP Nutlin\\results.All.NGP.RData")
results.All.sub <- results.All[results.All$DE.tool %in% c("DESeq2", "PoissonSeq", "QuasiSeq") &
                                 results.All$prop.DE==PDE, ]
results.All.sub$setting <- "non_default"
results.All.default_vs_non_default <- rbind(results.All.sub, perf.metrics.list)
saveRDS(results.All.default_vs_non_default, "results.All.default_vs_non_default.NGP.RData")

