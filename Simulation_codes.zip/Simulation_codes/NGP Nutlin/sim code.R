#load global functions and objects
source("global_functions_and_objects.R")
source("DE_Tools.R")

#Loading source dataset
#Full celine Neuroblastoma dataset
  counts_celine_NB <- readRDS("celine_neuroblastoma_data.RData")
  counts.source <- counts_celine_NB$counts #19206 genes and 20 samples
  group.source <- counts_celine_NB$group
  mRNA <- counts_celine_NB$mRNA
  lncRNA <- counts_celine_NB$lncRNA
  rm("counts_celine_NB")
   
  #proportions
  P.mRNA <- length(mRNA)/nrow(counts.source)
  P.lncRNA <- length(lncRNA)/nrow(counts.source)
  P.mRNA ; P.lncRNA ; P.mRNA + P.lncRNA
  
#Preparation of SimSeq 
lib.sizes <- apply(counts.source, 2, sum)
nf <- calcNormFactors(counts.source) * lib.sizes              #using edgeR package

## Compute weights to sample DE genes in SimData function using edgeR normalization method TMM
probs <- CalcPvalWilcox(counts.source, treatment = group.source, replic = NULL,
                        sort.method = "unpaired", sorted = TRUE, nf, exact = FALSE)

wghts <- 1 - fdrtool(probs, statistic = "pvalue", plot = FALSE, verbose = FALSE)$lfd

#saveRDS(list(probs=probs, weights=wghts), file="weights.RData")

#Simulation Parameter setting
PDE <- c(0, 0.05, 0.1, 0.15, 0.2, 0.25, 0.3)
for(pde in 1:7){
n.genes <- 10000
p.diff <- PDE[pde]  #0, 0.01,  0.05, 0.1, 0.2, 0.3
n.initial <- 11500 #number of genes to be simulated before filtration

par.setting <- list(list(counts.sources = counts.source, group.source = group.source, nf=nf, 
                         k.ind = 2, n.initial=n.initial, n.genes = n.genes, p.diff=p.diff, wghts=wghts),
                    list(counts.sources = counts.source, group.source = group.source, nf=nf,
                         k.ind = 3, n.initial=n.initial, n.genes = n.genes, p.diff=p.diff, wghts=wghts),
                    list(counts.sources= counts.source, group.source = group.source, nf=nf,
                         k.ind = 4, n.initial=n.initial, n.genes = n.genes, p.diff=p.diff, wghts=wghts),
                    list(counts.sources= counts.source, group.source = group.source, nf=nf,
                         k.ind = 5, n.initial=n.initial, n.genes = n.genes, p.diff=p.diff, wghts=wghts))

par.list <- rep(par.setting, each=100)


#generating counts
gene.biotype.source=list(mRNA=mRNA, lncRNA=lncRNA)
sim.counts <- lapply(par.list, FUN=generate.count,  gene.biotype.source=gene.biotype.source)
saveRDS(sim.counts, file=paste0("sim_counts", 100*p.diff, "PDE.RData"), ascii =TRUE)



#Run DE analysis
library(parallel)
cl <- detectCores()
cl <- makeCluster(cl) 
cl

#Running DE Tool wrap functions
source("DE_Tools.R")

res.edgeR.exact    <- parLapplyLB(cl, sim.counts, run_edgeR_exact)
res.edgeR.glm      <- parLapplyLB(cl, sim.counts, run_edgeR_glm)
res.edgeR.robust   <- parLapplyLB(cl, sim.counts, run_edgeR_robust)
res.edgeR.QL       <- parLapplyLB(cl, sim.counts, run_edgeR_ql)
res.DESeq          <- parLapplyLB(cl, sim.counts, run_DESeq)
res.DESeq2         <- parLapplyLB(cl, sim.counts, run_DESeq2) 
res.limmaQN        <- parLapplyLB(cl, sim.counts, run_limmaQN)
res.limmavoom      <- parLapplyLB(cl, sim.counts, run_limmaVoom) 
res.limmavoom_QW   <- parLapplyLB(cl, sim.counts, run_limmaVoom_QW) 
res.limmaVst       <- parLapplyLB(cl, sim.counts, run_limmaVst)
res.PoissonSeq     <- parLapplyLB(cl, sim.counts, run_PoissonSeq)
res.SAMSeq         <- parLapplyLB(cl, sim.counts, run_SAMSeq)
res.QuasiSeq       <- parLapplyLB(cl, sim.counts, run_QuasiSeq)
stopCluster(cl)

results <-list(edgeR.exact  = res.edgeR.exact, 
               edgeR.GLM    = res.edgeR.glm, 
               edgeR.robust = res.edgeR.robust,
               edgeR.QL     = res.edgeR.QL,
               DESeq        = res.DESeq, 
               DESeq2       = res.DESeq2, 
               limmaQN      = res.limmaQN, 
               limmaVoom    = res.limmavoom, 
               limmaVoom_QW = res.limmavoom_QW, 
               limmaVst     = res.limmaVst,
               PoissonSeq   = res.PoissonSeq,  
               SAMSeq       = res.SAMSeq,
               QuasiSeq     = res.QuasiSeq)


saveRDS(results, file=paste0("DE_result", 100*p.diff, "PDE.RData"), ascii =TRUE)
}




