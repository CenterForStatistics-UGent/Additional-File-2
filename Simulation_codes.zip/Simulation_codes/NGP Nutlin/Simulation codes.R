source(global_functions_and_objects)  #SimSeq code is included in this file
source("DE_Tools.R")

#Simulation of gene expression data
#Loading and prepare source dataset 

  counts_celine_NB <- readRDS("celine_neuroblastoma_data.RData") #NGP_Nutlin data
  counts.source <- counts_celine_NB$counts #19206 genes and 20 samples
  group.source <- counts_celine_NB$group
  mRNA <- counts_celine_NB$mRNA
  lncRNA <- counts_celine_NB$lncRNA
  rm("counts_celine_NB")
   
  #proportions
  P.mRNA <- length(mRNA)/nrow(counts.source)
  P.lncRNA <- length(lncRNA)/nrow(counts.source)
  P.mRNA ; P.lncRNA ; P.mRNA + P.lncRNA
  
#Preparation of SimSeq 
lib.sizes <- apply(counts.source, 2, sum)
nf        <- calcNormFactors(counts.source) * lib.sizes              #using edgeR package

## Compute weights to sample DE genes in SimData function using edgeR normalization method TMM
probs     <- CalcPvalWilcox(counts.source, treatment = group.source, replic = NULL,
                        sort.method = "unpaired", sorted = TRUE, nf, exact = FALSE)

wghts <- 1 - fdrtool(probs, statistic = "pvalue", plot = FALSE, verbose = FALSE)$lfd

saveRDS(list(probs=probs, weights=wghts), file="weights.RData")

#Simulation Parameter setting
PDE <- c(0, 0.05, 0.1, 0.15, 0.2, 0.25, 0.3)
for(pde in 1:7){
  n.genes <- 10000
  p.diff  <- PDE[pde]
  n.initial <- 11500 #number of genes to be simulated before filtration
  
  par.setting <- list(list(counts.sources = counts.source, group.source = group.source, nf=nf, 
                         k.ind = 2, n.initial=n.initial, n.genes = n.genes, p.diff=p.diff, wghts=wghts),
                    list(counts.sources = counts.source, group.source = group.source, nf=nf,
                         k.ind = 3, n.initial=n.initial, n.genes = n.genes, p.diff=p.diff, wghts=wghts),
                    list(counts.sources= counts.source, group.source = group.source, nf=nf,
                         k.ind = 4, n.initial=n.initial, n.genes = n.genes, p.diff=p.diff, wghts=wghts),
                    list(counts.sources= counts.source, group.source = group.source, nf=nf,
                         k.ind = 5, n.initial=n.initial, n.genes = n.genes, p.diff=p.diff, wghts=wghts))
  
par.list <- rep(par.setting, each=100)
  
  
  #generating counts
  
  gene.biotype.source=list(mRNA=mRNA, lncRNA=lncRNA)
  sim.counts <- lapply(par.list, FUN=generate.count,  gene.biotype.source=gene.biotype.source)
  saveRDS(sim.counts, file=paste0("sim_counts", 100*p.diff, "PDE.RData"), ascii =TRUE)
  
  
  
  #Run DE analysis
  cl <- detectCores()
  cl <- makeCluster(cl) 
  cl
  
  #Running DE Tool wrap functions
  
  res.edgeR.exact    <- parLapplyLB(cl, sim.counts, run_edgeR_exact)
  res.edgeR.glm      <- parLapplyLB(cl, sim.counts, run_edgeR_glm)
  res.edgeR.robust   <- parLapplyLB(cl, sim.counts, run_edgeR_robust)
  res.edgeR.QL       <- parLapplyLB(cl, sim.counts, run_edgeR_ql)
  res.DESeq          <- parLapplyLB(cl, sim.counts, run_DESeq)
  res.DESeq2         <- parLapplyLB(cl, sim.counts, run_DESeq2) 
  res.limmaQN        <- parLapplyLB(cl, sim.counts, run_limmaQN)
  res.limmavoom      <- parLapplyLB(cl, sim.counts, run_limmaVoom) 
  res.limmavoom_QW   <- parLapplyLB(cl, sim.counts, run_limmaVoom_QW) 
  res.limmaVst       <- parLapplyLB(cl, sim.counts, run_limmaVst)
  res.PoissonSeq     <- parLapplyLB(cl, sim.counts, run_PoissonSeq)
  res.SAMSeq         <- parLapplyLB(cl, sim.counts, run_SAMSeq)
  res.QuasiSeq       <- parLapplyLB(cl, sim.counts, run_QuasiSeq)
  stopCluster(cl)
  
  results <-list(edgeR.exact  = res.edgeR.exact, 
                 edgeR.GLM    = res.edgeR.glm, 
                 edgeR.robust = res.edgeR.robust,
                 edgeR.QL     = res.edgeR.QL,
                 DESeq        = res.DESeq, 
                 DESeq2       = res.DESeq2, 
                 limmaQN      = res.limmaQN, 
                 limmaVoom    = res.limmavoom, 
                 limmaVoom_QW = res.limmavoom_QW, 
                 limmaVst     = res.limmaVst,
                 PoissonSeq   = res.PoissonSeq,  
                 SAMSeq       = res.SAMSeq,
                 QuasiSeq     = res.QuasiSeq)
  
  saveRDS(results, file=paste0("DE_result", 100*p.diff, "PDE.RData"), ascii =TRUE)
}

#-------------------------------------------------------------------------------------------------
rm(list=ls())

#Calculating performance metrics
#load global functions and objects
source("global_functions_and_objects.R")

PDE <- c(0, 0.05, 0.1, 0.15, 0.2, 0.25, 0.3)  #Proportion of true DE genes in simulated counts

perf.metrics.list <- list()
fdr.thrld= seq(0, 0.2, 0.005)[-1] #c(0.01, 0.025, 0.05, 0.1, 0.2)
for(i in 1:length(PDE)){
  print(paste("----------", i))
  DE.result <- readRDS(paste0(dir.NGP, "/DE_result", 100*PDE[i], "PDE.RData"))
  perf.metrics.sub.list <- list()
  for(j in 1:length(fdr.thrld)){
    print(j)
    thrld <- fdr.thrld[j]
    perf.metrics <- lapply(DE.result, function(x){
      t(sapply(x, function(y){
        res <- y$result
        sumr.mRNA <- calc.perf.metrics(res$q[res$biotype=="mRNA"], res$de.genes[res$biotype=="mRNA"], thrld = thrld)
        FNR.mRNA <- sumr.mRNA$FNR
        TPR.mRNA <- sumr.mRNA$TPR
        TNR.mRNA <- sumr.mRNA$TNR
        FPR.mRNA <- sumr.mRNA$FPR
        FDR.mRNA <- sumr.mRNA$FDR
        
        sumr.lncRNA <- calc.perf.metrics(res$q[res$biotype=="lncRNA"], res$de.genes[res$biotype=="lncRNA"], thrld = thrld)
        FNR.lncRNA <- sumr.lncRNA$FNR
        TPR.lncRNA <- sumr.lncRNA$TPR
        TNR.lncRNA <- sumr.lncRNA$TNR
        FPR.lncRNA <- sumr.lncRNA$FPR
        FDR.lncRNA <- sumr.lncRNA$FDR
        
        rep.size <- y$inputs$setting$k.ind
        prop.DE  <- y$inputs$setting$p.diff
        biotype.composition <- unlist(y$inputs$gene.biotype.composition)
        c(FNR.mRNA=FNR.mRNA, TPR.mRNA=TPR.mRNA, TNR.mRNA=TNR.mRNA,FPR.mRNA=FPR.mRNA, 
          FDR.mRNA=FDR.mRNA,
          FNR.lncRNA=FNR.lncRNA, TPR.lncRNA=TPR.lncRNA, TNR.lncRNA=TNR.lncRNA,
          FPR.lncRNA=FPR.lncRNA, FDR.lncRNA=FDR.lncRNA,
          rep.size=rep.size, prop.DE=prop.DE, biotype.composition)
      }))
    })
    perf.metrics2            <- as.data.frame(do.call("rbind", perf.metrics))
    perf.metrics2$DE.tool    <- rep(names(perf.metrics), each=100*4)
    perf.metrics2$alpha      <- thrld
    perf.metrics.sub.list[j] <- list(perf.metrics2)
  }
  perf.metrics.sub.list <- do.call("rbind", perf.metrics.sub.list)
  rm("DE.result")
  perf.metrics.list[i] <- list(perf.metrics.sub.list)
}
library(data.table)
perf.metrics.list <- rbindlist(perf.metrics.list, fill = TRUE)
saveRDS(perf.metrics.list, "results.All.NGP.RData")


#--------------------------------------------------------------------------------------------------
rm(list=ls())

#Summarizing raw simulation results and creating plots

#load global functions and objects
source("global_functions_and_objects.R")


#Load raw simulation result summary and calculating mean and error interval
##NGP
simult.raw.summary.NGP <- readRDS(paste0(dir.NGP, "results.All.NGP.RData"))
simult.summary.NGP <- as.data.frame(do.call(rbind, by(simult.raw.summary.NGP[, c(1:10, 11, 12, 15, 16)],  simult.raw.summary.NGP[, c(11, 12, 15, 16)], calc.summary)))
saveRDS(simult.summary.NGP, paste0(dir.NGP, "simult.summary.NGP.RData"))
simult.summary.NGP <- readRDS(paste0(dir.NGP, "simult.summary.NGP.RData"))
head(simult.summary.NGP)



#-------------
#Plot for the main report 
sel.summary.NGP.a <- simult.summary.NGP[simult.summary.NGP$rep.size %in% c(3, 5) &
                                          simult.summary.NGP$prop.DE %in% c(0.05, 0.3) &
                                          simult.summary.NGP$alpha ==0.05 &
                                          simult.summary.NGP$metrics %in% c("FDR", "TPR"), ]
sel.summary.NGP.a$metrics = factor(sel.summary.NGP.a$metrics, levels = c("FDR", "TPR"))
sel.summary.NGP.a$biotype = factor(sel.summary.NGP.a$biotype, levels = c("mRNA", "lncRNA"))
sel.summary.NGP.a$DE.tool = as.factor(sel.summary.NGP.a$DE.tool)
sel.summary.NGP.a$vline <- ifelse(sel.summary.NGP.a$metrics== "FDR", 0.05, NA)
sel.summary.NGP.a[sel.summary.NGP.a$biotype == "lncRNA", c("ll", "mean", "ul", "vline")] <-
  -1*sel.summary.NGP.a[sel.summary.NGP.a$biotype == "lncRNA", c("ll", "mean", "ul", "vline")]
sel.summary.NGP.a$DE.tool <- factor(sel.summary.NGP.a$DE.tool, 
                                    levels=sel.summary.NGP.a$DE.tool[order(sel.summary.NGP.a$rep.size, sel.summary.NGP.a$prop.DE,
                                                                           sel.summary.NGP.a$biotype, sel.summary.NGP.a$metrics, sel.summary.NGP.a$mean)][13:1])


p <- ggplot(data=sel.summary.NGP.a, 
            aes(y=mean, x=DE.tool, group=biotype, fill=biotype))+
  geom_bar(position="stack", stat="identity", colour = "black", size = 0.1, width = 0.7) +
  coord_flip() + 
  facet_grid(rep.size~ prop.DE+metrics) +
  geom_errorbar(aes(ymin=ll, ymax=ul), width=0.4)+
  scale_fill_manual("", values = alpha(c("deepskyblue3", "orange"), 0.4)) + 
  scale_y_continuous(breaks=c(-0.5, 0, 0.5), labels=c( 0.5, 0, 0.5),  limits=c(-0.85, 0.85)) +
  theme(axis.text.x=element_text(size = 9, colour = "black"), 
        axis.text.y=element_text(size = 9, colour = "black"),
        panel.background = element_rect(fill = NA),
        panel.grid.major = element_line(colour = "grey80"),
        strip.background = element_rect(colour = "black", fill = "white"),
        panel.grid.major.y = element_blank(),
        legend.position="top")+
  geom_hline(aes(yintercept = vline), col="gray25", lty=2)+
  labs(y=NULL, x=NULL) 

png(file=paste0(dir.NGP, "FDR_TPR_NGP_NGP.png"), width=7.25,height=10.25, units = "in", res=700)
p
dev.off()

#Plots added in the additional files are also created in a similar fashion
