#load global functions and objects
source("global_functions_and_objects.R")

# PDE <- c(0.05, 0.2, 0.3)  #Proportion of true DE genes in simulated counts
# fdr.thrld= 0.05  #c(0.01, 0.025, 0.05, 0.1, 0.2)
# perf.metrics.list <- list()
# for(i in 1:length(PDE)){
#   print(i)
#   DE.result <- readRDS(paste0("Default_setting_Zhand_and_NGP_nutlin/DE_result_default_", 100*PDE[i], "PDE.NGP.RData"))
#   perf.metrics.sub.list <- list()
#   for(j in 1:length(fdr.thrld)){
#     print(j)
#     thrld <- fdr.thrld[j]
#     perf.metrics <- lapply(DE.result, function(x){
#       t(sapply(x, function(y){
#         res <- y$result
#         sumr.mRNA <- calc.perf.metrics(res$q[res$biotype=="mRNA"], res$de.genes[res$biotype=="mRNA"], thrld = thrld)
#         FNR.mRNA <- sumr.mRNA$FNR
#         TPR.mRNA <- sumr.mRNA$TPR
#         TNR.mRNA <- sumr.mRNA$TNR
#         FPR.mRNA <- sumr.mRNA$FPR
#         FDR.mRNA <- sumr.mRNA$FDR
#         
#         sumr.lncRNA <- calc.perf.metrics(res$q[res$biotype=="lncRNA"], res$de.genes[res$biotype=="lncRNA"], thrld = thrld)
#         FNR.lncRNA <- sumr.lncRNA$FNR
#         TPR.lncRNA <- sumr.lncRNA$TPR
#         TNR.lncRNA <- sumr.lncRNA$TNR
#         FPR.lncRNA <- sumr.lncRNA$FPR
#         FDR.lncRNA <- sumr.lncRNA$FDR
#         
#         rep.size <- y$inputs$setting$k.ind
#         prop.DE  <- y$inputs$setting$p.diff
#         biotype.composition <- unlist(y$inputs$gene.biotype.composition)
#         c(FNR.mRNA=FNR.mRNA, TPR.mRNA=TPR.mRNA, TNR.mRNA=TNR.mRNA,FPR.mRNA=FPR.mRNA, 
#           FDR.mRNA=FDR.mRNA,
#           FNR.lncRNA=FNR.lncRNA, TPR.lncRNA=TPR.lncRNA, TNR.lncRNA=TNR.lncRNA,
#           FPR.lncRNA=FPR.lncRNA, FDR.lncRNA=FDR.lncRNA,
#           rep.size=rep.size, prop.DE=prop.DE, biotype.composition)
#       }))
#     })
#     perf.metrics2 <- as.data.frame(do.call("rbind", perf.metrics))
#     perf.metrics2$DE.tool  <- rep(names(perf.metrics), each=400)
#     perf.metrics2$alpha    <- thrld
#     perf.metrics.sub.list[j] <- list(perf.metrics2)
#   }
#   perf.metrics.sub.list <- do.call("rbind", perf.metrics.sub.list)
#   rm("DE.result")
#   perf.metrics.list[i] <- list(perf.metrics.sub.list)
# }
# library(data.table)
# perf.metrics.list <- rbindlist(perf.metrics.list, fill = TRUE)
# 
# saveRDS(perf.metrics.list, "Default_setting_Zhand_and_NGP_nutlin/results.default.NGP.RData")

#---------
perf.metrics.default.NGP <- readRDS("Default_setting_Zhand_and_NGP_nutlin/results.default.NGP.RData")
str(perf.metrics.default.NGP)
table(perf.metrics.default.NGP$DE.tool)
perf.metrics.default.NGP$DE.tool <- as.factor(perf.metrics.default.NGP$DE.tool)

# simult.summary.default.NGP <- as.data.frame(do.call(rbind, by(perf.metrics.default.NGP[, c(1:10, 11, 12, 19, 20)],  
#                                                               perf.metrics.default.NGP[, c(11, 12, 19, 20)], convert.names=FALSE, calc.summary)))
# saveRDS(simult.summary.default.NGP, paste0(dir.Zhang, "simult.summary.default.NGP.RData"))
simult.summary.default.NGP <- readRDS(paste0(dir.Zhang, "simult.summary.default.NGP.RData"))
head(simult.summary.default.NGP)
simult.summary.default.NGP$setting  <- ifelse(simult.summary.default.NGP$DE.tool %in% c("DESeq2_default", "PoissonSeq_default"), "default", "not default")
simult.summary.default.NGP$DE.tool2 <- ifelse(simult.summary.default.NGP$DE.tool %in% c("DESeq2_default", "DESeq2"), "DESeq2", "PoissonSeq")
  
  
  

p1 <- ggplot(data=simult.summary.default.NGP[simult.summary.default.NGP$metrics %in% c("FDR", "TPR") &
                                             simult.summary.default.NGP$prop.DE == 0.05, ],
             aes(y=mean, x=rep.size, group=interaction(biotype, setting), colour=biotype, lty=setting))+
  geom_line(lwd=1.5) + geom_point(size=3) +
  #geom_bar(position="stack", stat="identity", colour = "black", size = 0.1, width = 0.7) +
  #coord_flip() + 
  facet_grid(DE.tool2~ metrics) +
  geom_errorbar(aes(ymin=ll, ymax=ul), width=0.15)+
  scale_color_manual("", values = alpha(c("orange", "deepskyblue3"), 1)) + 
  #scale_y_continuous(breaks=c(-0.5, 0, 0.5), labels=c( 0.5, 0, 0.5),  limits=c(-0.85, 0.85)) +
  theme(axis.text=element_text(size = 15, colour = "black"), 
        axis.title=element_text(size = 15, colour = "black"),
        panel.background = element_rect(fill = NA),
        panel.grid.major = element_line(colour = "grey80"),
        strip.background = element_rect(colour = "black", fill = "white"),
        strip.text = element_text(size = 17, colour = "black"),
        legend.text= element_text(size=15),
        legend.key.size  = unit(1.5,"line"), 
        legend.title = element_blank(),
        legend.position = c(0.01, 0.9),
        legend.box = "horizontal",
        legend.justification = "left")+
  #geom_hline(aes(yintercept = vline), col="gray25", lty=2)+
  labs(y=NULL, x="number of replicates", title="5% true DE genes") 
p2 <- ggplot(data=simult.summary.default.NGP[simult.summary.default.NGP$metrics %in% c("FDR", "TPR") &
                                               simult.summary.default.NGP$prop.DE == 0.3, ],
             aes(y=mean, x=rep.size, group=interaction(biotype, setting), colour=biotype, lty=setting))+
  geom_line(lwd=1.5) + geom_point(size=3) +
  #geom_bar(position="stack", stat="identity", colour = "black", size = 0.1, width = 0.7) +
  #coord_flip() + 
  facet_grid(DE.tool2~ metrics) +
  geom_errorbar(aes(ymin=ll, ymax=ul), width=0.15)+
  scale_color_manual("", values = alpha(c("orange", "deepskyblue3"), 1)) + 
  #scale_y_continuous(breaks=c(-0.5, 0, 0.5), labels=c( 0.5, 0, 0.5),  limits=c(-0.85, 0.85)) +
  theme(axis.text=element_text(size = 15, colour = "black"), 
        axis.title=element_text(size = 15, colour = "black"),
        panel.background = element_rect(fill = NA),
        panel.grid.major = element_line(colour = "grey80"),
        strip.background = element_rect(colour = "black", fill = "white"),
        strip.text = element_text(size = 17, colour = "black"),
        legend.text= element_text(size=15),
        legend.key.size  = unit(1.5,"line"), 
        legend.title = element_blank(),
        legend.position = c(0.01, 0.9),
        legend.box = "horizontal",
        legend.justification = "left")+
  #geom_hline(aes(yintercept = vline), col="gray25", lty=2)+
  labs(y=NULL, x="number of replicates", title="30% true DE genes") 

win.graph()
grid.arrange(p1, p2, ncol=2)

png(file=paste0(dir.NGP, "FDR_TPR.sel2.png"), width=7.25,height=5.25, units = "in", res=700)
p
dev.off()