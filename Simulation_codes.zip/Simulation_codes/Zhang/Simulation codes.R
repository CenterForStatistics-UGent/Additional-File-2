source(global_functions_and_objects)  #SimSeq code is included in this file
source("DE_Tools.R")

#Simulation of gene expression data
#Loading and prepare source dataset 

  counts_Neuroblastoma <- readRDS(paste0(dir.Zhang, "/Zhang_data_full.RData"))#Full Zhang dataset
  counts.source <- counts_Neuroblastoma[[1]]  #33605 genes and 172 samples
  group.source <- counts_Neuroblastoma[[2]]
  gr0 <-which(group.source == 0)
  gr1 <-which(group.source == 1)
  counts.source <- counts.source[, c(gr0, gr1)]
  group.source <- group.source[c(gr0, gr1)]
  geneBiotype.source <- counts_Neuroblastoma[[3]]
  rm("counts_Neuroblastoma")
  
  #Genes Biotype
  lncRNA <- geneBiotype.source$Gene_Name[geneBiotype.source$Gene_Biotype %in% c("antisense", "lincRNA")]
  mRNA <- geneBiotype.source$Gene_Name[geneBiotype.source$Gene_Biotype == "protein_coding"]
  length(mRNA) ; length(lncRNA)
  
  #Filtering genes with at least 40 expression across samples within each condition
  keep = which(apply(counts.source[, c(1:81)], 1, function(x) length(which(x==0)))<70 & 
               apply(counts.source[, c(82:171)], 1, function(x) length(which(x==0)))<80)
  length(keep) #27416 genes
  
  counts.source <- counts.source[keep,]
  dim(counts.source)
  lncRNA <- rownames(counts.source)[rownames(counts.source) %in% lncRNA]
  mRNA   <- rownames(counts.source)[rownames(counts.source) %in% mRNA]
  others <- rownames(counts.source)[!(rownames(counts.source) %in% c(mRNA, lncRNA))] #undefined
  length(mRNA) ; length(lncRNA) ; length(others)
  
  intersects <- intersect(mRNA, lncRNA)
  lncRNA     <- lncRNA[!(lncRNA %in%  intersects)]
  mRNA       <- mRNA[!(mRNA %in%  intersects)]
  length(unique(mRNA)) ; length(unique(lncRNA))
  
  counts.source        <- counts.source[!(rownames(counts.source) %in%  c(others, intersects)), ]
  counts.source.mRNA   <- counts.source[which(rownames(counts.source) %in% mRNA),]
  counts.source.lncRNA <- counts.source[which(rownames(counts.source) %in% lncRNA),]
  dim(counts.source) ; dim(counts.source.mRNA) ; dim(counts.source.lncRNA)
  
  #proportions
  P.mRNA <- length(mRNA)/nrow(counts.source)
  P.lncRNA <- length(lncRNA)/nrow(counts.source)
  P.mRNA ; P.lncRNA ; P.mRNA + P.lncRNA
  
#Preparation of SimSeq 
lib.sizes <- apply(counts.source, 2, sum)
nf        <- calcNormFactors(counts.source) * lib.sizes              #using edgeR package

## Compute weights to sample DE genes in SimData function using edgeR normalization method TMM
probs     <- CalcPvalWilcox(counts.source, treatment = group.source, replic = NULL,
                        sort.method = "unpaired", sorted = TRUE, nf, exact = FALSE)

wghts <- 1 - fdrtool(probs, statistic = "pvalue", plot = FALSE, verbose = FALSE)$lfd

saveRDS(list(probs=probs, weights=wghts), file="weights.RData")

#Simulation Parameter setting
PDE <- c(0, 0.05, 0.1, 0.15, 0.2, 0.25, 0.3)
for(pde in 1:7){
  n.genes <- 10000
  p.diff  <- PDE[pde]
  n.initial <- 11500 #number of genes to be simulated before filtration
  
  par.setting <- list(list(counts.sources = counts.source, group.source = group.source, nf=nf, 
                           k.ind = 2, n.initial=n.initial, n.genes = n.genes, p.diff=p.diff, wghts=wghts),
                      list(counts.sources = counts.source, group.source = group.source, nf=nf,
                           k.ind = 3, n.initial=n.initial, n.genes = n.genes, p.diff=p.diff, wghts=wghts),
                      list(counts.sources = counts.source, group.source = group.source, nf=nf,
                           k.ind = 4, n.initial=n.initial, n.genes = n.genes, p.diff=p.diff, wghts=wghts),
                      list(counts.sources= counts.source, group.source = group.source, nf=nf,
                           k.ind = 5, n.initial=n.initial, n.genes = n.genes, p.diff=p.diff, wghts=wghts),
                      list(counts.sources= counts.source, group.source = group.source, nf=nf,
                           k.ind = 7, n.initial=n.initial, n.genes = n.genes, p.diff=p.diff, wghts=wghts),
                      list(counts.sources= counts.source, group.source = group.source, nf=nf,
                           k.ind = 10, n.initial=n.initial, n.genes = n.genes, p.diff=p.diff, wghts=wghts),
                      list(counts.sources= counts.source, group.source = group.source, nf=nf,
                           k.ind = 15, n.initial=n.initial, n.genes = n.genes, p.diff=p.diff, wghts=wghts),
                      list(counts.sources= counts.source, group.source = group.source, nf=nf,
                           k.ind = 20, n.initial=n.initial, n.genes = n.genes, p.diff=p.diff, wghts=wghts),
                      list(counts.sources= counts.source, group.source = group.source, nf=nf,
                           k.ind = 30, n.initial=n.initial, n.genes = n.genes, p.diff=p.diff, wghts=wghts),
                      list(counts.sources= counts.source, group.source = group.source, nf=nf,
                           k.ind = 40, n.initial=n.initial, n.genes = n.genes, p.diff=p.diff, wghts=wghts))
  par.list <- rep(par.setting, each=100)
  
  
  
  #generating counts
  
  gene.biotype.source=list(mRNA=mRNA, lncRNA=lncRNA)
  sim.counts <- lapply(par.list, FUN=generate.count,  gene.biotype.source=gene.biotype.source)
  saveRDS(sim.counts, file=paste0("sim_counts", 100*p.diff, "PDE.RData"), ascii =TRUE)
  
  
  
  #Run DE analysis
  cl <- detectCores()
  cl <- makeCluster(cl) 
  cl
  
  #Running DE Tool wrap functions
  
  res.edgeR.exact    <- parLapplyLB(cl, sim.counts, run_edgeR_exact)
  res.edgeR.glm      <- parLapplyLB(cl, sim.counts, run_edgeR_glm)
  res.edgeR.robust   <- parLapplyLB(cl, sim.counts, run_edgeR_robust)
  res.edgeR.QL       <- parLapplyLB(cl, sim.counts, run_edgeR_ql)
  res.DESeq          <- parLapplyLB(cl, sim.counts, run_DESeq)
  res.DESeq2         <- parLapplyLB(cl, sim.counts, run_DESeq2) 
  res.limmaQN        <- parLapplyLB(cl, sim.counts, run_limmaQN)
  res.limmavoom      <- parLapplyLB(cl, sim.counts, run_limmaVoom) 
  res.limmavoom_QW   <- parLapplyLB(cl, sim.counts, run_limmaVoom_QW) 
  res.limmaVst       <- parLapplyLB(cl, sim.counts, run_limmaVst)
  res.PoissonSeq     <- parLapplyLB(cl, sim.counts, run_PoissonSeq)
  res.SAMSeq         <- parLapplyLB(cl, sim.counts, run_SAMSeq)
  res.QuasiSeq       <- parLapplyLB(cl, sim.counts, run_QuasiSeq)
  stopCluster(cl)
  
  results <-list(edgeR.exact  = res.edgeR.exact, 
                 edgeR.GLM    = res.edgeR.glm, 
                 edgeR.robust = res.edgeR.robust,
                 edgeR.QL     = res.edgeR.QL,
                 DESeq        = res.DESeq, 
                 DESeq2       = res.DESeq2, 
                 limmaQN      = res.limmaQN, 
                 limmaVoom    = res.limmavoom, 
                 limmaVoom_QW = res.limmavoom_QW, 
                 limmaVst     = res.limmaVst,
                 PoissonSeq   = res.PoissonSeq,  
                 SAMSeq       = res.SAMSeq,
                 QuasiSeq     = res.QuasiSeq)
  
  saveRDS(results, file=paste0("DE_result", 100*p.diff, "PDE.RData"), ascii =TRUE)
  
  
}

#-------------------------------------------------------------------------------------------------
rm(list=ls())

#Calculating performance metrics
#load global functions and objects
source("global_functions_and_objects.R")

PDE <- c(0, 0.05, 0.1, 0.15, 0.2, 0.25, 0.3)  #Proportion of true DE genes in simulated counts

perf.metrics.list <- list()
fdr.thrld= seq(0, 0.2, 0.005)[-1] #c(0.01, 0.025, 0.05, 0.1, 0.2)
for(i in 1:length(PDE)){
  print(paste("----------", i))
  DE.result <- readRDS(paste0(dir.Zhang, "/DE_result", 100*PDE[i], "PDE.RData"))
  perf.metrics.sub.list <- list()
  for(j in 1:length(fdr.thrld)){
    print(j)
    thrld <- fdr.thrld[j]
    perf.metrics <- lapply(DE.result, function(x){
      t(sapply(x, function(y){
        res <- y$result
        sumr.mRNA <- calc.perf.metrics(res$q[res$biotype=="mRNA"], res$de.genes[res$biotype=="mRNA"], thrld = thrld)
        FNR.mRNA <- sumr.mRNA$FNR
        TPR.mRNA <- sumr.mRNA$TPR
        TNR.mRNA <- sumr.mRNA$TNR
        FPR.mRNA <- sumr.mRNA$FPR
        FDR.mRNA <- sumr.mRNA$FDR
        
        sumr.lncRNA <- calc.perf.metrics(res$q[res$biotype=="lncRNA"], res$de.genes[res$biotype=="lncRNA"], thrld = thrld)
        FNR.lncRNA <- sumr.lncRNA$FNR
        TPR.lncRNA <- sumr.lncRNA$TPR
        TNR.lncRNA <- sumr.lncRNA$TNR
        FPR.lncRNA <- sumr.lncRNA$FPR
        FDR.lncRNA <- sumr.lncRNA$FDR
        
        rep.size <- y$inputs$setting$k.ind
        prop.DE  <- y$inputs$setting$p.diff
        biotype.composition <- unlist(y$inputs$gene.biotype.composition)
        c(FNR.mRNA=FNR.mRNA, TPR.mRNA=TPR.mRNA, TNR.mRNA=TNR.mRNA,FPR.mRNA=FPR.mRNA, 
          FDR.mRNA=FDR.mRNA,
          FNR.lncRNA=FNR.lncRNA, TPR.lncRNA=TPR.lncRNA, TNR.lncRNA=TNR.lncRNA,
          FPR.lncRNA=FPR.lncRNA, FDR.lncRNA=FDR.lncRNA,
          rep.size=rep.size, prop.DE=prop.DE, biotype.composition)
      }))
    })
    perf.metrics2            <- as.data.frame(do.call("rbind", perf.metrics))
    perf.metrics2$DE.tool    <- rep(names(perf.metrics), each=100*10)
    perf.metrics2$alpha      <- thrld
    perf.metrics.sub.list[j] <- list(perf.metrics2)
  }
  perf.metrics.sub.list <- do.call("rbind", perf.metrics.sub.list)
  rm("DE.result")
  perf.metrics.list[i] <- list(perf.metrics.sub.list)
}
library(data.table)
perf.metrics.list <- rbindlist(perf.metrics.list, fill = TRUE)
saveRDS(perf.metrics.list, "results.All.Zhang.RData")


#--------------------------------------------------------------------------------------------------
rm(list=ls())

#Summarizing raw simulation results and creating plots

#load global functions and objects
source("global_functions_and_objects.R")


#Load raw simulation result summary and calculating mean and error interval
##Zhang
simult.raw.summary.Zhang <- readRDS(paste0(dir.Zhang, "results.All.Zhang.RData"))
simult.summary.Zhang <- as.data.frame(do.call(rbind, by(simult.raw.summary.Zhang[, c(1:10, 11, 12, 15, 16)],  simult.raw.summary.Zhang[, c(11, 12, 15, 16)], calc.summary)))
saveRDS(simult.summary.Zhang, paste0(dir.Zhang, "simult.summary.Zhang.RData"))
simult.summary.Zhang <- readRDS(paste0(dir.Zhang, "simult.summary.Zhang.RData"))
head(simult.summary.Zhang)



#-------------
#Plot for the main report 
sel.summary.1 <- simult.summary.Zhang[simult.summary.Zhang$rep.size %in% c(10, 40) &
                                      simult.summary.Zhang$prop.DE %in% c(0.05, 0.3) &
                                      simult.summary.Zhang$alpha ==0.05 & 
                                      simult.summary.Zhang$metrics %in% c("FDR", "TPR"), ]
sel.summary.1$metrics = factor(sel.summary.1$metrics, levels = c("FDR", "TPR"))
sel.summary.1$biotype = factor(sel.summary.1$biotype, levels = c("mRNA", "lncRNA"))
sel.summary.1$vline <- ifelse(sel.summary.1$metrics== "FDR", 0.05, NA)
sel.summary.1[sel.summary.1$biotype == "lncRNA", c("ll", "mean", "ul", "vline")] <-
  -1*sel.summary.1[sel.summary.1$biotype == "lncRNA", c("ll", "mean", "ul", "vline")]
sel.summary.1$DE.tool <- factor(sel.summary.1$DE.tool, levels(sel.summary.1$DE.tool)[rev(c(11,8,7,10,5,12,13,9,1,2,6,3,4))])


p <- ggplot(data=sel.summary.1, 
            aes(y=mean, x=DE.tool, group=biotype, fill=biotype))+
  geom_bar(position="stack", stat="identity", colour = "black", size = 0.1, width = 0.7) +
  coord_flip() + 
  facet_grid(rep.size~ prop.DE+metrics) +
  geom_errorbar(aes(ymin=ll, ymax=ul), width=0.4)+
  scale_fill_manual("", values = alpha(c("deepskyblue3", "orange"), 0.4)) + 
  scale_y_continuous(breaks=c(-0.5, 0, 0.5), labels=c( 0.5, 0, 0.5),  limits=c(-0.85, 0.7)) +
  theme(axis.text.x=element_text(size = 9, colour = "black"), 
        axis.text.y=element_text(size = 9, colour = "black"),
        panel.background = element_rect(fill = NA),
        panel.grid.major = element_line(colour = "grey80"),
        strip.background = element_rect(colour = "black", fill = "white"),
        panel.grid.major.y = element_blank(),
        legend.position="top")+
  geom_hline(aes(yintercept = vline), col="gray25", lty=2)+
  labs(y=NULL, x=NULL) 

png(file=paste0(dir.Zhang, "FDR_TPR.sel2.png"), width=7.25,height=5.25, units = "in", res=700)
p
dev.off()

#-----------------------------------------------------------
sel.summary.2 <- simult.summary.NGP[simult.summary.NGP$rep.size %in% c(3, 5) &
                                      simult.summary.NGP$prop.DE %in% c(0.05, 0.3) &
                                      simult.summary.NGP$alpha ==0.05 &
                                      simult.summary.NGP$metrics %in% c("FDR", "TPR"), ]
sel.summary.2$metrics = factor(sel.summary.2$metrics, levels = c("FDR", "TPR"))
sel.summary.2$biotype = factor(sel.summary.2$biotype, levels = c("mRNA", "lncRNA"))
sel.summary.2$DE.tool = as.factor(sel.summary.2$DE.tool)
sel.summary.2$vline <- ifelse(sel.summary.2$metrics== "FDR", 0.05, NA)
sel.summary.2[sel.summary.2$biotype == "lncRNA", c("ll", "mean", "ul", "vline")] <-
  -1*sel.summary.2[sel.summary.2$biotype == "lncRNA", c("ll", "mean", "ul", "vline")]
sel.summary.2$DE.tool <- factor(sel.summary.2$DE.tool, 
                                levels=sel.summary.2$DE.tool[order(sel.summary.2$rep.size, sel.summary.2$prop.DE,
                                                                   sel.summary.2$biotype, sel.summary.2$metrics, sel.summary.2$mean)][13:1])


p <- ggplot(data=sel.summary.2, 
            aes(y=mean, x=DE.tool, group=biotype, fill=biotype))+
  geom_bar(position="stack", stat="identity", colour = "black", size = 0.1, width = 0.7) +
  coord_flip() + 
  facet_grid(rep.size~ prop.DE+metrics) +
  geom_errorbar(aes(ymin=ll, ymax=ul), width=0.4)+
  scale_fill_manual("", values = alpha(c("deepskyblue3", "orange"), 0.4)) + 
  scale_y_continuous(breaks=c(-0.5, 0, 0.5), labels=c( 0.5, 0, 0.5),  limits=c(-0.85, 0.85)) +
  theme(axis.text.x=element_text(size = 9, colour = "black"), 
        axis.text.y=element_text(size = 9, colour = "black"),
        panel.background = element_rect(fill = NA),
        panel.grid.major = element_line(colour = "grey80"),
        strip.background = element_rect(colour = "black", fill = "white"),
        panel.grid.major.y = element_blank(),
        legend.position="top")+
  geom_hline(aes(yintercept = vline), col="gray25", lty=2)+
  labs(y=NULL, x=NULL) 

png(file=paste0(dir.NGP, "FDR_TPR.sel2.png"), width=7.25,height=5.25, units = "in", res=700)
p
dev.off()

#Plots added in the additional files are also created in a similar fashion
