#Required libraries
library(reshape2)
library(lattice)
library(latticeExtra)
library(gridExtra)
library(tidyr)
library(ggplot2)

library(edgeR) 
library(SimSeq)
library(fdrtool)
library(parallel)

#Working director
dir <- getwd()

#Simulations from all source datasets
dir.Zhang <- paste0(dir, "/Zhang/")
dir.NGP   <- paste0(dir, "/NGP Nutlin/")
dir.GTEx   <- paste0(dir, "/GTEx/")


methods.names <- c("edgeR exact", "edgeR GLM", "edgeR robust", "edgeR QL", "DESeq", "DESeq2", "limmaQN",
                   "limmaVoom", "limmaVoom+QW", "limmaVst", "PoissonSeq", "SAMSeq", "QuasiSeq")
cols <-c("slateblue4", "palegreen1", "palegreen3", "palegreen4", 
         "skyblue2","royalblue4",
         "goldenrod1", "salmon1", "salmon4", "lightpink3", 
         "purple1", 
         "gray41", 
         "mediumvioletred")

convert.name <- function(x){
  if(x=="edgeR.exact") {"edgeR exact"}
  else if(x=="edgeR.GLM") {"edgeR GLM"}
  else if(x=="edgeR.robust") {"edgeR robust"}
  else if(x=="edgeR.QL") {"edgeR QL"}
  else if(x=="limmaVoom_QW") {"limmaVoom+QW"}
  else if(x=="limmaVoom") {"limmaVoom"}
  else if(x=="DESeq") {"DESeq"}
  else if(x=="DESeq2") {"DESeq2"}
  else if(x=="QuasiSeq") {"QuasiSeq"}
  else if(x=="limmaVst") {"limmaVst"}
  else if(x=="limmaQN") {"limmaQN"}
  else if(x=="PoissonSeq") {"PoissonSeq"}
  else if(x=="SAMSeq") {"SAMSeq"}
}

calc.summary <- function(x, convert.names=TRUE){
  require(reshape2)
  smr <- as.data.frame(apply(x[, 1:10], 2, function(y){
    if(all(is.na(y))){
      return(c(mean=NA, ll=NA, ul=NA))
    }
    else{
      mean    = mean(y, na.rm = TRUE)
      n       = length(y)
      std.err = sd(y, na.rm = TRUE)/sqrt(n)
      ll      = max(mean-1.96*std.err, 0) 
      ul      = min(mean+1.96*std.err, 1)
      return(c(mean=mean, ll=ll, ul=ul))
    }
  }))
  
  smr$rep.size = as.numeric(unique(x[, 11]))
  smr$prop.DE  = as.numeric(unique(x[, 12]))
  if(convert.names) {smr$DE.tool  = as.character(convert.name(unique(x[, 13])))}
  else {smr$DE.tool  = as.factor(unique(x[, 13]))}
  smr$alpha    = as.numeric(unique(x[, 14]))
  smr$stat     = rownames(smr) ; rownames(smr) = NULL
  
  smr <- melt(smr, id.vars = c("rep.size", "prop.DE", "DE.tool", "alpha", "stat"))
  smr <- dcast(smr, rep.size+prop.DE+DE.tool+alpha+variable ~stat)
  smr$metrics = sapply(1:nrow(smr), function(i) unlist(strsplit(as.character(smr$variable[i]), "[.]"))[1])
  smr$biotype = sapply(1:nrow(smr), function(i) unlist(strsplit(as.character(smr$variable[i]), "[.]"))[2])
  smr$variable = NULL
  
  smr$metrics  <- as.factor(smr$metrics)
  smr$DE.tool  <- as.factor(smr$DE.tool)
  smr$biotype  <- as.factor(smr$biotype)
  
  smr
}


calc.perf.metrics <- function(q, null,  thrld=0.05){
  #This function calculates the four performance comparison metrics: TPR, TNR, FPR, FNR, and FDR
  #TPR 
  if(sum(null==1) > 0){
    tpr <- sum(q<thrld & null == 1)/sum(null == 1) 
  }
  else { tpr <- NA }
  
  #TNR
  if(sum(null==0) > 0){
    tnr <- sum(q >= thrld & null == 0)/sum(null == 0)
  }
  else { tnr <- NA }
  
  #FPR 
  if(sum(null==0) > 0){
    fpr <- sum(q<thrld & null == 0)/sum(null == 0)
  }
  else { fpr <- NA }
  
  #FNR
  if(sum(null == 1) >0){
    fnr <- sum(q>=thrld & null == 1)/sum(null == 1)
  }
  else {  fnr <- NA }
  
  #FDR 
  if(sum(q<thrld) > 0){
    fdr <- sum(q<thrld & null == 0)/sum(q<thrld)
  }
  else { fdr <- 0 } #by definition of FDR (BH95)
  
  return(list(TPR=tpr, TNR=tnr, FPR=fpr, FNR=fnr, FDR=fdr))
}


generate.count <- function(par.list,  gene.biotype.source){
  require(SimSeq)
  
  #Inputs validation
  if(is.null(gene.biotype.source)) {stop("Genes biotype is not provided.")}
  if(is.null(rownames(par.list$counts.source))) {stop("Genes ID/name is not provided.")}
  if(length(rownames(par.list$counts.source)) != length(unique(rownames(par.list$counts.source))))
  {stop("Genes ID/name are not unique.")}
  
  #Preparing inputs
  counts.s   <- par.list$counts.source
  group.s    <- par.list$group.source
  k.ind      <- par.list$k.ind 
  n.genes    <- par.list$n.genes
  n.initial  <- par.list$n.initial
  n.diff     <- round(par.list$p.diff*n.initial) 
  nf         <- par.list$nf
  wghts      <- par.list$wghts
  
  mRNA  <- gene.biotype.source$mRNA
  lncRNA <- gene.biotype.source$lncRNA
  
  #Generating counts
  counts.simseq.list <- SimData(counts = counts.s, treatment = group.s, replic = NULL, 
                                sort.method = "unpaired", k.ind = k.ind, n.genes = n.initial,
                                n.diff = n.diff, norm.factors = nf, weights = wghts, switch.trt = F)
  
  counts.simseq <- counts.simseq.list$counts    # Simulated Count matrix from SimSeq
  genes.samp <- counts.simseq.list$genes.subset # Genes sampled from source matrix
  de.genes <- counts.simseq.list$DE.genes       # DE genes sampled from source matrix
  ee.genes <- genes.samp[ ! (genes.samp %in% de.genes) ] # EE genes sampled from source matrix
  samp.col <- counts.simseq.list$col # Columns sampled in SimSeq algorithm
  de.genes.sim <- counts.simseq.list$genes.subset %in% de.genes # logical vector giving which genes are DE in simulted matrix
  de.genes.sim <- data.frame(Genes = rownames(counts.simseq), de.genes = ifelse(de.genes.sim,1,0))
  trt <- counts.simseq.list$treatment
  
  #filtering genes with no expression (at least 1 expression each group)
  keep <- names(which(rowSums(counts.simseq[, c(1:k.ind)]) > 0 & 
                        rowSums(counts.simseq[, c((k.ind+1):(2*k.ind))])>0))
  
  keep.mRNA   <- keep[(keep %in% mRNA)]
  keep.lncRNA <- keep[(keep %in% lncRNA)] 
  
  if(length(keep) > n.genes){
    keep.mRNA <- sample(keep.mRNA, n.genes - length(keep.lncRNA), 
                        prob = as.vector(rowSums(counts.simseq[keep.mRNA,])/sum(colSums(counts.simseq[keep.mRNA, ])))) 
    counts.simseq <- counts.simseq[c(keep.mRNA, keep.lncRNA),]
  }
  else{
    counts.simseq <- counts.simseq[keep,]
  }
  
  de.genes.sim <- de.genes.sim[de.genes.sim$Genes %in%c(keep.mRNA, keep.lncRNA),]
  de.genes.sim$biotype <- ifelse(de.genes.sim$Genes %in% lncRNA, "lncRNA", "mRNA") 
  
  #Summarizing composition of gene biotype and DE genes
  if(par.list$p.diff != 0){
    gene.biotype.composition = list(prop.mRNA   = prop.table(table(de.genes.sim$biotype))[2], 
                                    prop.lncRNA = prop.table(table(de.genes.sim$biotype))[1],
                                    prop.DE_in_mRNA   = prop.table(table(de.genes.sim$biotype, 
                                                                         de.genes.sim$de.genes), 1)[2, 2],
                                    prop.DE_in_lncRNA   = prop.table(table(de.genes.sim$biotype, 
                                                                           de.genes.sim$de.genes), 1)[1, 2],
                                    prop.mRNA_in_DE   = prop.table(table(de.genes.sim$biotype, 
                                                                         de.genes.sim$de.genes), 2)[2, 2],
                                    prop.lncRNA_in_DE   = prop.table(table(de.genes.sim$biotype, 
                                                                           de.genes.sim$de.genes), 2)[1, 2])
  }
  else{
    gene.biotype.composition = list(prop.mRNA   = prop.table(table(de.genes.sim$biotype))[2], 
                                    prop.lncRNA = prop.table(table(de.genes.sim$biotype))[1])
  }
  
  #preparing a list of outputs  
  out.object <- list(counts=counts.simseq, 
                     group=trt, 
                     de.gene=de.genes.sim, 
                     setting=list(k.ind = k.ind, n.genes=n.genes, p.diff=p.diff),
                     gene.biotype.composition = gene.biotype.composition)
  
  return(out.object)
}
