
#load global functions and objects
source("global_functions_and_objects.R")

#-------------
#Load raw simulation result summary and calculating mean and error interval
##Zhang
# simult.raw.summary.Zhang <- readRDS(paste0(dir.Zhang, "results.All.Zhang.RData"))
# simult.summary.Zhang <- as.data.frame(do.call(rbind, by(simult.raw.summary.Zhang[, c(1:10, 11, 12, 15, 16)],  simult.raw.summary.Zhang[, c(11, 12, 15, 16)], calc.summary)))
# saveRDS(simult.summary.Zhang, paste0(dir.Zhang, "simult.summary.Zhang.RData"))
simult.summary.Zhang <- readRDS(paste0(dir.Zhang, "simult.summary.Zhang.RData"))
head(simult.summary.Zhang)


##NGP Nutlin
#simult.raw.summary.NGP <- readRDS(paste0(dir.NGP, "results.All.NGP.RData"))
#simult.summary.NGP     <- as.data.frame(do.call(rbind, by(simult.raw.summary.NGP[, c(1:10, 11, 12, 15, 16)],  simult.raw.summary.NGP[, c(11, 12, 15, 16)], calc.summary)))
#saveRDS(simult.summary.NGP, paste0(dir.NGP, "simult.summary.NGP.RData"))
simult.summary.NGP <- readRDS(paste0(dir.NGP, "simult.summary.NGP.RData"))
head(simult.summary.NGP)

#-------------
#Plot for the main report 
sel.summary.1 <- simult.summary.Zhang[simult.summary.Zhang$rep.size %in% c(10, 40) &
                                      simult.summary.Zhang$prop.DE %in% c(0.05, 0.3) &
                                      simult.summary.Zhang$alpha ==0.05 & 
                                      simult.summary.Zhang$metrics %in% c("FDR", "TPR"), ]
sel.summary.1$metrics = factor(sel.summary.1$metrics, levels = c("FDR", "TPR"))
sel.summary.1$biotype = factor(sel.summary.1$biotype, levels = c("mRNA", "lncRNA"))
sel.summary.1$vline <- ifelse(sel.summary.1$metrics== "FDR", 0.05, NA)
sel.summary.1[sel.summary.1$biotype == "lncRNA", c("ll", "mean", "ul", "vline")] <-
  -1*sel.summary.1[sel.summary.1$biotype == "lncRNA", c("ll", "mean", "ul", "vline")]
sel.summary.1$DE.tool <- factor(sel.summary.1$DE.tool, levels(sel.summary.1$DE.tool)[rev(c(11,8,7,10,5,12,13,9,1,2,6,3,4))])


p <- ggplot(data=sel.summary.1, 
            aes(y=mean, x=DE.tool, group=biotype, fill=biotype))+
  geom_bar(position="stack", stat="identity", colour = "black", size = 0.1, width = 0.7) +
  coord_flip() + 
  facet_grid(rep.size~ prop.DE+metrics) +
  geom_errorbar(aes(ymin=ll, ymax=ul), width=0.4)+
  scale_fill_manual("", values = alpha(c("deepskyblue3", "orange"), 0.4)) + 
  scale_y_continuous(breaks=c(-0.5, 0, 0.5), labels=c( 0.5, 0, 0.5),  limits=c(-0.85, 0.7)) +
  theme(axis.text.x=element_text(size = 9, colour = "black"), 
        axis.text.y=element_text(size = 9, colour = "black"),
        panel.background = element_rect(fill = NA),
        panel.grid.major = element_line(colour = "grey80"),
        strip.background = element_rect(colour = "black", fill = "white"),
        panel.grid.major.y = element_blank(),
        legend.position="top")+
  geom_hline(aes(yintercept = vline), col="gray25", lty=2)+
  labs(y=NULL, x=NULL) 

png(file=paste0(dir.Zhang, "FDR_TPR.sel2.png"), width=7.25,height=5.25, units = "in", res=700)
p
dev.off()

#-----------------------------------------------------------
sel.summary.2 <- simult.summary.NGP[simult.summary.NGP$rep.size %in% c(3, 5) &
                                      simult.summary.NGP$prop.DE %in% c(0.05, 0.3) &
                                      simult.summary.NGP$alpha ==0.05 &
                                      simult.summary.NGP$metrics %in% c("FDR", "TPR"), ]
sel.summary.2$metrics = factor(sel.summary.2$metrics, levels = c("FDR", "TPR"))
sel.summary.2$biotype = factor(sel.summary.2$biotype, levels = c("mRNA", "lncRNA"))
sel.summary.2$DE.tool = as.factor(sel.summary.2$DE.tool)
sel.summary.2$vline <- ifelse(sel.summary.2$metrics== "FDR", 0.05, NA)
sel.summary.2[sel.summary.2$biotype == "lncRNA", c("ll", "mean", "ul", "vline")] <-
  -1*sel.summary.2[sel.summary.2$biotype == "lncRNA", c("ll", "mean", "ul", "vline")]
sel.summary.2$DE.tool <- factor(sel.summary.2$DE.tool, 
                                levels=sel.summary.2$DE.tool[order(sel.summary.2$rep.size, sel.summary.2$prop.DE,
                                                                   sel.summary.2$biotype, sel.summary.2$metrics, sel.summary.2$mean)][13:1])


p <- ggplot(data=sel.summary.2, 
            aes(y=mean, x=DE.tool, group=biotype, fill=biotype))+
  geom_bar(position="stack", stat="identity", colour = "black", size = 0.1, width = 0.7) +
  coord_flip() + 
  facet_grid(rep.size~ prop.DE+metrics) +
  geom_errorbar(aes(ymin=ll, ymax=ul), width=0.4)+
  scale_fill_manual("", values = alpha(c("deepskyblue3", "orange"), 0.4)) + 
  scale_y_continuous(breaks=c(-0.5, 0, 0.5), labels=c( 0.5, 0, 0.5),  limits=c(-0.85, 0.85)) +
  theme(axis.text.x=element_text(size = 9, colour = "black"), 
        axis.text.y=element_text(size = 9, colour = "black"),
        panel.background = element_rect(fill = NA),
        panel.grid.major = element_line(colour = "grey80"),
        strip.background = element_rect(colour = "black", fill = "white"),
        panel.grid.major.y = element_blank(),
        legend.position="top")+
  geom_hline(aes(yintercept = vline), col="gray25", lty=2)+
  labs(y=NULL, x=NULL) 

png(file=paste0(dir.NGP, "FDR_TPR.sel2.png"), width=7.25,height=5.25, units = "in", res=700)
p
dev.off()


#Plots to be in the additional file
#-------------------------------

sel.summary.Zhang <- simult.summary.Zhang[simult.summary.Zhang$rep.size %in% c(3, 5) &
                                            simult.summary.Zhang$prop.DE %in% c(0.2) &
                                            simult.summary.Zhang$alpha ==0.05 &
                                            simult.summary.Zhang$metrics %in% c("FDR", "TPR"), ]
sel.summary.Zhang$source.data <- "Zhang"
sel.summary.NGP <- simult.summary.NGP[simult.summary.NGP$rep.size %in% c(3, 5) &
                                        simult.summary.NGP$prop.DE %in% c(0.2) &
                                        simult.summary.NGP$alpha ==0.05 &
                                        simult.summary.NGP$metrics %in% c("FDR", "TPR"), ]
sel.summary.NGP$source.data <- "NGP Nutlin"

sel.summary.2 <- rbind(sel.summary.Zhang, sel.summary.NGP)

sel.summary.2$metrics = factor(sel.summary.2$metrics, levels = c("FDR", "TPR"))
sel.summary.2$biotype = factor(sel.summary.2$biotype, levels = c("mRNA", "lncRNA"))
sel.summary.2$source.data = factor(sel.summary.2$source.data, levels = c("Zhang", "NGP Nutlin"))

sel.summary.2$vline <- ifelse(sel.summary.2$metrics== "FDR", 0.05, NA)
sel.summary.2[sel.summary.2$biotype == "lncRNA", c("ll", "mean", "ul", "vline")] <-
  -1*sel.summary.2[sel.summary.2$biotype == "lncRNA", c("ll", "mean", "ul", "vline")]
sel.summary.2$DE.tool <- factor(sel.summary.2$DE.tool, levels(sel.summary.2$DE.tool)[rev(c(11,8,7,10,5,12,13,9,1,2,6,3,4))])



p <- ggplot(data=sel.summary.2, 
            aes(y=mean, x=DE.tool, group=biotype, fill=biotype))+
  geom_bar(position="stack", stat="identity", colour = "black", size = 0.01, width = 0.7) +
  coord_flip() + 
  facet_grid(rep.size~ source.data+metrics) +
  geom_errorbar(aes(ymin=ll, ymax=ul), width=0.4)+
  scale_fill_manual("", values = alpha(c("deepskyblue3", "orange"), 0.3)) + 
  scale_y_continuous(breaks=c(-0.5, 0, 0.5), labels=c( 0.5, 0, 0.5),  limits=c(-0.85, 0.85)) +
  theme(axis.text.x=element_text(size = 8, colour = "gray15"), 
        axis.text.y=element_text(size = 8, colour = "gray15"),
        panel.background = element_rect(fill = NA),
        panel.grid.major = element_line(colour = "grey80"),
        strip.background = element_rect(colour = "black", fill = "white"),
        panel.grid.major.y = element_blank(),
        legend.position="top")+
  geom_hline(aes(yintercept = vline), col="gray25", lty=2)+
  labs(y=NULL, x=NULL) 

png(file=paste0(dir.NGP, "FDR_TPR.sel2.png"), width=7.25,height=5.25, units = "in", res=700)
p
dev.off()


#Plots to be in the additional file
#-------------------------------
##NGP Nutlin
sel.summary.NGP.a <- simult.summary.NGP[simult.summary.NGP$rep.size %in% c(2,3, 4, 5) &
                                          simult.summary.NGP$prop.DE %in% c(0.05, 0.2, 0.3) &
                                          simult.summary.NGP$alpha ==0.05 &
                                          simult.summary.NGP$metrics %in% c("FDR", "TPR"), ]
sel.summary.NGP.a$metrics = factor(sel.summary.NGP.a$metrics, levels = c("FDR", "TPR"))
sel.summary.NGP.a$biotype = factor(sel.summary.NGP.a$biotype, levels = c("mRNA", "lncRNA"))
sel.summary.NGP.a$DE.tool = as.factor(sel.summary.NGP.a$DE.tool)
sel.summary.NGP.a$vline <- ifelse(sel.summary.NGP.a$metrics== "FDR", 0.05, NA)
sel.summary.NGP.a[sel.summary.NGP.a$biotype == "lncRNA", c("ll", "mean", "ul", "vline")] <-
  -1*sel.summary.NGP.a[sel.summary.NGP.a$biotype == "lncRNA", c("ll", "mean", "ul", "vline")]
sel.summary.NGP.a$DE.tool <- factor(sel.summary.NGP.a$DE.tool, 
                                    levels=sel.summary.NGP.a$DE.tool[order(sel.summary.NGP.a$rep.size, sel.summary.NGP.a$prop.DE,
                                                                           sel.summary.NGP.a$biotype, sel.summary.NGP.a$metrics, sel.summary.NGP.a$mean)][13:1])


p <- ggplot(data=sel.summary.NGP.a, 
            aes(y=mean, x=DE.tool, group=biotype, fill=biotype))+
  geom_bar(position="stack", stat="identity", colour = "black", size = 0.1, width = 0.7) +
  coord_flip() + 
  facet_grid(rep.size~ prop.DE+metrics) +
  geom_errorbar(aes(ymin=ll, ymax=ul), width=0.4)+
  scale_fill_manual("", values = alpha(c("deepskyblue3", "orange"), 0.4)) + 
  scale_y_continuous(breaks=c(-0.5, 0, 0.5), labels=c( 0.5, 0, 0.5),  limits=c(-0.85, 0.85)) +
  theme(axis.text.x=element_text(size = 9, colour = "black"), 
        axis.text.y=element_text(size = 9, colour = "black"),
        panel.background = element_rect(fill = NA),
        panel.grid.major = element_line(colour = "grey80"),
        strip.background = element_rect(colour = "black", fill = "white"),
        panel.grid.major.y = element_blank(),
        legend.position="top")+
  geom_hline(aes(yintercept = vline), col="gray25", lty=2)+
  labs(y=NULL, x=NULL) 

png(file=paste0(dir.NGP, "FDR_TPR_NGP_all.png"), width=7.25,height=10.25, units = "in", res=700)
p
dev.off()










