
run_edgeR_exact<-function(object) {
  #A function that runs edgeR exact test
  # @param object contains non normalized count matrices, grouping variable and and indicator variable of true DE genes
  
  require(edgeR)
  count <- object$counts                    # count matrixs
  cond  <- object$group                     # Grouping variable
  de.gene <- as.data.frame(object$de.gene)  # a data frame for DE genes abd biotype indicator 
  
  y <- DGEList(counts=count, group=cond)
  y <- calcNormFactors(y)
  y <- estimateCommonDisp(y)
  y <- estimateTagwiseDisp(y)
  
  et <- exactTest(y) 
  et <- et$table
  et$q <- p.adjust(et$PValue, method="BH")
  et$q[is.na(et$q)] <- 1
  
  et$Genes <- rownames(et)
  et <- merge(et, de.gene, by="Genes")
  colnames(et) <- c("Genes", "LFC", "logCPM", "p", "q", "de.genes", "biotype")
  return(list(result=et,  inputs = object))
}

run_edgeR_glm<-function(object) {
  #A function that runs edgeR GLM
  # @param object contains non normalized count matrices, grouping variable and and indicator variable of true DE genes
  
  require(edgeR)
  count <- object$counts                    # count matrixs
  cond  <- object$group                     # Grouping variable
  de.gene <- as.data.frame(object$de.gene)  # a data frame for DE genes abd biotype indicator
  
  
  y <- DGEList(counts=count, group=cond)
  y <- calcNormFactors(y)
  design <- model.matrix(~cond)
  y <- estimateGLMTrendedDisp(y, design)
  y <- estimateGLMTagwiseDisp(y, design)
  dFit <- glmFit(y, design)                         
  dLrt <- glmLRT(dFit, coef=2) 
  dLrt <- dLrt$table
  dLrt$q <- p.adjust(dLrt$PValue,method="BH")
  dLrt$q[is.na(dLrt$q)] <- 1
  
  dLrt$Genes <- rownames(dLrt)
  dLrt <- merge(dLrt, de.gene, by="Genes")
  dLrt <- dLrt[, -4]
  colnames(dLrt) <- c("Genes", "LFC", "logCPM", "p", "q", "de.genes", "biotype")
  
  return(list(result=dLrt, inputs = object))
} 

run_edgeR_robust<-function(object) {
  #A function that runs robust edgeR GLM
  # @param object contains non normalized count matrices, grouping variable and and indicator variable of true DE genes
  
  require(edgeR)
  count <- object$counts                    # count matrixs
  cond  <- object$group                     # Grouping variable
  de.gene <- as.data.frame(object$de.gene)  # a data frame for DE genes abd biotype indicator
  
  y <- DGEList(counts=count, group=cond)
  y <- calcNormFactors(y)
  design <- model.matrix(~cond)
  y <- estimateGLMRobustDisp(y, design)   # as in pipeline.pdf document
  
  ## DE test
  dFit <- glmFit(y, design)                         
  dLrt <- glmLRT(dFit,coef=2)                       # Test
  
  dLrt <- dLrt$table
  dLrt$q <- p.adjust(dLrt$PValue, method="BH")
  dLrt$q[is.na(dLrt$q)] <- 1
  
  dLrt$Genes <- rownames(dLrt)
  dLrt <- merge(dLrt, de.gene, by="Genes")
  dLrt <- dLrt[, -4]
  colnames(dLrt) <- c("Genes", "LFC", "logCPM", "p", "q", "de.genes", "biotype")
  
  return(list(result=dLrt, inputs = object))
}

run_edgeR_ql<-function(object) {
  #A function that runs edgeR quasi-likelihood test
  # @param object contains non normalized count matrices, grouping variable and and indicator variable of true DE genes
  
  require(edgeR)
  count <- object$counts                    # count matrixs
  cond  <- object$group                     # Grouping variable
  de.gene <- as.data.frame(object$de.gene)  # a data frame for DE genes abd biotype indicator
  
  y <- DGEList(counts=count, group=cond)
  y <- calcNormFactors(y)
  design <- model.matrix(~cond)
  y <- estimateDisp(y, design)
  
  fit <- glmQLFit(y, design, robust=TRUE)
  dFit <- glmQLFTest(fit)                         
  dLrt <- dFit$table
  dLrt$q <- p.adjust(dLrt$PValue,method="BH")
  dLrt$q[is.na(dLrt$q)] <- 1
  
  dLrt$Genes <- rownames(dLrt)
  dLrt <- merge(dLrt, de.gene, by="Genes")
  dLrt <- dLrt[, -4]
  colnames(dLrt) <- c("Genes", "LFC", "logCPM", "p", "q", "de.genes", "biotype")
  
  return(list(result=dLrt, inputs = object))
}

run_DESeq <- function(object){
  #A function that runs DESeq
  # @param object contains non normalized count matrices, grouping variable and and indicator variable of true DE genes
  
  require(DESeq)
  count <- object$counts                    # count matrixs
  cond  <- object$group                     # Grouping variable
  de.gene <- as.data.frame(object$de.gene)  # a data frame for DE genes abd biotype indicator
  
  cds <- newCountDataSet(count, cond) ## Initialize new DESeq object
  cds <- estimateSizeFactors(cds) ## estimate size factor
  cds_norm <- cds
  
  ## estimate dispersion parameters
  cds  <- try(estimateDispersions(cds, sharingMode="maximum",
                                  method= "pooled", fitType='local'), silent = T )#all are default )
  res <- nbinomTest(cds, levels(cond)[1], levels(cond)[2]) ## differential expression
  res <- res[, c(1, 2, 6, 7, 8)]
  colnames(res) <- c("Genes", "Mean", "LFC", "p", "q")
  res$q[is.na(res$q)] <- 1
  
  res <- merge(res, de.gene, by="Genes")
  return(list(result=res, inputs = object))
  
}

run_DESeq2<- function(object) {
  #A function that runs DESeq
  # @param object contains non normalized count matrices, grouping variable and and indicator variable of true DE genes
  
  require(DESeq2)
  count <- object$counts                    # count matrixs
  cond  <- object$group                     # Grouping variable
  de.gene <- as.data.frame(object$de.gene)  # a data frame for DE genes abd biotype indicator
  
  
  colData <- data.frame(cond)
  rownames(colData) <- colnames(count)
  d_deseq2 <- DESeqDataSetFromMatrix(countData=count, colData=colData, design=~cond)
  
  # Differential expression analysis
  d_deseq2 <- DESeq(d_deseq2)
  res  <- results(d_deseq2, independentFiltering = F)
  res <- as.data.frame(res)
  res$Genes <- rownames(res)
  res <- res[,c(1,2,5,6,7)]
  colnames(res) <- c("Mean", "LFC", "p", "q", "Genes")
  res$q[is.na(res$q)] <- 1
  res <- merge(res, de.gene, by="Genes")
  
  return(list(result=res, inputs = object))
} 

run_limmaQN <- function(object){
  #A function that runs limmaQN
  # @param object contains non normalized count matrices, grouping variable and and indicator variable of true DE genes
  
  require(limma)
  count <- object$counts                    # count matrixs
  cond  <- object$group                     # Grouping variable
  de.gene <- as.data.frame(object$de.gene)  # a data frame for DE genes abd biotype indicator
  
  # Create model matrix and set up dge object
  design <- model.matrix(~cond)
  
  # Quantile normalization  
  counts.log.dat=log2(counts+1)  # log2 transformation of counts, a constant 1 is added to avoid taking log of 0
  counts.log.norm.dat=normalizeBetweenArrays(counts.log.dat,method='quantile')  # QN normalization
  dat=counts.log.norm.dat
  
  # Test for differential expression
  fit <- lmFit(dat,design)
  fit <- eBayes(fit)
  res <- topTable(fit,coef=ncol(design),n=nrow(dat),sort.by="none") # Return top table
  
  res <- res[, c(1, 2,4, 5)]
  res$Genes <- rownames(res)
  colnames(res) <- c("LFC", "Mean", "p", "q", "Genes")
  res$q[is.na(res$q)] <- 1
  res <- merge(res, de.gene, by="Genes")
  
  return(list(result=res, inputs = object))
}

run_limmaVoom<- function(object){
  #A function that runs limmaVoom
  # @param object contains non normalized count matrices, grouping variable and and indicator variable of true DE genes
  
  require(limma)
  require(edgeR)
  count <- object$counts                    # count matrixs
  cond  <- object$group                     # Grouping variable
  de.gene <- as.data.frame(object$de.gene)  # a data frame for DE genes abd biotype indicator
  
  # Create model matrix and set up dge object
  design <- model.matrix(~cond)
  dgel <- DGEList(counts=count)
  
  # Calculate normalization factors - TMM
  dgel <- calcNormFactors(dgel)
  
  # Voom transformation - estimate dispersion
  v <- voom(dgel, design, plot=FALSE)
  
  # Test for differential expression
  fit <- lmFit(v,design)
  fit <- eBayes(fit)
  
  # Return top table
  de_table <- topTable(fit,coef=ncol(design),n=nrow(dgel),sort.by="none")
  
  res <- as.data.frame(de_table)
  res$Genes <- rownames(res)
  res <- res[,c(1,2,4,5,7)]
  colnames(res) <- c("LFC", "Mean", "p", "q", "Genes")
  res$q[is.na(res$q)] <- 1
  res <- merge(res, de.gene, by="Genes")
  
  return(list(result=res, inputs = object))
}

run_limmaVoom_QW <- function(object){
  #A function that runs limmaVoom + quality weight 
  # @param object contains non normalized count matrices, grouping variable and and indicator variable of true DE genes
  
  require(limma)
  require(edgeR)
  count <- object$counts                    # count matrixs
  cond  <- object$group                     # Grouping variable
  de.gene <- as.data.frame(object$de.gene)  # a data frame for DE genes abd biotype indicator
  
  # Create model matrix and set up dge object
  design <- model.matrix(~cond)
  dgel <- DGEList(counts=count)
  
  # Calculate normalization factors - TMM
  dgel <- calcNormFactors(dgel)
  
  # Voom transformation with sample quality weights - estimate dispersion
  v <-  voomWithQualityWeights(dgel,design,normalization="none",plot=FALSE)
  
  # Test for differential expression
  fit <- lmFit(v,design)
  fit <- eBayes(fit)
  
  # Return top table
  de_table <- topTable(fit,coef=ncol(design),n=nrow(dgel),sort.by="none")
  
  res <- as.data.frame(de_table)
  res$Genes <- rownames(res)
  res <- res[,c(1,2,4,5,7)]
  colnames(res) <- c("LFC", "Mean", "p", "q", "Genes")
  res$q[is.na(res$q)] <- 1
  res <- merge(res, de.gene, by="Genes")
  
  return(list(result=res, inputs = object))
}

run_limmaVst <- function(object){
  #A function that runs limma+variance stablizing transformation
  # @param object contains non normalized count matrices, grouping variable and and indicator variable of true DE genes
  
  require(limma)
  require(DESeq)
  count <- object$counts                    # count matrixs
  cond  <- object$group                     # Grouping variable
  de.gene <- as.data.frame(object$de.gene)  # a data frame for DE genes abd biotype indicator
  
  
  ## Initialize design matrix and new DESeq object
  design <- model.matrix(~cond)
  cds <- newCountDataSet(counts, cond)
  cds <- estimateSizeFactors(cds) ## Estimate size factors
  
  ## Estimate dispersion parameters
  cds <- estimateDispersions(cds, method='blind', fitType='local') # Options set as in Soneson research
  
  ## Apply variance stabilizing transformation
  # own function that adapts getVarianceStabilizedData function
  vst <- DESeq::getVarianceStabilizedData(cds)
  
  # Limma test for differential expression
  fit <- lmFit(vst,design)
  fit <- eBayes(fit)
  res <- topTable(fit,coef=ncol(design),n=nrow(vst),sort.by="none")
  
  res <- res[, c(1, 2,4, 5)]
  res$Genes <- rownames(res)
  colnames(res) <- c("LFC", "Mean", "p", "q", "Genes")
  res$q[is.na(res$q)] <- 1
  res <- merge(res, de.gene, by="Genes")
  
  return(list(result=res, inputs = object))
}


run_PoissonSeq <- function(object){
  #A function that runs PoissonSeq
  # @param object contains non normalized count matrices, grouping variable and and indicator variable of true DE genes
  
  require(PoissonSeq)
  count <- object$counts                    # count matrixs
  cond  <- object$group                     # Grouping variable
  de.gene <- as.data.frame(object$de.gene)  # a data frame for DE genes abd biotype indicator
  
  ## Reformat conditions vector for PoissonSeq analysis
  y <- ifelse(cond==0, 1, 2)
  y <- as.numeric(y)
  
  ## Create list object for PoissonSeq analysis
  dat <- list(n=count,
              y=y,
              type='twoclass',
              pair=FALSE,
              gname=rownames(count))
  
  ## Set parameters for Poisson Analysis
  para <- list(ct.sum=1, ct.mean=0.01)
  
  ## Call Poisson DE analysis
  res <- try(PS.Main(dat=dat, para=para), silent = TRUE)
  if(class(res) =="try-error"){
    temp2 <- data.frame(Genes=rownames(count), p=1, q=1, LFC=0)
    sum_df <- merge(temp2,  de.gene, by='Genes')
    return(list(result=sum_df, inputs = object))
  }
  else{
    # Data frame with other metrics (only includes genes that past the filter)
    temp2 <- data.frame(Genes=rownames(res), p=res$pval, q=res$fdr, LFC=res$log.fc)
    sum_df <- merge(temp2,  de.gene, by='Genes')
    temp2$q[is.na(temp2$q)] <- 1
    return(list(result=sum_df, inputs = object))
  }
}

run_SAMSeq <- function(object, reorder=F) {
  #A function that runs limma+variance stablizing transformation
  # @param object contains non normalized count matrices, grouping variable and and indicator variable of true DE genes
  
  require(samr)
  count <- object$counts                    # count matrixs
  cond  <- object$group                     # Grouping variable
  de.gene <- as.data.frame(object$de.gene)  # a data frame for DE genes abd biotype indicator
  
  ## Reformat conditions vector for PoissonSeq analysis
  labels <- ifelse(cond==0, 1, 2)
  
  capture.output(x <- SAMseq(counts, labels, geneid=rownames(counts), resp.type="Two class unpaired", 
                             fdr.output=1.0))
  ss <- rbind(x$siggenes.table$genes.up, x$siggenes.table$genes.lo)
  res <- data.frame(id=ss[, 2], foldchange=as.numeric(ss[, 4]), q=as.numeric(ss[, 5]))
  res <- cbind(res, threshold=-res$q)
  missed.id = setdiff(rownames(counts), ss[, "Gene Name"])	
  res <- rbind(res, data.frame(id=missed.id, foldchange=0, q=max(res$q), threshold = 1-max(res$q)))
  res$id <- as.character(res$id)
  if (reorder){
    res <- res[order(res$id), ]
    message("Reordering genes!!!")
  }
  
  colnames(res) <- c("Genes", "FC", "q", "threshold")
  res$q <- res$q / 100
  res$q[is.na(res$q)] <- 1
  res$p <- res$q
  res <- res[,c(1,5,3, 2)]
  res <- merge(res, de.gene, by="Genes")
  
  return(list(result=res, inputs = object))
}

run_QuasiSeq <- function(object){
  #A function that runs QuasiSeq
  # @param object contains non normalized count matrices, grouping variable and and indicator variable of true DE genes
  
  require(QuasiSeq)
  require(edgeR)
  count <- object$counts                    # count matrixs
  cond  <- object$group                     # Grouping variable
  de.gene <- as.data.frame(object$de.gene)  # a data frame for DE genes abd biotype indicator
  
  
  ##Estimating dispersion using edgeR package (trended dispersion estimate from edgeR GLM)
  y <- DGEList(counts=count, group=cond)
  y <- calcNormFactors(y)
  design <- model.matrix(~cond)
  est.nb.disp <- estimateGLMTrendedDisp(y, design)$trended.dispersion
  
  ### Create list of designs describing model under null and alternative hypotheses
  design.list <- vector("list",2)
  design.list[[1]] <- model.matrix(~as.factor(cond)) 
  design.list[[2]] <- rep(1,length(cond))
  log.offset <- log(apply(count,2,quantile,.75))
  
  ### Analyze using QL, QLShrink and QLSpline methods applied to quasi-Poisson model
  ### applied to quasi-negative binomial model
  fit <- QL.fit(count, design.list, log.offset=log.offset, nb.disp=est.nb.disp, Model="NegBin", 
                print.progress=FALSE, NBdisp="trend")
  results <- QL.results(fit, Dispersion="Deviance", Plot=FALSE)
  
  #Results only from QLSpline 
  result <- data.frame(Genes=rownames(count), LFC=fit$coefficients[,2], p=results$P.values$QLSpline,
                       q=results$Q.values$QLSpline)
  result <- merge(result, de.gene, by="Genes")
  colnames(result) <- c("Genes", "LFC", "p", "q", "de.genes", "biotype")
  result$q[is.na(result$q)] <-1
  
  return(list(result=result, inputs = object))
}

