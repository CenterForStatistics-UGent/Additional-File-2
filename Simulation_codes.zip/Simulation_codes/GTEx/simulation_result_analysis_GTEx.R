

#load global functions and objects
source("global_functions_and_objects.R")

#Load simulation results
DE.result.30PDE.GTEx <- readRDS(paste0(dir.GTEx, "DE_results_30PercDE.RData"))
DE.result.20PDE.GTEx <- readRDS(paste0(dir.GTEx, "DE_results_20PercDE.RData"))

#Choosing cut point based on the CPM of lncRNAs. approximately 99% of lncRNAs have mean cpm of less than 15
NGP.count <- readRDS(paste0(dir.NGP, "celine_neuroblastoma_data.RData"))
NGP.count.cpm.mean <- rowMeans(edgeR::cpm(NGP.count$counts))
quantile(NGP.count.cpm.mean[NGP.count$lncRNA], probs = c(0.90, 0.95, 0.975, 0.98, 0.985, 0.99, 1))


DE.result.30PDE.GTEx <- lapply(DE.result.30PDE.GTEx, function(y){
  y <- lapply(y, function(x){
    calc.cpm      <- edgeR::cpm(x$inputs$counts)   #Calculate CPM for simulated count matrix
    calc.mean.cpm <- rowMeans(calc.cpm)           #Calculate mean cpm per gene
    low.count.mRNA  <- names(which(calc.mean.cpm < 20))
    high.count.mRNA <- names(which(calc.mean.cpm >=20))
    
    x$result$abundance.level <- NA
    x$result$abundance.level[x$result$Genes %in% low.count.mRNA]  <- "low"
    x$result$abundance.level[x$result$Genes %in% high.count.mRNA] <- "high"
    
    x$inputs$de.gene$abundance.level <- NA
    x$inputs$de.gene$abundance.level[x$inputs$de.gene$Genes %in% low.count.mRNA]  <- "low"
    x$inputs$de.gene$abundance.level[x$inputs$de.gene$Genes %in% high.count.mRNA] <- "high"
    
    
    if(x$inputs$setting$p.diff > 0){
      temp.table.1 <- prop.table(table(x$inputs$de.gene$abundance.level, x$inputs$de.gene$de.genes), margin = 1)
      temp.table.2 <- prop.table(table(x$inputs$de.gene$abundance.level, x$inputs$de.gene$de.genes), margin = 2)
      
      x$inputs$abundance.level.composition <- list(
        prop.low.count.mRNA  = length(low.count.mRNA)/nrow(x$inputs$counts), 
        prop.high.count.mRNA = length(high.count.mRNA)/nrow(x$inputs$counts),
        
        prop.low.count.mRNA_in_DE      = temp.table.2[2, 2],
        prop.low.count.mRNA_in_none.DE = temp.table.2[2, 1],
        
        prop.high.count.mRNA_in_DE     = temp.table.2[1, 2],
        prop.high.count.mRNA_in_none.DE= temp.table.2[1, 1],
        
        
        prop.DE_in_low.count.mRNA     = temp.table.1[2, 2],
        prop.non.DE_in_low.count.mRNA = temp.table.1[2, 1],
        
        prop.DE_in_high.count.mRNA     = temp.table.1[1, 2],
        prop.non.DE_in_high.count.mRNA = temp.table.1[1, 1])
    }
    else if(x$inputs$setting$p.diff == 0){
      x$inputs$abundance.level.composition <- list(list(
        prop.low.count.mRNA  <- length(low.count.mRNA)/nrow(x$inputs$counts), 
        prop.high.count.mRNA <- 1 - prop.low.count.mRNA,
        
        prop.low.count.mRNA_in_DE      <- NA,
        prop.low.count.mRNA_in_none.DE <- prop.low.count.mRNA,
        
        prop.high.count.mRNA_in_DE     <- NA,
        prop.high.count.mRNA_in_none.DE<- prop.high.count.mRNA,
        
        
        prop.DE_in_low.count.mRNA     <- 0,
        prop.non.DE_in_low.count.mRNA <- 1,
        
        prop.DE_in_high.count.mRNA     <- 0,
        prop.non.DE_in_high.count.mRNA <- 1))
    }
    return(x)
  })
  return(y)
})
DE.result.20PDE.GTEx <- lapply(DE.result.20PDE.GTEx, function(y){
  y <- lapply(y, function(x){
    calc.cpm      <- edgeR::cpm(x$inputs$counts)   #Calculate CPM for simulated count matrix
    calc.mean.cpm <- rowMeans(calc.cpm)           #Calculate mean cpm per gene
    low.count.mRNA  <- names(which(calc.mean.cpm < 10))
    high.count.mRNA <- names(which(calc.mean.cpm >=10))
    
    x$result$abundance.level <- NA
    x$result$abundance.level[x$result$Genes %in% low.count.mRNA]  <- "low"
    x$result$abundance.level[x$result$Genes %in% high.count.mRNA] <- "high"
    
    x$inputs$de.gene$abundance.level <- NA
    x$inputs$de.gene$abundance.level[x$inputs$de.gene$Genes %in% low.count.mRNA]  <- "low"
    x$inputs$de.gene$abundance.level[x$inputs$de.gene$Genes %in% high.count.mRNA] <- "high"
    
    
    if(x$inputs$setting$p.diff > 0){
      temp.table.1 <- prop.table(table(x$inputs$de.gene$abundance.level, x$inputs$de.gene$de.genes), margin = 1)
      temp.table.2 <- prop.table(table(x$inputs$de.gene$abundance.level, x$inputs$de.gene$de.genes), margin = 2)
      
      x$inputs$abundance.level.composition <- list(
        prop.low.count.mRNA  = length(low.count.mRNA)/nrow(x$inputs$counts), 
        prop.high.count.mRNA = length(high.count.mRNA)/nrow(x$inputs$counts),
        
        prop.low.count.mRNA_in_DE      = temp.table.2[2, 2],
        prop.low.count.mRNA_in_none.DE = temp.table.2[2, 1],
        
        prop.high.count.mRNA_in_DE     = temp.table.2[1, 2],
        prop.high.count.mRNA_in_none.DE= temp.table.2[1, 1],
        
        
        prop.DE_in_low.count.mRNA     = temp.table.1[2, 2],
        prop.non.DE_in_low.count.mRNA = temp.table.1[2, 1],
        
        prop.DE_in_high.count.mRNA     = temp.table.1[1, 2],
        prop.non.DE_in_high.count.mRNA = temp.table.1[1, 1])
    }
    else if(x$inputs$setting$p.diff == 0){
      x$inputs$abundance.level.composition <- list(list(
        prop.low.count.mRNA  <- length(low.count.mRNA)/nrow(x$inputs$counts), 
        prop.high.count.mRNA <- 1 - prop.low.count.mRNA,
        
        prop.low.count.mRNA_in_DE      <- NA,
        prop.low.count.mRNA_in_none.DE <- prop.low.count.mRNA,
        
        prop.high.count.mRNA_in_DE     <- NA,
        prop.high.count.mRNA_in_none.DE<- prop.high.count.mRNA,
        
        
        prop.DE_in_low.count.mRNA     <- 0,
        prop.non.DE_in_low.count.mRNA <- 1,
        
        prop.DE_in_high.count.mRNA     <- 0,
        prop.non.DE_in_high.count.mRNA <- 1))
    }
    return(x)
  })
  return(y)
})


str(DE.result.20PDE.GTEx$edgeR.exact[[151]])

saveRDS(DE.result.30PDE.GTEx, paste0(dir.GTEx, "DE.result.30PDE.GTEx.RData"))
saveRDS(DE.result.20PDE.GTEx, paste0(dir.GTEx, "DE.result.20PDE.GTEx.RData"))

#Calculate performance metrics
thrld =0.05
perf.measures.30PDE.GTEx <- lapply(DE.result.30PDE.GTEx, function(x){
    t(sapply(x, function(y){
      res <- y$result
      sumr.low.count.mRNA <- calc.perf.metrics(res$q[res$abundance.level=="low"], 
                                               res$de.genes[res$abundance.level=="low"], thrld = thrld)
      FNR.low.count.mRNA <- sumr.low.count.mRNA$FNR
      TPR.low.count.mRNA <- sumr.low.count.mRNA$TPR
      TNR.low.count.mRNA <- sumr.low.count.mRNA$TNR
      FPR.low.count.mRNA <- sumr.low.count.mRNA$FPR
      FDR.low.count.mRNA <- sumr.low.count.mRNA$FDR
      
      sumr.high.count.mRNA <- calc.perf.metrics(res$q[res$abundance.level=="high"], 
                                                res$de.genes[res$abundance.level=="high"], thrld = thrld)
      FNR.high.count.mRNA <- sumr.high.count.mRNA$FNR
      TPR.high.count.mRNA <- sumr.high.count.mRNA$TPR
      TNR.high.count.mRNA <- sumr.high.count.mRNA$TNR
      FPR.high.count.mRNA <- sumr.high.count.mRNA$FPR
      FDR.high.count.mRNA <- sumr.high.count.mRNA$FDR
      
      rep.size <- y$inputs$setting$k.ind
      prop.DE  <- y$inputs$setting$p.diff
      biotype.composition <- unlist(y$inputs$gene.biotype.composition)
      abundance.level.composition <- unlist(y$inputs$abundance.level.composition)
      c(FNR.low.count.mRNA=FNR.low.count.mRNA, TPR.low.count.mRNA=TPR.low.count.mRNA, TNR.low.count.mRNA=TNR.low.count.mRNA,FPR.low.count.mRNA=FPR.low.count.mRNA, 
        FDR.low.count.mRNA=FDR.low.count.mRNA,
        FNR.high.count.mRNA=FNR.high.count.mRNA, TPR.high.count.mRNA=TPR.high.count.mRNA, TNR.high.count.mRNA=TNR.high.count.mRNA,
        FPR.high.count.mRNA=FPR.high.count.mRNA, FDR.high.count.mRNA=FDR.high.count.mRNA,
        rep.size=rep.size, prop.DE=prop.DE, biotype.composition, abundance.level.composition)
    }))
  })
perf.measures.30PDE.GTEx <- as.data.frame(do.call("rbind", perf.measures.30PDE.GTEx))
perf.measures.30PDE.GTEx$DE.tool  <- rep(names(DE.result.30PDE.GTEx), each=300)
perf.measures.30PDE.GTEx$alpha    <- thrld
saveRDS(perf.measures.30PDE.GTEx, paste0(dir.GTEx, "perf.measures.30PDE.GTEx.RData"))


thrld =0.05
perf.measures.20PDE.GTEx <- lapply(DE.result.20PDE.GTEx, function(x){
  t(sapply(x, function(y){
    res <- y$result
    sumr.low.count.mRNA <- calc.perf.metrics(res$q[res$abundance.level=="low"], 
                                             res$de.genes[res$abundance.level=="low"], thrld = thrld)
    FNR.low.count.mRNA <- sumr.low.count.mRNA$FNR
    TPR.low.count.mRNA <- sumr.low.count.mRNA$TPR
    TNR.low.count.mRNA <- sumr.low.count.mRNA$TNR
    FPR.low.count.mRNA <- sumr.low.count.mRNA$FPR
    FDR.low.count.mRNA <- sumr.low.count.mRNA$FDR
    
    sumr.high.count.mRNA <- calc.perf.metrics(res$q[res$abundance.level=="high"], 
                                              res$de.genes[res$abundance.level=="high"], thrld = thrld)
    FNR.high.count.mRNA <- sumr.high.count.mRNA$FNR
    TPR.high.count.mRNA <- sumr.high.count.mRNA$TPR
    TNR.high.count.mRNA <- sumr.high.count.mRNA$TNR
    FPR.high.count.mRNA <- sumr.high.count.mRNA$FPR
    FDR.high.count.mRNA <- sumr.high.count.mRNA$FDR
    
    rep.size <- y$inputs$setting$k.ind
    prop.DE  <- y$inputs$setting$p.diff
    biotype.composition <- unlist(y$inputs$gene.biotype.composition)
    abundance.level.composition <- unlist(y$inputs$abundance.level.composition)
    c(FNR.low.count.mRNA=FNR.low.count.mRNA, TPR.low.count.mRNA=TPR.low.count.mRNA, TNR.low.count.mRNA=TNR.low.count.mRNA,FPR.low.count.mRNA=FPR.low.count.mRNA, 
      FDR.low.count.mRNA=FDR.low.count.mRNA,
      FNR.high.count.mRNA=FNR.high.count.mRNA, TPR.high.count.mRNA=TPR.high.count.mRNA, TNR.high.count.mRNA=TNR.high.count.mRNA,
      FPR.high.count.mRNA=FPR.high.count.mRNA, FDR.high.count.mRNA=FDR.high.count.mRNA,
      rep.size=rep.size, prop.DE=prop.DE, biotype.composition, abundance.level.composition)
  }))
})
perf.measures.20PDE.GTEx <- as.data.frame(do.call("rbind", perf.measures.20PDE.GTEx))
perf.measures.20PDE.GTEx$DE.tool  <- rep(names(DE.result.20PDE.GTEx), each=350)
perf.measures.20PDE.GTEx$alpha    <- thrld

head(perf.measures.20PDE.GTEx)
saveRDS(perf.measures.20PDE.GTEx, paste0(dir.GTEx, "perf.measures.20PDE.GTEx.RData"))


#Calculate summary of performance metrics
calc.summary <- function(x){
  require(reshape2)
  smr <- as.data.frame(apply(x[, 1:10], 2, function(y){
    if(all(is.na(y))){
      return(c(mean=NA, ll=NA, ul=NA))
    }
    else{
      mean    = mean(y, na.rm = TRUE)
      n       = length(y)
      std.err = sd(y, na.rm = TRUE)/sqrt(n)
      ll      = max(mean-1.96*std.err, 0) 
      ul      = min(mean+1.96*std.err, 1)
      return(c(mean=mean, ll=ll, ul=ul))
    }
  }))
  
  smr$rep.size = as.numeric(unique(x[, 11]))
  smr$prop.DE  = as.numeric(unique(x[, 12]))
  smr$DE.tool  = as.character(convert.name(unique(x[, 13])))
  smr$alpha    = as.numeric(unique(x[, 14]))
  smr$stat     = rownames(smr) ; rownames(smr) = NULL
  
  smr <- melt(smr, id.vars = c("rep.size", "prop.DE", "DE.tool", "alpha", "stat"))
  smr <- dcast(smr, rep.size+prop.DE+DE.tool+alpha+variable ~stat)
  smr$metrics = sapply(1:nrow(smr), function(i) unlist(strsplit(as.character(smr$variable[i]), "[.]"))[1])
  smr$abundance.level = sapply(1:nrow(smr), function(i) unlist(strsplit(as.character(smr$variable[i]), "[.]"))[2])
  smr$variable = NULL
  
  smr$metrics  <- as.factor(smr$metrics)
  smr$DE.tool  <- as.factor(smr$DE.tool)
  smr$abundance.level  <- as.factor(smr$abundance.level)
  
  smr
}

simult.summary.30PDE.GTEx <- as.data.frame(do.call(rbind, by(perf.measures.30PDE.GTEx[, c(1:10, 11, 12, 25, 26)],  
                                                       perf.measures.30PDE.GTEx[, c(11, 12, 25, 26)], calc.summary)))
simult.summary.20PDE.GTEx <- as.data.frame(do.call(rbind, by(perf.measures.20PDE.GTEx[, c(1:10, 11, 12, 25, 26)],  
                                                             perf.measures.20PDE.GTEx[, c(11, 12, 25, 26)], calc.summary)))
saveRDS(simult.summary.30PDE.GTEx, paste0(dir.GTEx, "simult.summary.30PDE.GTEx.RData"))
saveRDS(simult.summary.20PDE.GTEx, paste0(dir.GTEx, "simult.summary.20PDE.GTEx.RData"))


simult.summary.30PDE.GTEx <- readRDS(paste0(dir.GTEx, "simult.summary.30PDE.GTEx.RData"))
simult.summary.20PDE.GTEx <- readRDS(paste0(dir.GTEx, "simult.summary.20PDE.GTEx.RData"))
head(simult.summary.20PDE.GTEx)


#Creat Plot
##20% true DE 
sel.summary.1 <- simult.summary.20PDE.GTEx[simult.summary.20PDE.GTEx$rep.size %in% c(5, 14) &
                                             simult.summary.20PDE.GTEx$prop.DE %in% c(0.2) &
                                             simult.summary.20PDE.GTEx$alpha ==0.05 & 
                                             simult.summary.20PDE.GTEx$metrics %in% c("FDR", "TPR"), ]
sel.summary.1$metrics = factor(sel.summary.1$metrics, levels = c("FDR", "TPR"))
sel.summary.1$abundance.level = factor(sel.summary.1$abundance.level, levels = c("low", "high"))
sel.summary.1$vline <- ifelse(sel.summary.1$metrics== "FDR", 0.05, NA)
# sel.summary.1[sel.summary.1$abundance.level == "low", c("ll", "mean", "ul", "vline")] <-
#   -1*sel.summary.1[sel.summary.1$abundance.level == "low", c("ll", "mean", "ul", "vline")]
sel.summary.1$DE.tool <- factor(sel.summary.1$DE.tool, levels(sel.summary.1$DE.tool)[rev(c(13,7,5,10, 12, 8,1, 9, 3, 2 ,4,11,6))])


p <- ggplot(data=sel.summary.1, 
            aes(y=mean, x=DE.tool, group=abundance.level, colour=abundance.level))+
  #geom_bar(position="stack", stat="identity", colour = "black", size = 0.1, width = 0.7) +
  geom_point(size=3)+
  coord_flip() + 
  facet_wrap(rep.size~ metrics) +
  geom_errorbar(aes(ymin=ll, ymax=ul), width=0.4)+
  scale_color_manual("", values = c( "high" ="deepskyblue3", "low"= "orange")) + 
  scale_alpha_manual(values = 0.75)+
  scale_y_continuous(breaks=c(0,  0.25, 0.5), labels=c(0,  0.25, 0.5),  limits=c(0, 0.5)) +
  theme(axis.text.x=element_text(size = 9, colour = "black"), 
        axis.text.y=element_text(size = 9, colour = "black"),
        panel.background = element_rect(fill = NA),
        panel.grid.major = element_line(colour = "grey80"),
        strip.background = element_rect(colour = "black", fill = "white"),
        panel.grid.major.y = element_blank(),
        legend.position="top")+
  geom_hline(aes(yintercept = vline), col="gray25", lty=2)+
  labs(y=NULL, x=NULL) 
p

png(file=paste0(dir.GTEx, "FDR_TPR.sel.png"), width=7.25,height=5.25, units = "in", res=700)
p
dev.off()


##30% true DE 
sel.summary.1 <- simult.summary.30PDE.GTEx[simult.summary.30PDE.GTEx$rep.size %in% c(5, 10) &
                                             simult.summary.30PDE.GTEx$prop.DE %in% c(0.3) &
                                             simult.summary.30PDE.GTEx$alpha ==0.05 & 
                                             simult.summary.30PDE.GTEx$metrics %in% c("FDR", "TPR"), ]
sel.summary.1$metrics = factor(sel.summary.1$metrics, levels = c("FDR", "TPR"))
sel.summary.1$abundance.level = factor(sel.summary.1$abundance.level, levels = c("low", "high"))
sel.summary.1$vline <- ifelse(sel.summary.1$metrics== "FDR", 0.05, NA)
# sel.summary.1[sel.summary.1$abundance.level == "low", c("ll", "mean", "ul", "vline")] <-
#   -1*sel.summary.1[sel.summary.1$abundance.level == "low", c("ll", "mean", "ul", "vline")]
sel.summary.1$DE.tool <- factor(sel.summary.1$DE.tool, levels(sel.summary.1$DE.tool)[rev(c(11,3,7,6,8,10,12,1,4,5,13,9,2))])


p <- ggplot(data=sel.summary.1, 
            aes(y=mean, x=DE.tool, group=abundance.level, colour=abundance.level))+
  #geom_bar(position="stack", stat="identity", colour = "black", size = 0.1, width = 0.7) +
  geom_point(size=3)+
  coord_flip() + 
  facet_wrap(rep.size~ metrics) +
  geom_errorbar(aes(ymin=ll, ymax=ul), width=0.4)+
  scale_color_manual("", values = c( "high" ="deepskyblue3", "low"= "orange")) + 
  scale_alpha_manual(values = 0.75)+
  scale_y_continuous(breaks=c(0,  0.25, 0.5), labels=c(0,  0.25, 0.5),  limits=c(0, 0.5)) +
  theme(axis.text.x=element_text(size = 9, colour = "black"), 
        axis.text.y=element_text(size = 9, colour = "black"),
        panel.background = element_rect(fill = NA),
        panel.grid.major = element_line(colour = "grey80"),
        strip.background = element_rect(colour = "black", fill = "white"),
        panel.grid.major.y = element_blank(),
        legend.position="top")+
  geom_hline(aes(yintercept = vline), col="gray25", lty=2)+
  labs(y=NULL, x=NULL) 
p

png(file=paste0(dir.GTEx, "FDR_TPR.sel.png"), width=7.25,height=5.25, units = "in", res=700)
p
dev.off()
