#load global functions and objects
source("global_functions_and_objects.R")

DE.result.20PDE.GTEx <- readRDS(paste0(dir.GTEx, "DE_results_20PercDE.RData"))


#Filter out genes with mean CPM below a specific value and calculate performance metrics

filt_and_perf.20PDE.GTEx <- as.data.frame(do.call(rbind, lapply(DE.result.20PDE.GTEx, function(y){
  temp <- as.data.frame(do.call(rbind, lapply(y, function(x){
    calc.cpm      <- edgeR::cpm(x$inputs$counts)   #Calculate CPM for simulated count matrix
    calc.mean.cpm <- rowMeans(calc.cpm)           #Calculate mean cpm per gene
    mRNA.0CPM     <- names(which(calc.mean.cpm > 0))
    mRNA.0.1CPM     <- names(which(calc.mean.cpm >= 0.1))
    mRNA.0.5CPM     <- names(which(calc.mean.cpm >= 0.5))
    mRNA.1CPM     <- names(which(calc.mean.cpm >= 1))
    mRNA.5CPM     <- names(which(calc.mean.cpm >= 5))
    mRNA.10CPM     <- names(which(calc.mean.cpm >= 10))
    mRNA.15CPM     <- names(which(calc.mean.cpm >= 15))
    mRNA.20CPM     <- names(which(calc.mean.cpm >= 20))
    mRNA.30CPM     <- names(which(calc.mean.cpm >= 30))
    mRNA.50CPM     <- names(which(calc.mean.cpm >= 50))
    
    res <- x$result

    
    cut.off <- c(0, 0.1, 0.5, 01, 5, 10, 15, 20, 30, 50)
    perf.all <- as.data.frame(t(sapply(cut.off, function(i){
      sub.set <- names(which(calc.mean.cpm >= i))
      perf    <- calc.perf.metrics(res$q[res$Genes %in% sub.set], res$de.genes[res$Genes %in% sub.set])
      list(TPR = perf$TPR,
           FDR = perf$FDR,
           n.genes = length(sub.set),
           n.filtered.genes = nrow(x$inputs$counts) - length(sub.set),
           n.DE.genes       = length(res$de.genes[res$Genes %in% sub.set & res$de.genes==1]),
           cut.off  = i,
           rep.size = x$inputs$setting$k.ind,
           alpha    = 0.05,
           prop.DE  = x$inputs$setting$p.diff)
    })))
    perf.all
  })))
  return(temp)
})))
filt_and_perf.20PDE.GTEx$DE.tool <- rep(names(DE.result.20PDE.GTEx), each=3500)
rownames(filt_and_perf.20PDE.GTEx) <- NULL
class(filt_and_perf.20PDE.GTEx)
head(filt_and_perf.20PDE.GTEx)

filt_and_perf.20PDE.GTEx$FDR <- as.numeric(filt_and_perf.20PDE.GTEx$FDR)
filt_and_perf.20PDE.GTEx$TPR <- as.numeric(filt_and_perf.20PDE.GTEx$TPR)
filt_and_perf.20PDE.GTEx$cut.off <- as.numeric(filt_and_perf.20PDE.GTEx$cut.off)


saveRDS(filt_and_perf.20PDE.GTEx, "GTEx/filt_and_perf.20PDE.GTEx.RData")

#Creat plot
plt1 <- ggplot(filt_and_perf.20PDE.GTEx[filt_and_perf.20PDE.GTEx$rep.size == 10, ], 
       aes(x=cut.off, y=TPR))+
  geom_point()+
  facet_grid(.~DE.tool)
plt1 
